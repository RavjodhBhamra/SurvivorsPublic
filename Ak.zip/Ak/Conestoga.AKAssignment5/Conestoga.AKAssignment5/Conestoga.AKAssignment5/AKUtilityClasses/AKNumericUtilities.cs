﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
    This is a Utility class naming "AKNumericUtilities" in "AKUtilityClasses"
     folder. This class contains following methods in
     sequence.
     1) AKIsNumeric.
     2) AKIsInteger
     
    Ankit Ravindra Kundlu, 2018.04.16 : Created 
 */
namespace Conestoga.AKAssignment5.AKUtilityClasses
{
    class AKNumericUtilities
    {
        // Is Numeric Methods
        public Boolean AKIsNumeric(string input)
        {
            int result;
            return int.TryParse(input, out result);
        }

        // Is Integers Methods
        public Boolean AKIsInteger(string input)
        {
            double result;
            return Double.TryParse(input, out result);
        } 
    }
}
