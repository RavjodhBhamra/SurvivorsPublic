﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
     This is a Utility class naming "AKValidations" in "AKUtilityClasses"
     folder. This class contains following methods in
     sequence.s class contains following methods in
     sequence.
     1) AKValidatePostalCode
     2) Validate ZipCode method
     4) AKValidatePhone
     
    Ankit Ravindra Kundlu, 2018.04.16 : Created 
 */

namespace Conestoga.AKAssignment5.AKUtilityClasses
{
    public class AKValidations
    {
        // Validate Postal Code method
        public bool AKValidatePostalCode(string postalCodeValidation)
        {
           Regex postalPattern = new Regex("^[ABCEGHJ-NPRSTVXY]{1}[0-9]{1}[ABCEGHJ-NPRSTV-Z]{1}[ ]?[0-9]{1}[ABCEGHJ-NPRSTV-Z]{1}[0-9]{1}$", RegexOptions.IgnoreCase);
           return postalPattern.IsMatch(postalCodeValidation);       
        }

        // Validate ZipCode method
        public bool AKValidateZip(string zipValidation)
        {
            Regex zip = new Regex(@"^(?!0{5})(\d{5})(?!-?0{4})(|-\d{4})?$", RegexOptions.IgnoreCase);

            if (zipValidation.Length == 5 || zipValidation.Length == 9)
            {
                return true;
            }
            else
            {
                return false;
            }
            return zip.IsMatch(zipValidation);
        }

         // Validate Phone method
        public bool AKValidatePhone(string phoneValidation)
        {
            Regex phone = new Regex(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", RegexOptions.IgnoreCase);
            return phone.IsMatch(phoneValidation);
        }
    }
}
