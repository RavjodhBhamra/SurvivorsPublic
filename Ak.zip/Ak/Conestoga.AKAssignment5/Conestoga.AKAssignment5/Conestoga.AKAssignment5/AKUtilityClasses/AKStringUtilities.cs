﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
     This is a Utility class naming "AKStringUtilities" in "AKUtilityClasses"
     folder. This class contains following methods in
     sequence.
     1) AKCapatalize
     2) AKFormatPhone
     4) KFormatPostal
     5) AKFormatZip
     6) AKFullName
     
    Ankit Ravindra Kundlu, 2018.04.16 : Created 
 */

namespace Conestoga.AKAssignment5.AKUtilityClasses
{
    public class AKStringUtilities
    {
        // Capatalize method 
        public string AKCapatalize(string capatalize)
        { 
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;

            return textInfo.ToTitleCase(capatalize).Trim();  
        }

        // Format Phone Method
        public string AKFormatPhone(string phone)
        {
            string result;

            phone.Trim();
            if (phone.Length == 7)
            {

                result = phone.Substring(0, 3) + " - " + phone.Substring(3);
                return result;
            }
            else if (phone.Length == 10)
            {

                result = phone.Substring(0, 3) + "-" + phone.Substring(3, 3) + "-" + phone.Substring(6);
                return result;
            }
            else
            {
                result = phone;
                return result;
            }
        }
        
        // Format Postal Code Method
        public string AKFormatPostal(string postalCode)
        {
            try
            {
                string result = postalCode.Substring(0, 3).Insert(3, " ") + postalCode.Substring(3).Trim();
                
                return result.Trim().ToUpper();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            } 
        }

        // Format Zip Code Method
        public string AKFormatZip(string zipCode)
        {
            string result; 
            if (zipCode.Length == 5)
            {
                result = zipCode;
                return result;
            }
            else if (zipCode.Length == 9)
            {

                result = zipCode.Substring(0, 5) + " - " + zipCode.Substring(5);
                return result;
            }
            else
            {
                result = zipCode;
                return result.Trim();
            }
        }

        // Full Name Method
        public string AKFullName(string fullName)
        {
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;

            return textInfo.ToTitleCase(fullName).Trim().Replace(" ", "," + " ");
        }
    }
}
