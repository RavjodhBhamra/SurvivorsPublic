﻿namespace Conestoga.AKAssignment5
{
    partial class AKAssignment5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIsNumeric = new System.Windows.Forms.TextBox();
            this.txtIsInteger = new System.Windows.Forms.TextBox();
            this.txtExtractNumeric = new System.Windows.Forms.TextBox();
            this.txtOnlyInputDigit = new System.Windows.Forms.TextBox();
            this.txtCapatalize = new System.Windows.Forms.TextBox();
            this.txtExtractDigit = new System.Windows.Forms.TextBox();
            this.txtFormatPhone = new System.Windows.Forms.TextBox();
            this.txtFormatPostal = new System.Windows.Forms.TextBox();
            this.txtFormatZip = new System.Windows.Forms.TextBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtValidatePostal = new System.Windows.Forms.TextBox();
            this.txtValidateZip = new System.Windows.Forms.TextBox();
            this.txtValidatePhone = new System.Windows.Forms.TextBox();
            this.lblNumericUtilities = new System.Windows.Forms.Label();
            this.lblStringUtilities = new System.Windows.Forms.Label();
            this.lblValidations = new System.Windows.Forms.Label();
            this.lblIsNumeric = new System.Windows.Forms.Label();
            this.lblIsInteger = new System.Windows.Forms.Label();
            this.lblExtractNumeric = new System.Windows.Forms.Label();
            this.lblOnlyInputDigits = new System.Windows.Forms.Label();
            this.lblCapatalize = new System.Windows.Forms.Label();
            this.lblExtractDigits = new System.Windows.Forms.Label();
            this.lblFormatPhone = new System.Windows.Forms.Label();
            this.lblFormatPostalCode = new System.Windows.Forms.Label();
            this.lblFormatZipCode = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblValidatePostalCode = new System.Windows.Forms.Label();
            this.lblValidateZipCode = new System.Windows.Forms.Label();
            this.lblvalidatePhoneNumber = new System.Windows.Forms.Label();
            this.lblMsgIsNumeric = new System.Windows.Forms.Label();
            this.lblMsgIsInteger = new System.Windows.Forms.Label();
            this.lblMsgExtractNumeric = new System.Windows.Forms.Label();
            this.lblMsgOnlyInputDigit = new System.Windows.Forms.Label();
            this.lblMsgCapatalize = new System.Windows.Forms.Label();
            this.lblMsgExtractDigit = new System.Windows.Forms.Label();
            this.lblMsgFormatPhone = new System.Windows.Forms.Label();
            this.lblMsgFormatPostal = new System.Windows.Forms.Label();
            this.lblMsgFormatZip = new System.Windows.Forms.Label();
            this.lblMsgFormatFullName = new System.Windows.Forms.Label();
            this.lblMsgValidatePostal = new System.Windows.Forms.Label();
            this.lblMsgValidateZip = new System.Windows.Forms.Label();
            this.lblMsgValidatePhone = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClearTxtBox = new System.Windows.Forms.Button();
            this.btnPreFill = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtIsNumeric
            // 
            this.txtIsNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsNumeric.Location = new System.Drawing.Point(267, 51);
            this.txtIsNumeric.Multiline = true;
            this.txtIsNumeric.Name = "txtIsNumeric";
            this.txtIsNumeric.Size = new System.Drawing.Size(342, 32);
            this.txtIsNumeric.TabIndex = 0;
            // 
            // txtIsInteger
            // 
            this.txtIsInteger.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsInteger.Location = new System.Drawing.Point(267, 101);
            this.txtIsInteger.Multiline = true;
            this.txtIsInteger.Name = "txtIsInteger";
            this.txtIsInteger.Size = new System.Drawing.Size(342, 32);
            this.txtIsInteger.TabIndex = 1;
            // 
            // txtExtractNumeric
            // 
            this.txtExtractNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtractNumeric.Location = new System.Drawing.Point(267, 153);
            this.txtExtractNumeric.Multiline = true;
            this.txtExtractNumeric.Name = "txtExtractNumeric";
            this.txtExtractNumeric.Size = new System.Drawing.Size(342, 32);
            this.txtExtractNumeric.TabIndex = 2;
            this.txtExtractNumeric.TextChanged += new System.EventHandler(this.txtExtractNumeric_TextChanged);
            // 
            // txtOnlyInputDigit
            // 
            this.txtOnlyInputDigit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOnlyInputDigit.Location = new System.Drawing.Point(267, 202);
            this.txtOnlyInputDigit.Multiline = true;
            this.txtOnlyInputDigit.Name = "txtOnlyInputDigit";
            this.txtOnlyInputDigit.Size = new System.Drawing.Size(342, 32);
            this.txtOnlyInputDigit.TabIndex = 3;
            this.txtOnlyInputDigit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOnlyInputDigit_KeyPress);
            // 
            // txtCapatalize
            // 
            this.txtCapatalize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCapatalize.Location = new System.Drawing.Point(267, 297);
            this.txtCapatalize.Multiline = true;
            this.txtCapatalize.Name = "txtCapatalize";
            this.txtCapatalize.Size = new System.Drawing.Size(342, 32);
            this.txtCapatalize.TabIndex = 4;
            // 
            // txtExtractDigit
            // 
            this.txtExtractDigit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtractDigit.Location = new System.Drawing.Point(267, 346);
            this.txtExtractDigit.Multiline = true;
            this.txtExtractDigit.Name = "txtExtractDigit";
            this.txtExtractDigit.Size = new System.Drawing.Size(342, 32);
            this.txtExtractDigit.TabIndex = 5;
            this.txtExtractDigit.TextChanged += new System.EventHandler(this.txtExtractDigit_TextChanged);
            // 
            // txtFormatPhone
            // 
            this.txtFormatPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFormatPhone.Location = new System.Drawing.Point(267, 395);
            this.txtFormatPhone.Multiline = true;
            this.txtFormatPhone.Name = "txtFormatPhone";
            this.txtFormatPhone.Size = new System.Drawing.Size(342, 32);
            this.txtFormatPhone.TabIndex = 6;
            // 
            // txtFormatPostal
            // 
            this.txtFormatPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFormatPostal.Location = new System.Drawing.Point(267, 444);
            this.txtFormatPostal.Multiline = true;
            this.txtFormatPostal.Name = "txtFormatPostal";
            this.txtFormatPostal.Size = new System.Drawing.Size(342, 32);
            this.txtFormatPostal.TabIndex = 7;
            // 
            // txtFormatZip
            // 
            this.txtFormatZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFormatZip.Location = new System.Drawing.Point(267, 493);
            this.txtFormatZip.Multiline = true;
            this.txtFormatZip.Name = "txtFormatZip";
            this.txtFormatZip.Size = new System.Drawing.Size(342, 32);
            this.txtFormatZip.TabIndex = 8;
            // 
            // txtFullName
            // 
            this.txtFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFullName.Location = new System.Drawing.Point(267, 542);
            this.txtFullName.Multiline = true;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(342, 32);
            this.txtFullName.TabIndex = 9;
            // 
            // txtValidatePostal
            // 
            this.txtValidatePostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValidatePostal.Location = new System.Drawing.Point(267, 633);
            this.txtValidatePostal.Multiline = true;
            this.txtValidatePostal.Name = "txtValidatePostal";
            this.txtValidatePostal.Size = new System.Drawing.Size(342, 32);
            this.txtValidatePostal.TabIndex = 10;
            // 
            // txtValidateZip
            // 
            this.txtValidateZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValidateZip.Location = new System.Drawing.Point(267, 685);
            this.txtValidateZip.Multiline = true;
            this.txtValidateZip.Name = "txtValidateZip";
            this.txtValidateZip.Size = new System.Drawing.Size(342, 32);
            this.txtValidateZip.TabIndex = 11;
            // 
            // txtValidatePhone
            // 
            this.txtValidatePhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValidatePhone.Location = new System.Drawing.Point(267, 737);
            this.txtValidatePhone.Multiline = true;
            this.txtValidatePhone.Name = "txtValidatePhone";
            this.txtValidatePhone.Size = new System.Drawing.Size(342, 32);
            this.txtValidatePhone.TabIndex = 12;
            // 
            // lblNumericUtilities
            // 
            this.lblNumericUtilities.AutoSize = true;
            this.lblNumericUtilities.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumericUtilities.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblNumericUtilities.Location = new System.Drawing.Point(30, 9);
            this.lblNumericUtilities.Name = "lblNumericUtilities";
            this.lblNumericUtilities.Size = new System.Drawing.Size(228, 31);
            this.lblNumericUtilities.TabIndex = 13;
            this.lblNumericUtilities.Text = "Numeric Utilities";
            // 
            // lblStringUtilities
            // 
            this.lblStringUtilities.AutoSize = true;
            this.lblStringUtilities.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStringUtilities.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStringUtilities.Location = new System.Drawing.Point(30, 264);
            this.lblStringUtilities.Name = "lblStringUtilities";
            this.lblStringUtilities.Size = new System.Drawing.Size(197, 31);
            this.lblStringUtilities.TabIndex = 14;
            this.lblStringUtilities.Text = "String Utilities";
            // 
            // lblValidations
            // 
            this.lblValidations.AutoSize = true;
            this.lblValidations.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidations.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblValidations.Location = new System.Drawing.Point(40, 599);
            this.lblValidations.Name = "lblValidations";
            this.lblValidations.Size = new System.Drawing.Size(158, 31);
            this.lblValidations.TabIndex = 15;
            this.lblValidations.Text = "Validations";
            // 
            // lblIsNumeric
            // 
            this.lblIsNumeric.AutoSize = true;
            this.lblIsNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsNumeric.Location = new System.Drawing.Point(89, 63);
            this.lblIsNumeric.Name = "lblIsNumeric";
            this.lblIsNumeric.Size = new System.Drawing.Size(172, 20);
            this.lblIsNumeric.TabIndex = 16;
            this.lblIsNumeric.Text = "IsNumeric-string-object";
            // 
            // lblIsInteger
            // 
            this.lblIsInteger.AutoSize = true;
            this.lblIsInteger.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsInteger.Location = new System.Drawing.Point(43, 113);
            this.lblIsInteger.Name = "lblIsInteger";
            this.lblIsInteger.Size = new System.Drawing.Size(218, 20);
            this.lblIsInteger.TabIndex = 17;
            this.lblIsInteger.Text = "IsInteger-string-object-double";
            // 
            // lblExtractNumeric
            // 
            this.lblExtractNumeric.AutoSize = true;
            this.lblExtractNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtractNumeric.Location = new System.Drawing.Point(144, 165);
            this.lblExtractNumeric.Name = "lblExtractNumeric";
            this.lblExtractNumeric.Size = new System.Drawing.Size(117, 20);
            this.lblExtractNumeric.TabIndex = 18;
            this.lblExtractNumeric.Text = "ExtractNumeric";
            // 
            // lblOnlyInputDigits
            // 
            this.lblOnlyInputDigits.AutoSize = true;
            this.lblOnlyInputDigits.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOnlyInputDigits.Location = new System.Drawing.Point(144, 214);
            this.lblOnlyInputDigits.Name = "lblOnlyInputDigits";
            this.lblOnlyInputDigits.Size = new System.Drawing.Size(117, 20);
            this.lblOnlyInputDigits.TabIndex = 19;
            this.lblOnlyInputDigits.Text = "OnlyInputDigits";
            // 
            // lblCapatalize
            // 
            this.lblCapatalize.AutoSize = true;
            this.lblCapatalize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCapatalize.Location = new System.Drawing.Point(174, 309);
            this.lblCapatalize.Name = "lblCapatalize";
            this.lblCapatalize.Size = new System.Drawing.Size(84, 20);
            this.lblCapatalize.TabIndex = 20;
            this.lblCapatalize.Text = "Capatalize";
            // 
            // lblExtractDigits
            // 
            this.lblExtractDigits.AutoSize = true;
            this.lblExtractDigits.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtractDigits.Location = new System.Drawing.Point(159, 358);
            this.lblExtractDigits.Name = "lblExtractDigits";
            this.lblExtractDigits.Size = new System.Drawing.Size(99, 20);
            this.lblExtractDigits.TabIndex = 21;
            this.lblExtractDigits.Text = "ExtractDigits";
            // 
            // lblFormatPhone
            // 
            this.lblFormatPhone.AutoSize = true;
            this.lblFormatPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormatPhone.Location = new System.Drawing.Point(152, 407);
            this.lblFormatPhone.Name = "lblFormatPhone";
            this.lblFormatPhone.Size = new System.Drawing.Size(106, 20);
            this.lblFormatPhone.TabIndex = 22;
            this.lblFormatPhone.Text = "FormatPhone";
            // 
            // lblFormatPostalCode
            // 
            this.lblFormatPostalCode.AutoSize = true;
            this.lblFormatPostalCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormatPostalCode.Location = new System.Drawing.Point(116, 456);
            this.lblFormatPostalCode.Name = "lblFormatPostalCode";
            this.lblFormatPostalCode.Size = new System.Drawing.Size(142, 20);
            this.lblFormatPostalCode.TabIndex = 23;
            this.lblFormatPostalCode.Text = "FormatPostalCode";
            // 
            // lblFormatZipCode
            // 
            this.lblFormatZipCode.AutoSize = true;
            this.lblFormatZipCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormatZipCode.Location = new System.Drawing.Point(138, 505);
            this.lblFormatZipCode.Name = "lblFormatZipCode";
            this.lblFormatZipCode.Size = new System.Drawing.Size(120, 20);
            this.lblFormatZipCode.TabIndex = 24;
            this.lblFormatZipCode.Text = "FormatZipCode";
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFullName.Location = new System.Drawing.Point(182, 554);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(76, 20);
            this.lblFullName.TabIndex = 25;
            this.lblFullName.Text = "FullName";
            // 
            // lblValidatePostalCode
            // 
            this.lblValidatePostalCode.AutoSize = true;
            this.lblValidatePostalCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidatePostalCode.Location = new System.Drawing.Point(104, 645);
            this.lblValidatePostalCode.Name = "lblValidatePostalCode";
            this.lblValidatePostalCode.Size = new System.Drawing.Size(157, 20);
            this.lblValidatePostalCode.TabIndex = 26;
            this.lblValidatePostalCode.Text = "Validate Postal Code";
            // 
            // lblValidateZipCode
            // 
            this.lblValidateZipCode.AutoSize = true;
            this.lblValidateZipCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidateZipCode.Location = new System.Drawing.Point(131, 697);
            this.lblValidateZipCode.Name = "lblValidateZipCode";
            this.lblValidateZipCode.Size = new System.Drawing.Size(127, 20);
            this.lblValidateZipCode.TabIndex = 27;
            this.lblValidateZipCode.Text = "ValidateZipCode";
            // 
            // lblvalidatePhoneNumber
            // 
            this.lblvalidatePhoneNumber.AutoSize = true;
            this.lblvalidatePhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvalidatePhoneNumber.Location = new System.Drawing.Point(92, 749);
            this.lblvalidatePhoneNumber.Name = "lblvalidatePhoneNumber";
            this.lblvalidatePhoneNumber.Size = new System.Drawing.Size(169, 20);
            this.lblvalidatePhoneNumber.TabIndex = 28;
            this.lblvalidatePhoneNumber.Text = "ValidatePhoneNumber";
            // 
            // lblMsgIsNumeric
            // 
            this.lblMsgIsNumeric.AutoSize = true;
            this.lblMsgIsNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgIsNumeric.ForeColor = System.Drawing.Color.Red;
            this.lblMsgIsNumeric.Location = new System.Drawing.Point(628, 63);
            this.lblMsgIsNumeric.Name = "lblMsgIsNumeric";
            this.lblMsgIsNumeric.Size = new System.Drawing.Size(13, 16);
            this.lblMsgIsNumeric.TabIndex = 29;
            this.lblMsgIsNumeric.Text = "*";
            // 
            // lblMsgIsInteger
            // 
            this.lblMsgIsInteger.AutoSize = true;
            this.lblMsgIsInteger.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgIsInteger.ForeColor = System.Drawing.Color.Red;
            this.lblMsgIsInteger.Location = new System.Drawing.Point(628, 113);
            this.lblMsgIsInteger.Name = "lblMsgIsInteger";
            this.lblMsgIsInteger.Size = new System.Drawing.Size(13, 16);
            this.lblMsgIsInteger.TabIndex = 30;
            this.lblMsgIsInteger.Text = "*";
            // 
            // lblMsgExtractNumeric
            // 
            this.lblMsgExtractNumeric.AutoSize = true;
            this.lblMsgExtractNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgExtractNumeric.ForeColor = System.Drawing.Color.Red;
            this.lblMsgExtractNumeric.Location = new System.Drawing.Point(628, 165);
            this.lblMsgExtractNumeric.Name = "lblMsgExtractNumeric";
            this.lblMsgExtractNumeric.Size = new System.Drawing.Size(13, 16);
            this.lblMsgExtractNumeric.TabIndex = 31;
            this.lblMsgExtractNumeric.Text = "*";
            // 
            // lblMsgOnlyInputDigit
            // 
            this.lblMsgOnlyInputDigit.AutoSize = true;
            this.lblMsgOnlyInputDigit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgOnlyInputDigit.ForeColor = System.Drawing.Color.Red;
            this.lblMsgOnlyInputDigit.Location = new System.Drawing.Point(628, 214);
            this.lblMsgOnlyInputDigit.Name = "lblMsgOnlyInputDigit";
            this.lblMsgOnlyInputDigit.Size = new System.Drawing.Size(13, 16);
            this.lblMsgOnlyInputDigit.TabIndex = 32;
            this.lblMsgOnlyInputDigit.Text = "*";
            // 
            // lblMsgCapatalize
            // 
            this.lblMsgCapatalize.AutoSize = true;
            this.lblMsgCapatalize.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgCapatalize.ForeColor = System.Drawing.Color.Red;
            this.lblMsgCapatalize.Location = new System.Drawing.Point(628, 309);
            this.lblMsgCapatalize.Name = "lblMsgCapatalize";
            this.lblMsgCapatalize.Size = new System.Drawing.Size(13, 16);
            this.lblMsgCapatalize.TabIndex = 33;
            this.lblMsgCapatalize.Text = "*";
            // 
            // lblMsgExtractDigit
            // 
            this.lblMsgExtractDigit.AutoSize = true;
            this.lblMsgExtractDigit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgExtractDigit.ForeColor = System.Drawing.Color.Red;
            this.lblMsgExtractDigit.Location = new System.Drawing.Point(628, 358);
            this.lblMsgExtractDigit.Name = "lblMsgExtractDigit";
            this.lblMsgExtractDigit.Size = new System.Drawing.Size(13, 16);
            this.lblMsgExtractDigit.TabIndex = 34;
            this.lblMsgExtractDigit.Text = "*";
            // 
            // lblMsgFormatPhone
            // 
            this.lblMsgFormatPhone.AutoSize = true;
            this.lblMsgFormatPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgFormatPhone.ForeColor = System.Drawing.Color.Red;
            this.lblMsgFormatPhone.Location = new System.Drawing.Point(628, 407);
            this.lblMsgFormatPhone.Name = "lblMsgFormatPhone";
            this.lblMsgFormatPhone.Size = new System.Drawing.Size(13, 16);
            this.lblMsgFormatPhone.TabIndex = 35;
            this.lblMsgFormatPhone.Text = "*";
            // 
            // lblMsgFormatPostal
            // 
            this.lblMsgFormatPostal.AutoSize = true;
            this.lblMsgFormatPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgFormatPostal.ForeColor = System.Drawing.Color.Red;
            this.lblMsgFormatPostal.Location = new System.Drawing.Point(628, 456);
            this.lblMsgFormatPostal.Name = "lblMsgFormatPostal";
            this.lblMsgFormatPostal.Size = new System.Drawing.Size(13, 16);
            this.lblMsgFormatPostal.TabIndex = 36;
            this.lblMsgFormatPostal.Text = "*";
            // 
            // lblMsgFormatZip
            // 
            this.lblMsgFormatZip.AutoSize = true;
            this.lblMsgFormatZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgFormatZip.ForeColor = System.Drawing.Color.Red;
            this.lblMsgFormatZip.Location = new System.Drawing.Point(628, 505);
            this.lblMsgFormatZip.Name = "lblMsgFormatZip";
            this.lblMsgFormatZip.Size = new System.Drawing.Size(13, 16);
            this.lblMsgFormatZip.TabIndex = 37;
            this.lblMsgFormatZip.Text = "*";
            // 
            // lblMsgFormatFullName
            // 
            this.lblMsgFormatFullName.AutoSize = true;
            this.lblMsgFormatFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgFormatFullName.ForeColor = System.Drawing.Color.Red;
            this.lblMsgFormatFullName.Location = new System.Drawing.Point(628, 554);
            this.lblMsgFormatFullName.Name = "lblMsgFormatFullName";
            this.lblMsgFormatFullName.Size = new System.Drawing.Size(13, 16);
            this.lblMsgFormatFullName.TabIndex = 38;
            this.lblMsgFormatFullName.Text = "*";
            // 
            // lblMsgValidatePostal
            // 
            this.lblMsgValidatePostal.AutoSize = true;
            this.lblMsgValidatePostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgValidatePostal.ForeColor = System.Drawing.Color.Red;
            this.lblMsgValidatePostal.Location = new System.Drawing.Point(628, 645);
            this.lblMsgValidatePostal.Name = "lblMsgValidatePostal";
            this.lblMsgValidatePostal.Size = new System.Drawing.Size(13, 16);
            this.lblMsgValidatePostal.TabIndex = 39;
            this.lblMsgValidatePostal.Text = "*";
            // 
            // lblMsgValidateZip
            // 
            this.lblMsgValidateZip.AutoSize = true;
            this.lblMsgValidateZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgValidateZip.ForeColor = System.Drawing.Color.Red;
            this.lblMsgValidateZip.Location = new System.Drawing.Point(628, 697);
            this.lblMsgValidateZip.Name = "lblMsgValidateZip";
            this.lblMsgValidateZip.Size = new System.Drawing.Size(13, 16);
            this.lblMsgValidateZip.TabIndex = 40;
            this.lblMsgValidateZip.Text = "*";
            // 
            // lblMsgValidatePhone
            // 
            this.lblMsgValidatePhone.AutoSize = true;
            this.lblMsgValidatePhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgValidatePhone.ForeColor = System.Drawing.Color.Red;
            this.lblMsgValidatePhone.Location = new System.Drawing.Point(628, 749);
            this.lblMsgValidatePhone.Name = "lblMsgValidatePhone";
            this.lblMsgValidatePhone.Size = new System.Drawing.Size(13, 16);
            this.lblMsgValidatePhone.TabIndex = 41;
            this.lblMsgValidatePhone.Text = "*";
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSubmit.Location = new System.Drawing.Point(347, 795);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(162, 40);
            this.btnSubmit.TabIndex = 42;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClearTxtBox
            // 
            this.btnClearTxtBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClearTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearTxtBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnClearTxtBox.Location = new System.Drawing.Point(893, 806);
            this.btnClearTxtBox.Name = "btnClearTxtBox";
            this.btnClearTxtBox.Size = new System.Drawing.Size(133, 28);
            this.btnClearTxtBox.TabIndex = 43;
            this.btnClearTxtBox.Text = "Clear Everthing";
            this.btnClearTxtBox.UseVisualStyleBackColor = false;
            this.btnClearTxtBox.Click += new System.EventHandler(this.btnClearTxtBox_Click);
            // 
            // btnPreFill
            // 
            this.btnPreFill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnPreFill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreFill.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPreFill.Location = new System.Drawing.Point(747, 806);
            this.btnPreFill.Name = "btnPreFill";
            this.btnPreFill.Size = new System.Drawing.Size(97, 28);
            this.btnPreFill.TabIndex = 44;
            this.btnPreFill.Text = "Pre-Fill";
            this.btnPreFill.UseVisualStyleBackColor = false;
            this.btnPreFill.Click += new System.EventHandler(this.btnPreFill_Click);
            // 
            // AKAssignment5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1051, 847);
            this.Controls.Add(this.btnPreFill);
            this.Controls.Add(this.btnClearTxtBox);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblMsgValidatePhone);
            this.Controls.Add(this.lblMsgValidateZip);
            this.Controls.Add(this.lblMsgValidatePostal);
            this.Controls.Add(this.lblMsgFormatFullName);
            this.Controls.Add(this.lblMsgFormatZip);
            this.Controls.Add(this.lblMsgFormatPostal);
            this.Controls.Add(this.lblMsgFormatPhone);
            this.Controls.Add(this.lblMsgExtractDigit);
            this.Controls.Add(this.lblMsgCapatalize);
            this.Controls.Add(this.lblMsgOnlyInputDigit);
            this.Controls.Add(this.lblMsgExtractNumeric);
            this.Controls.Add(this.lblMsgIsInteger);
            this.Controls.Add(this.lblMsgIsNumeric);
            this.Controls.Add(this.lblvalidatePhoneNumber);
            this.Controls.Add(this.lblValidateZipCode);
            this.Controls.Add(this.lblValidatePostalCode);
            this.Controls.Add(this.lblFullName);
            this.Controls.Add(this.lblFormatZipCode);
            this.Controls.Add(this.lblFormatPostalCode);
            this.Controls.Add(this.lblFormatPhone);
            this.Controls.Add(this.lblExtractDigits);
            this.Controls.Add(this.lblCapatalize);
            this.Controls.Add(this.lblOnlyInputDigits);
            this.Controls.Add(this.lblExtractNumeric);
            this.Controls.Add(this.lblIsInteger);
            this.Controls.Add(this.lblIsNumeric);
            this.Controls.Add(this.lblValidations);
            this.Controls.Add(this.lblStringUtilities);
            this.Controls.Add(this.lblNumericUtilities);
            this.Controls.Add(this.txtValidatePhone);
            this.Controls.Add(this.txtValidateZip);
            this.Controls.Add(this.txtValidatePostal);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.txtFormatZip);
            this.Controls.Add(this.txtFormatPostal);
            this.Controls.Add(this.txtFormatPhone);
            this.Controls.Add(this.txtExtractDigit);
            this.Controls.Add(this.txtCapatalize);
            this.Controls.Add(this.txtOnlyInputDigit);
            this.Controls.Add(this.txtExtractNumeric);
            this.Controls.Add(this.txtIsInteger);
            this.Controls.Add(this.txtIsNumeric);
            this.Name = "AKAssignment5";
            this.Text = "Utility Classes";
            this.Load += new System.EventHandler(this.AKAssignment5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIsNumeric;
        private System.Windows.Forms.TextBox txtIsInteger;
        private System.Windows.Forms.TextBox txtExtractNumeric;
        private System.Windows.Forms.TextBox txtOnlyInputDigit;
        private System.Windows.Forms.TextBox txtCapatalize;
        private System.Windows.Forms.TextBox txtExtractDigit;
        private System.Windows.Forms.TextBox txtFormatPhone;
        private System.Windows.Forms.TextBox txtFormatPostal;
        private System.Windows.Forms.TextBox txtFormatZip;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtValidatePostal;
        private System.Windows.Forms.TextBox txtValidateZip;
        private System.Windows.Forms.TextBox txtValidatePhone;
        private System.Windows.Forms.Label lblNumericUtilities;
        private System.Windows.Forms.Label lblStringUtilities;
        private System.Windows.Forms.Label lblValidations;
        private System.Windows.Forms.Label lblIsNumeric;
        private System.Windows.Forms.Label lblIsInteger;
        private System.Windows.Forms.Label lblExtractNumeric;
        private System.Windows.Forms.Label lblOnlyInputDigits;
        private System.Windows.Forms.Label lblCapatalize;
        private System.Windows.Forms.Label lblExtractDigits;
        private System.Windows.Forms.Label lblFormatPhone;
        private System.Windows.Forms.Label lblFormatPostalCode;
        private System.Windows.Forms.Label lblFormatZipCode;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblValidatePostalCode;
        private System.Windows.Forms.Label lblValidateZipCode;
        private System.Windows.Forms.Label lblvalidatePhoneNumber;
        private System.Windows.Forms.Label lblMsgIsNumeric;
        private System.Windows.Forms.Label lblMsgIsInteger;
        private System.Windows.Forms.Label lblMsgExtractNumeric;
        private System.Windows.Forms.Label lblMsgOnlyInputDigit;
        private System.Windows.Forms.Label lblMsgCapatalize;
        private System.Windows.Forms.Label lblMsgExtractDigit;
        private System.Windows.Forms.Label lblMsgFormatPhone;
        private System.Windows.Forms.Label lblMsgFormatPostal;
        private System.Windows.Forms.Label lblMsgFormatZip;
        private System.Windows.Forms.Label lblMsgFormatFullName;
        private System.Windows.Forms.Label lblMsgValidatePostal;
        private System.Windows.Forms.Label lblMsgValidateZip;
        private System.Windows.Forms.Label lblMsgValidatePhone;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClearTxtBox;
        private System.Windows.Forms.Button btnPreFill;
    }
}

