﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KGering_Assignment4
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            statusBar.Text = "Ready - No Document Open";
        }

        /// <summary>
        /// Method run to save anything to file
        /// </summary>
        public void SaveMethod()
        {
            if (ActiveMdiChild is TextDocumentForm)
            {
                DialogResult dialogResult = MessageBox.Show("Would you like to save?", "Save Text Document?", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                    {
                        saveFileDialog.InitialDirectory = Environment.CurrentDirectory;
                        if (saveFileDialog.ShowDialog() == DialogResult.OK)
                        {
                            string saveFileName = saveFileDialog.FileName;
                            Form activeChildForm = this.ActiveMdiChild;
                            TextBox txtTest = activeChildForm.ActiveControl as TextBox;

                            if (saveFileName.Contains(".txt"))
                            {
                                using (StreamWriter writer = new StreamWriter(saveFileName))
                                {
                                    writer.WriteLine(txtTest.Text);
                                }
                            }
                            else
                            {
                                saveFileName = saveFileName + ".txt";
                                using (StreamWriter writer = new StreamWriter(saveFileName))
                                {
                                    writer.WriteLine(txtTest.Text);
                                }
                            }
                        }
                    } 
                }
            }
        }

        /// <summary>
        /// creates a new text document form with the save on close event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TextDocumentForm text = new TextDocumentForm();
            text.FormClosing += AllForm_FormClosing;
            text.MdiParent = this;
            text.Show();
        }

        /// <summary>
        /// Opens a Text document from a drop down menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textDocumentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Environment.CurrentDirectory;
                openFileDialog.Filter = "txt files (*.txt)|*.txt";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string fileName = openFileDialog.FileName;
                    TextDocumentForm text = new TextDocumentForm();
                    text.MdiParent = this;
                    text.Show();
                    var fileStream = openFileDialog.OpenFile();

                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        string fileContent = reader.ReadToEnd();
                        text.TextFill(fileContent);
                    }
                }
            }
        }

        /// <summary>
        /// Opens an image document form from the drop down menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void imageDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Environment.CurrentDirectory;
                openFileDialog.Filter = "Image Files(*.jpg; *.jpeg; *.bmp;)|*.jpg; .jpeg; *.bmp;";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string fileName = openFileDialog.FileName;
                    ImageDocumentForm image = new ImageDocumentForm();
                    image.MdiParent = this;
                    image.Show();
                    image.ImageFill(fileName);
                }
            }
        }

        /// <summary>
        /// Closes the main form prompting all open documents to save
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Cascades the open documents from the drop down menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cascadeWindowsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        /// <summary>
        /// Shows the about form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutForm about = new AboutForm();
            about.ShowDialog(this.MdiParent);
        }

        /// <summary>
        /// Opens any document type supported by the program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Environment.CurrentDirectory;
                openFileDialog.Filter = "Text Files (*.txt)|*.txt|Image Files(*.jpg; *.jpeg; *.bmp;)|*.jpg; .jpeg; *.bmp;| All Files (*.*)|*.*";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;


                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string fileName = openFileDialog.FileName;
                    if (fileName.Contains(".txt"))
                    {
                        TextDocumentForm text = new TextDocumentForm();
                        text.MdiParent = this;
                        text.Show();
                        var fileStream = openFileDialog.OpenFile();

                        using (StreamReader reader = new StreamReader(fileStream))
                        {
                            string fileContent = reader.ReadToEnd();
                            text.TextFill(fileContent);
                        }
                    }

                    else
                    {
                            fileName = openFileDialog.FileName;
                            ImageDocumentForm image = new ImageDocumentForm();
                            image.MdiParent = this;
                            image.Show();
                            image.ImageFill(fileName);
                    }
                }
            }
        }

        /// <summary>
        /// Checks to see what document type is currently active and changes the status bar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_MdiChildActivate(object sender, EventArgs e)
        {
            if (ActiveMdiChild is TextDocumentForm)
            {
                statusBar.Text = "Text document active";
                saveAsToolStripMenuItem.Enabled = true;
            }
            else if (ActiveMdiChild is ImageDocumentForm)
            {
                statusBar.Text = "Image document active";
                saveAsToolStripMenuItem.Enabled = false;
            }
            else
            {
                statusBar.Text = "No active document";
            }
        }

        /// <summary>
        /// Runs the save method from drop down menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveMethod();
        }

        /// <summary>
        /// Saves text documents from the toolbar, unless its an image document
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild is TextDocumentForm)
            {
                SaveMethod();
            }
            else
            {
                MessageBox.Show("Cannot Save image documents");
            }
        }

        /// <summary>
        /// Event handler that runs the save method on all text documents
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AllForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveMethod();
        }
    }
}
