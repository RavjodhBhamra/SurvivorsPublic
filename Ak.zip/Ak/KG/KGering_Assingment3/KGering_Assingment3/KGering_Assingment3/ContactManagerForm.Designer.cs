﻿namespace KGering_Assingment3
{
    partial class ContactManagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbContactList = new System.Windows.Forms.ListBox();
            this.btnAddContact = new System.Windows.Forms.Button();
            this.pnlContactDetails = new System.Windows.Forms.Panel();
            this.grbPhone = new System.Windows.Forms.GroupBox();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.lblPhoneType = new System.Windows.Forms.Label();
            this.txtPhoneType = new System.Windows.Forms.TextBox();
            this.grbEmail = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtEmailType = new System.Windows.Forms.TextBox();
            this.lblEmailType = new System.Windows.Forms.Label();
            this.grbAddress = new System.Windows.Forms.GroupBox();
            this.lblZip = new System.Windows.Forms.Label();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.lblProvince = new System.Windows.Forms.Label();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.lblType = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.lblStreet = new System.Windows.Forms.Label();
            this.btnEditContact = new System.Windows.Forms.Button();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.pbContactPhoto = new System.Windows.Forms.PictureBox();
            this.pnlNotes = new System.Windows.Forms.Panel();
            this.grbNotes = new System.Windows.Forms.GroupBox();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.grbAddNote = new System.Windows.Forms.GroupBox();
            this.btnAddNote = new System.Windows.Forms.Button();
            this.txtAddNote = new System.Windows.Forms.TextBox();
            this.pnlContactDetails.SuspendLayout();
            this.grbPhone.SuspendLayout();
            this.grbEmail.SuspendLayout();
            this.grbAddress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbContactPhoto)).BeginInit();
            this.pnlNotes.SuspendLayout();
            this.grbNotes.SuspendLayout();
            this.grbAddNote.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbContactList
            // 
            this.lbContactList.FormattingEnabled = true;
            this.lbContactList.Location = new System.Drawing.Point(12, 12);
            this.lbContactList.Name = "lbContactList";
            this.lbContactList.Size = new System.Drawing.Size(120, 407);
            this.lbContactList.TabIndex = 0;
            this.lbContactList.SelectedIndexChanged += new System.EventHandler(this.lbContactList_SelectedIndexChanged);
            // 
            // btnAddContact
            // 
            this.btnAddContact.Location = new System.Drawing.Point(12, 425);
            this.btnAddContact.Name = "btnAddContact";
            this.btnAddContact.Size = new System.Drawing.Size(120, 23);
            this.btnAddContact.TabIndex = 1;
            this.btnAddContact.Text = "Add Contact";
            this.btnAddContact.UseVisualStyleBackColor = true;
            this.btnAddContact.Click += new System.EventHandler(this.btnAddContact_Click);
            // 
            // pnlContactDetails
            // 
            this.pnlContactDetails.Controls.Add(this.grbPhone);
            this.pnlContactDetails.Controls.Add(this.grbEmail);
            this.pnlContactDetails.Controls.Add(this.grbAddress);
            this.pnlContactDetails.Controls.Add(this.btnEditContact);
            this.pnlContactDetails.Controls.Add(this.txtLastName);
            this.pnlContactDetails.Controls.Add(this.txtFirstName);
            this.pnlContactDetails.Controls.Add(this.lblLastName);
            this.pnlContactDetails.Controls.Add(this.lblFirstName);
            this.pnlContactDetails.Controls.Add(this.pbContactPhoto);
            this.pnlContactDetails.Enabled = false;
            this.pnlContactDetails.Location = new System.Drawing.Point(139, 13);
            this.pnlContactDetails.Name = "pnlContactDetails";
            this.pnlContactDetails.Size = new System.Drawing.Size(337, 435);
            this.pnlContactDetails.TabIndex = 2;
            // 
            // grbPhone
            // 
            this.grbPhone.Controls.Add(this.txtPhoneNumber);
            this.grbPhone.Controls.Add(this.lblPhoneType);
            this.grbPhone.Controls.Add(this.txtPhoneType);
            this.grbPhone.Location = new System.Drawing.Point(14, 368);
            this.grbPhone.Name = "grbPhone";
            this.grbPhone.Size = new System.Drawing.Size(320, 57);
            this.grbPhone.TabIndex = 8;
            this.grbPhone.TabStop = false;
            this.grbPhone.Text = "Phone";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(6, 22);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.ReadOnly = true;
            this.txtPhoneNumber.Size = new System.Drawing.Size(159, 20);
            this.txtPhoneNumber.TabIndex = 14;
            // 
            // lblPhoneType
            // 
            this.lblPhoneType.AutoSize = true;
            this.lblPhoneType.Location = new System.Drawing.Point(171, 25);
            this.lblPhoneType.Name = "lblPhoneType";
            this.lblPhoneType.Size = new System.Drawing.Size(34, 13);
            this.lblPhoneType.TabIndex = 12;
            this.lblPhoneType.Text = "Type:";
            // 
            // txtPhoneType
            // 
            this.txtPhoneType.Location = new System.Drawing.Point(214, 22);
            this.txtPhoneType.Name = "txtPhoneType";
            this.txtPhoneType.ReadOnly = true;
            this.txtPhoneType.Size = new System.Drawing.Size(100, 20);
            this.txtPhoneType.TabIndex = 13;
            // 
            // grbEmail
            // 
            this.grbEmail.Controls.Add(this.txtEmail);
            this.grbEmail.Controls.Add(this.txtEmailType);
            this.grbEmail.Controls.Add(this.lblEmailType);
            this.grbEmail.Location = new System.Drawing.Point(14, 305);
            this.grbEmail.Name = "grbEmail";
            this.grbEmail.Size = new System.Drawing.Size(320, 57);
            this.grbEmail.TabIndex = 7;
            this.grbEmail.TabStop = false;
            this.grbEmail.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(6, 19);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.ReadOnly = true;
            this.txtEmail.Size = new System.Drawing.Size(159, 20);
            this.txtEmail.TabIndex = 11;
            // 
            // txtEmailType
            // 
            this.txtEmailType.Location = new System.Drawing.Point(214, 19);
            this.txtEmailType.Name = "txtEmailType";
            this.txtEmailType.ReadOnly = true;
            this.txtEmailType.Size = new System.Drawing.Size(100, 20);
            this.txtEmailType.TabIndex = 10;
            // 
            // lblEmailType
            // 
            this.lblEmailType.AutoSize = true;
            this.lblEmailType.Location = new System.Drawing.Point(171, 22);
            this.lblEmailType.Name = "lblEmailType";
            this.lblEmailType.Size = new System.Drawing.Size(34, 13);
            this.lblEmailType.TabIndex = 9;
            this.lblEmailType.Text = "Type:";
            // 
            // grbAddress
            // 
            this.grbAddress.Controls.Add(this.lblZip);
            this.grbAddress.Controls.Add(this.txtZip);
            this.grbAddress.Controls.Add(this.lblProvince);
            this.grbAddress.Controls.Add(this.txtProvince);
            this.grbAddress.Controls.Add(this.lblCity);
            this.grbAddress.Controls.Add(this.txtCity);
            this.grbAddress.Controls.Add(this.txtStreet);
            this.grbAddress.Controls.Add(this.lblType);
            this.grbAddress.Controls.Add(this.txtType);
            this.grbAddress.Controls.Add(this.lblStreet);
            this.grbAddress.Location = new System.Drawing.Point(14, 168);
            this.grbAddress.Name = "grbAddress";
            this.grbAddress.Size = new System.Drawing.Size(320, 131);
            this.grbAddress.TabIndex = 6;
            this.grbAddress.TabStop = false;
            this.grbAddress.Text = "Address";
            // 
            // lblZip
            // 
            this.lblZip.AutoSize = true;
            this.lblZip.Location = new System.Drawing.Point(219, 78);
            this.lblZip.Name = "lblZip";
            this.lblZip.Size = new System.Drawing.Size(25, 13);
            this.lblZip.TabIndex = 15;
            this.lblZip.Text = "Zip:";
            // 
            // txtZip
            // 
            this.txtZip.Location = new System.Drawing.Point(245, 75);
            this.txtZip.Name = "txtZip";
            this.txtZip.ReadOnly = true;
            this.txtZip.Size = new System.Drawing.Size(60, 20);
            this.txtZip.TabIndex = 16;
            // 
            // lblProvince
            // 
            this.lblProvince.AutoSize = true;
            this.lblProvince.Location = new System.Drawing.Point(104, 78);
            this.lblProvince.Name = "lblProvince";
            this.lblProvince.Size = new System.Drawing.Size(52, 13);
            this.lblProvince.TabIndex = 13;
            this.lblProvince.Text = "Province:";
            // 
            // txtProvince
            // 
            this.txtProvince.Location = new System.Drawing.Point(162, 75);
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.ReadOnly = true;
            this.txtProvince.Size = new System.Drawing.Size(51, 20);
            this.txtProvince.TabIndex = 14;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(13, 78);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(27, 13);
            this.lblCity.TabIndex = 11;
            this.lblCity.Text = "City:";
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(46, 75);
            this.txtCity.Name = "txtCity";
            this.txtCity.ReadOnly = true;
            this.txtCity.Size = new System.Drawing.Size(54, 20);
            this.txtCity.TabIndex = 12;
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(46, 49);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.ReadOnly = true;
            this.txtStreet.Size = new System.Drawing.Size(259, 20);
            this.txtStreet.TabIndex = 10;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(6, 26);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(34, 13);
            this.lblType.TabIndex = 7;
            this.lblType.Text = "Type:";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(46, 23);
            this.txtType.Name = "txtType";
            this.txtType.ReadOnly = true;
            this.txtType.Size = new System.Drawing.Size(99, 20);
            this.txtType.TabIndex = 9;
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Location = new System.Drawing.Point(6, 52);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(38, 13);
            this.lblStreet.TabIndex = 8;
            this.lblStreet.Text = "Street:";
            // 
            // btnEditContact
            // 
            this.btnEditContact.Location = new System.Drawing.Point(259, 124);
            this.btnEditContact.Name = "btnEditContact";
            this.btnEditContact.Size = new System.Drawing.Size(75, 23);
            this.btnEditContact.TabIndex = 5;
            this.btnEditContact.Text = "Edit Contact";
            this.btnEditContact.UseVisualStyleBackColor = true;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(196, 88);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.ReadOnly = true;
            this.txtLastName.Size = new System.Drawing.Size(138, 20);
            this.txtLastName.TabIndex = 4;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(196, 62);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.ReadOnly = true;
            this.txtFirstName.Size = new System.Drawing.Size(138, 20);
            this.txtFirstName.TabIndex = 3;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(130, 88);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(130, 62);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 1;
            this.lblFirstName.Text = "First Name:";
            // 
            // pbContactPhoto
            // 
            this.pbContactPhoto.BackgroundImage = global::KGering_Assingment3.Properties.Resources.iconfinder_b_95_4230287;
            this.pbContactPhoto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbContactPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbContactPhoto.Location = new System.Drawing.Point(14, 18);
            this.pbContactPhoto.Name = "pbContactPhoto";
            this.pbContactPhoto.Size = new System.Drawing.Size(110, 144);
            this.pbContactPhoto.TabIndex = 0;
            this.pbContactPhoto.TabStop = false;
            // 
            // pnlNotes
            // 
            this.pnlNotes.Controls.Add(this.grbNotes);
            this.pnlNotes.Controls.Add(this.grbAddNote);
            this.pnlNotes.Enabled = false;
            this.pnlNotes.Location = new System.Drawing.Point(482, 13);
            this.pnlNotes.Name = "pnlNotes";
            this.pnlNotes.Size = new System.Drawing.Size(336, 435);
            this.pnlNotes.TabIndex = 3;
            // 
            // grbNotes
            // 
            this.grbNotes.Controls.Add(this.txtNotes);
            this.grbNotes.Location = new System.Drawing.Point(3, 180);
            this.grbNotes.Name = "grbNotes";
            this.grbNotes.Size = new System.Drawing.Size(324, 245);
            this.grbNotes.TabIndex = 1;
            this.grbNotes.TabStop = false;
            this.grbNotes.Text = "Notes";
            // 
            // txtNotes
            // 
            this.txtNotes.Location = new System.Drawing.Point(6, 19);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.ReadOnly = true;
            this.txtNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNotes.Size = new System.Drawing.Size(318, 220);
            this.txtNotes.TabIndex = 2;
            // 
            // grbAddNote
            // 
            this.grbAddNote.Controls.Add(this.btnAddNote);
            this.grbAddNote.Controls.Add(this.txtAddNote);
            this.grbAddNote.Location = new System.Drawing.Point(3, 8);
            this.grbAddNote.Name = "grbAddNote";
            this.grbAddNote.Size = new System.Drawing.Size(330, 166);
            this.grbAddNote.TabIndex = 0;
            this.grbAddNote.TabStop = false;
            this.grbAddNote.Text = "Take a Note:";
            // 
            // btnAddNote
            // 
            this.btnAddNote.Location = new System.Drawing.Point(249, 126);
            this.btnAddNote.Name = "btnAddNote";
            this.btnAddNote.Size = new System.Drawing.Size(75, 23);
            this.btnAddNote.TabIndex = 1;
            this.btnAddNote.Text = "Add Note";
            this.btnAddNote.UseVisualStyleBackColor = true;
            // 
            // txtAddNote
            // 
            this.txtAddNote.Location = new System.Drawing.Point(6, 19);
            this.txtAddNote.Multiline = true;
            this.txtAddNote.Name = "txtAddNote";
            this.txtAddNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAddNote.Size = new System.Drawing.Size(318, 101);
            this.txtAddNote.TabIndex = 0;
            // 
            // ContactManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 450);
            this.Controls.Add(this.pnlNotes);
            this.Controls.Add(this.pnlContactDetails);
            this.Controls.Add(this.btnAddContact);
            this.Controls.Add(this.lbContactList);
            this.MaximizeBox = false;
            this.Name = "ContactManagerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contact Manager";
            this.pnlContactDetails.ResumeLayout(false);
            this.pnlContactDetails.PerformLayout();
            this.grbPhone.ResumeLayout(false);
            this.grbPhone.PerformLayout();
            this.grbEmail.ResumeLayout(false);
            this.grbEmail.PerformLayout();
            this.grbAddress.ResumeLayout(false);
            this.grbAddress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbContactPhoto)).EndInit();
            this.pnlNotes.ResumeLayout(false);
            this.grbNotes.ResumeLayout(false);
            this.grbNotes.PerformLayout();
            this.grbAddNote.ResumeLayout(false);
            this.grbAddNote.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnAddContact;
        private System.Windows.Forms.Panel pnlContactDetails;
        private System.Windows.Forms.PictureBox pbContactPhoto;
        private System.Windows.Forms.Panel pnlNotes;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.GroupBox grbAddress;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.Button btnEditContact;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblProvince;
        private System.Windows.Forms.TextBox txtProvince;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label lblZip;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.GroupBox grbPhone;
        private System.Windows.Forms.GroupBox grbEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtEmailType;
        private System.Windows.Forms.Label lblEmailType;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.Label lblPhoneType;
        private System.Windows.Forms.TextBox txtPhoneType;
        private System.Windows.Forms.GroupBox grbNotes;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.GroupBox grbAddNote;
        private System.Windows.Forms.Button btnAddNote;
        private System.Windows.Forms.TextBox txtAddNote;
        public System.Windows.Forms.ListBox lbContactList;
    }
}

