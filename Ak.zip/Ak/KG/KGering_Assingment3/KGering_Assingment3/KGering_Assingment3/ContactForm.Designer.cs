﻿namespace KGering_Assingment3
{
    partial class ContactForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbAddPhone = new System.Windows.Forms.GroupBox();
            this.cbAddPhoneType = new System.Windows.Forms.ComboBox();
            this.mtxtAddPhone = new System.Windows.Forms.MaskedTextBox();
            this.lblAddPhoneType = new System.Windows.Forms.Label();
            this.grbAddEmail = new System.Windows.Forms.GroupBox();
            this.cbAddEmailType = new System.Windows.Forms.ComboBox();
            this.txtAddEmail = new System.Windows.Forms.TextBox();
            this.lblAddEmailType = new System.Windows.Forms.Label();
            this.grbAddAddress = new System.Windows.Forms.GroupBox();
            this.mtxtAddZip = new System.Windows.Forms.MaskedTextBox();
            this.cbAddProvince = new System.Windows.Forms.ComboBox();
            this.cbAddAddressType = new System.Windows.Forms.ComboBox();
            this.lblAddZip = new System.Windows.Forms.Label();
            this.lblAddProvince = new System.Windows.Forms.Label();
            this.lblAddCity = new System.Windows.Forms.Label();
            this.txtAddCity = new System.Windows.Forms.TextBox();
            this.txtAddStreet = new System.Windows.Forms.TextBox();
            this.lblAddType = new System.Windows.Forms.Label();
            this.lblAddStreet = new System.Windows.Forms.Label();
            this.btnAddPhoto = new System.Windows.Forms.Button();
            this.txtAddLastName = new System.Windows.Forms.TextBox();
            this.txtAddFirstName = new System.Windows.Forms.TextBox();
            this.lblAddLastName = new System.Windows.Forms.Label();
            this.lblAddFirstName = new System.Windows.Forms.Label();
            this.pbAddContactPhoto = new System.Windows.Forms.PictureBox();
            this.btnAddContactSave = new System.Windows.Forms.Button();
            this.grbAddPhone.SuspendLayout();
            this.grbAddEmail.SuspendLayout();
            this.grbAddAddress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddContactPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // grbAddPhone
            // 
            this.grbAddPhone.Controls.Add(this.cbAddPhoneType);
            this.grbAddPhone.Controls.Add(this.mtxtAddPhone);
            this.grbAddPhone.Controls.Add(this.lblAddPhoneType);
            this.grbAddPhone.Location = new System.Drawing.Point(12, 362);
            this.grbAddPhone.Name = "grbAddPhone";
            this.grbAddPhone.Size = new System.Drawing.Size(320, 57);
            this.grbAddPhone.TabIndex = 17;
            this.grbAddPhone.TabStop = false;
            this.grbAddPhone.Text = "Phone";
            // 
            // cbAddPhoneType
            // 
            this.cbAddPhoneType.FormattingEnabled = true;
            this.cbAddPhoneType.Items.AddRange(new object[] {
            "Business",
            "Personal"});
            this.cbAddPhoneType.Location = new System.Drawing.Point(206, 21);
            this.cbAddPhoneType.Name = "cbAddPhoneType";
            this.cbAddPhoneType.Size = new System.Drawing.Size(99, 21);
            this.cbAddPhoneType.TabIndex = 13;
            // 
            // mtxtAddPhone
            // 
            this.mtxtAddPhone.Location = new System.Drawing.Point(6, 22);
            this.mtxtAddPhone.Mask = "(000) 000-0000";
            this.mtxtAddPhone.Name = "mtxtAddPhone";
            this.mtxtAddPhone.Size = new System.Drawing.Size(159, 20);
            this.mtxtAddPhone.TabIndex = 14;
            // 
            // lblAddPhoneType
            // 
            this.lblAddPhoneType.AutoSize = true;
            this.lblAddPhoneType.Location = new System.Drawing.Point(171, 25);
            this.lblAddPhoneType.Name = "lblAddPhoneType";
            this.lblAddPhoneType.Size = new System.Drawing.Size(34, 13);
            this.lblAddPhoneType.TabIndex = 12;
            this.lblAddPhoneType.Text = "Type:";
            // 
            // grbAddEmail
            // 
            this.grbAddEmail.Controls.Add(this.cbAddEmailType);
            this.grbAddEmail.Controls.Add(this.txtAddEmail);
            this.grbAddEmail.Controls.Add(this.lblAddEmailType);
            this.grbAddEmail.Location = new System.Drawing.Point(12, 299);
            this.grbAddEmail.Name = "grbAddEmail";
            this.grbAddEmail.Size = new System.Drawing.Size(320, 57);
            this.grbAddEmail.TabIndex = 16;
            this.grbAddEmail.TabStop = false;
            this.grbAddEmail.Text = "Email";
            // 
            // cbAddEmailType
            // 
            this.cbAddEmailType.FormattingEnabled = true;
            this.cbAddEmailType.Items.AddRange(new object[] {
            "Business",
            "Personal"});
            this.cbAddEmailType.Location = new System.Drawing.Point(206, 19);
            this.cbAddEmailType.Name = "cbAddEmailType";
            this.cbAddEmailType.Size = new System.Drawing.Size(99, 21);
            this.cbAddEmailType.TabIndex = 12;
            // 
            // txtAddEmail
            // 
            this.txtAddEmail.Location = new System.Drawing.Point(6, 19);
            this.txtAddEmail.Name = "txtAddEmail";
            this.txtAddEmail.Size = new System.Drawing.Size(159, 20);
            this.txtAddEmail.TabIndex = 11;
            // 
            // lblAddEmailType
            // 
            this.lblAddEmailType.AutoSize = true;
            this.lblAddEmailType.Location = new System.Drawing.Point(171, 22);
            this.lblAddEmailType.Name = "lblAddEmailType";
            this.lblAddEmailType.Size = new System.Drawing.Size(34, 13);
            this.lblAddEmailType.TabIndex = 9;
            this.lblAddEmailType.Text = "Type:";
            // 
            // grbAddAddress
            // 
            this.grbAddAddress.Controls.Add(this.mtxtAddZip);
            this.grbAddAddress.Controls.Add(this.cbAddProvince);
            this.grbAddAddress.Controls.Add(this.cbAddAddressType);
            this.grbAddAddress.Controls.Add(this.lblAddZip);
            this.grbAddAddress.Controls.Add(this.lblAddProvince);
            this.grbAddAddress.Controls.Add(this.lblAddCity);
            this.grbAddAddress.Controls.Add(this.txtAddCity);
            this.grbAddAddress.Controls.Add(this.txtAddStreet);
            this.grbAddAddress.Controls.Add(this.lblAddType);
            this.grbAddAddress.Controls.Add(this.lblAddStreet);
            this.grbAddAddress.Location = new System.Drawing.Point(12, 162);
            this.grbAddAddress.Name = "grbAddAddress";
            this.grbAddAddress.Size = new System.Drawing.Size(320, 131);
            this.grbAddAddress.TabIndex = 15;
            this.grbAddAddress.TabStop = false;
            this.grbAddAddress.Text = "Address";
            // 
            // mtxtAddZip
            // 
            this.mtxtAddZip.Location = new System.Drawing.Point(250, 75);
            this.mtxtAddZip.Mask = "L0L 0L0";
            this.mtxtAddZip.Name = "mtxtAddZip";
            this.mtxtAddZip.Size = new System.Drawing.Size(55, 20);
            this.mtxtAddZip.TabIndex = 19;
            // 
            // cbAddProvince
            // 
            this.cbAddProvince.FormattingEnabled = true;
            this.cbAddProvince.Items.AddRange(new object[] {
            "AB",
            "BC",
            "MB",
            "NB",
            "NL",
            "NT",
            "NS",
            "NU",
            "ON",
            "PE",
            "QC",
            "SK",
            "YT"});
            this.cbAddProvince.Location = new System.Drawing.Point(162, 75);
            this.cbAddProvince.Name = "cbAddProvince";
            this.cbAddProvince.Size = new System.Drawing.Size(51, 21);
            this.cbAddProvince.TabIndex = 18;
            // 
            // cbAddAddressType
            // 
            this.cbAddAddressType.FormattingEnabled = true;
            this.cbAddAddressType.Items.AddRange(new object[] {
            "Home",
            "Business"});
            this.cbAddAddressType.Location = new System.Drawing.Point(46, 23);
            this.cbAddAddressType.Name = "cbAddAddressType";
            this.cbAddAddressType.Size = new System.Drawing.Size(121, 21);
            this.cbAddAddressType.TabIndex = 17;
            // 
            // lblAddZip
            // 
            this.lblAddZip.AutoSize = true;
            this.lblAddZip.Location = new System.Drawing.Point(219, 78);
            this.lblAddZip.Name = "lblAddZip";
            this.lblAddZip.Size = new System.Drawing.Size(25, 13);
            this.lblAddZip.TabIndex = 15;
            this.lblAddZip.Text = "Zip:";
            // 
            // lblAddProvince
            // 
            this.lblAddProvince.AutoSize = true;
            this.lblAddProvince.Location = new System.Drawing.Point(104, 78);
            this.lblAddProvince.Name = "lblAddProvince";
            this.lblAddProvince.Size = new System.Drawing.Size(52, 13);
            this.lblAddProvince.TabIndex = 13;
            this.lblAddProvince.Text = "Province:";
            // 
            // lblAddCity
            // 
            this.lblAddCity.AutoSize = true;
            this.lblAddCity.Location = new System.Drawing.Point(13, 78);
            this.lblAddCity.Name = "lblAddCity";
            this.lblAddCity.Size = new System.Drawing.Size(27, 13);
            this.lblAddCity.TabIndex = 11;
            this.lblAddCity.Text = "City:";
            // 
            // txtAddCity
            // 
            this.txtAddCity.Location = new System.Drawing.Point(46, 75);
            this.txtAddCity.Name = "txtAddCity";
            this.txtAddCity.Size = new System.Drawing.Size(54, 20);
            this.txtAddCity.TabIndex = 12;
            // 
            // txtAddStreet
            // 
            this.txtAddStreet.Location = new System.Drawing.Point(46, 49);
            this.txtAddStreet.Name = "txtAddStreet";
            this.txtAddStreet.Size = new System.Drawing.Size(259, 20);
            this.txtAddStreet.TabIndex = 10;
            // 
            // lblAddType
            // 
            this.lblAddType.AutoSize = true;
            this.lblAddType.Location = new System.Drawing.Point(6, 26);
            this.lblAddType.Name = "lblAddType";
            this.lblAddType.Size = new System.Drawing.Size(34, 13);
            this.lblAddType.TabIndex = 7;
            this.lblAddType.Text = "Type:";
            // 
            // lblAddStreet
            // 
            this.lblAddStreet.AutoSize = true;
            this.lblAddStreet.Location = new System.Drawing.Point(6, 52);
            this.lblAddStreet.Name = "lblAddStreet";
            this.lblAddStreet.Size = new System.Drawing.Size(38, 13);
            this.lblAddStreet.TabIndex = 8;
            this.lblAddStreet.Text = "Street:";
            // 
            // btnAddPhoto
            // 
            this.btnAddPhoto.Location = new System.Drawing.Point(131, 119);
            this.btnAddPhoto.Name = "btnAddPhoto";
            this.btnAddPhoto.Size = new System.Drawing.Size(75, 23);
            this.btnAddPhoto.TabIndex = 14;
            this.btnAddPhoto.Text = "Add Photo";
            this.btnAddPhoto.UseVisualStyleBackColor = true;
            this.btnAddPhoto.Click += new System.EventHandler(this.btnAddPhoto_Click);
            // 
            // txtAddLastName
            // 
            this.txtAddLastName.Location = new System.Drawing.Point(194, 82);
            this.txtAddLastName.Name = "txtAddLastName";
            this.txtAddLastName.Size = new System.Drawing.Size(138, 20);
            this.txtAddLastName.TabIndex = 13;
            // 
            // txtAddFirstName
            // 
            this.txtAddFirstName.Location = new System.Drawing.Point(194, 56);
            this.txtAddFirstName.Name = "txtAddFirstName";
            this.txtAddFirstName.Size = new System.Drawing.Size(138, 20);
            this.txtAddFirstName.TabIndex = 12;
            // 
            // lblAddLastName
            // 
            this.lblAddLastName.AutoSize = true;
            this.lblAddLastName.Location = new System.Drawing.Point(128, 82);
            this.lblAddLastName.Name = "lblAddLastName";
            this.lblAddLastName.Size = new System.Drawing.Size(61, 13);
            this.lblAddLastName.TabIndex = 11;
            this.lblAddLastName.Text = "Last Name:";
            // 
            // lblAddFirstName
            // 
            this.lblAddFirstName.AutoSize = true;
            this.lblAddFirstName.Location = new System.Drawing.Point(128, 56);
            this.lblAddFirstName.Name = "lblAddFirstName";
            this.lblAddFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblAddFirstName.TabIndex = 10;
            this.lblAddFirstName.Text = "First Name:";
            // 
            // pbAddContactPhoto
            // 
            this.pbAddContactPhoto.BackgroundImage = global::KGering_Assingment3.Properties.Resources.iconfinder_b_95_4230287;
            this.pbAddContactPhoto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbAddContactPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbAddContactPhoto.InitialImage = null;
            this.pbAddContactPhoto.Location = new System.Drawing.Point(12, 12);
            this.pbAddContactPhoto.Name = "pbAddContactPhoto";
            this.pbAddContactPhoto.Size = new System.Drawing.Size(110, 144);
            this.pbAddContactPhoto.TabIndex = 9;
            this.pbAddContactPhoto.TabStop = false;
            // 
            // btnAddContactSave
            // 
            this.btnAddContactSave.Location = new System.Drawing.Point(257, 425);
            this.btnAddContactSave.Name = "btnAddContactSave";
            this.btnAddContactSave.Size = new System.Drawing.Size(75, 23);
            this.btnAddContactSave.TabIndex = 18;
            this.btnAddContactSave.Text = "Save";
            this.btnAddContactSave.UseVisualStyleBackColor = true;
            this.btnAddContactSave.Click += new System.EventHandler(this.btnAddContactSave_Click);
            // 
            // ContactForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 453);
            this.Controls.Add(this.btnAddContactSave);
            this.Controls.Add(this.grbAddPhone);
            this.Controls.Add(this.grbAddEmail);
            this.Controls.Add(this.grbAddAddress);
            this.Controls.Add(this.btnAddPhoto);
            this.Controls.Add(this.txtAddLastName);
            this.Controls.Add(this.txtAddFirstName);
            this.Controls.Add(this.lblAddLastName);
            this.Controls.Add(this.lblAddFirstName);
            this.Controls.Add(this.pbAddContactPhoto);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ContactForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Contact";
            this.grbAddPhone.ResumeLayout(false);
            this.grbAddPhone.PerformLayout();
            this.grbAddEmail.ResumeLayout(false);
            this.grbAddEmail.PerformLayout();
            this.grbAddAddress.ResumeLayout(false);
            this.grbAddAddress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddContactPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbAddPhone;
        private System.Windows.Forms.Label lblAddPhoneType;
        private System.Windows.Forms.GroupBox grbAddEmail;
        private System.Windows.Forms.TextBox txtAddEmail;
        private System.Windows.Forms.Label lblAddEmailType;
        private System.Windows.Forms.GroupBox grbAddAddress;
        private System.Windows.Forms.MaskedTextBox mtxtAddZip;
        private System.Windows.Forms.ComboBox cbAddProvince;
        private System.Windows.Forms.ComboBox cbAddAddressType;
        private System.Windows.Forms.Label lblAddZip;
        private System.Windows.Forms.Label lblAddProvince;
        private System.Windows.Forms.Label lblAddCity;
        private System.Windows.Forms.TextBox txtAddCity;
        private System.Windows.Forms.TextBox txtAddStreet;
        private System.Windows.Forms.Label lblAddType;
        private System.Windows.Forms.Label lblAddStreet;
        private System.Windows.Forms.Button btnAddPhoto;
        private System.Windows.Forms.TextBox txtAddLastName;
        private System.Windows.Forms.TextBox txtAddFirstName;
        private System.Windows.Forms.Label lblAddLastName;
        private System.Windows.Forms.Label lblAddFirstName;
        private System.Windows.Forms.PictureBox pbAddContactPhoto;
        private System.Windows.Forms.ComboBox cbAddPhoneType;
        private System.Windows.Forms.MaskedTextBox mtxtAddPhone;
        private System.Windows.Forms.ComboBox cbAddEmailType;
        private System.Windows.Forms.Button btnAddContactSave;
    }
}