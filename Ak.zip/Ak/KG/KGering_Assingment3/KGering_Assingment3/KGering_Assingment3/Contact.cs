﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KGering_Assingment3
{
    public class Contact
    {
        public string firstName = "";
        public string lastName = "";
        public string addressType = "";
        public string street = "";
        public string city = "";
        public string province = "";
        public string zip = "";
        public string email = "";
        public string emailType = "";
        public string phone = "";
        public string phoneType = "";
        public string photo;
    }
}
