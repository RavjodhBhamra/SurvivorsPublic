﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KGering_Assingment3
{
    public partial class ContactManagerForm : Form
    {
        public ContactManagerForm()
        {
            InitializeComponent();
        }

        Contact selectedContact;

        private void btnAddContact_Click(object sender, EventArgs e)
        {
            ContactForm addContactForm = new ContactForm();
            addContactForm.ShowDialog();
        }

        private void lbContactList_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFirstName.Text = selectedContact.firstName;
            txtLastName.Text = selectedContact.lastName;
            txtType.Text = selectedContact.addressType;
            txtStreet.Text = selectedContact.street;
            txtCity.Text = selectedContact.city;
            txtProvince.Text = selectedContact.province;
            txtZip.Text = selectedContact.zip;
            txtEmail.Text = selectedContact.email;
            txtEmailType.Text = selectedContact.emailType;
            txtPhoneNumber.Text = selectedContact.phone;
            txtPhoneType.Text = selectedContact.phoneType;
        }
    }
}
