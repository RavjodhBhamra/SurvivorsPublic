﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KGering_Assingment3
{
    public partial class ContactForm : Form
    {
        public ContactForm()
        {
            InitializeComponent();
        }

        Contact newContact = new Contact();

        public void btnAddContactSave_Click(object sender, EventArgs e)
        {
            newContact.firstName = txtAddFirstName.Text;
            newContact.lastName = txtAddLastName.Text;
            newContact.addressType = cbAddAddressType.Text;
            newContact.street = txtAddStreet.Text;
            newContact.city = txtAddCity.Text;
            newContact.province = cbAddProvince.Text;
            newContact.zip = mtxtAddZip.Text;
            newContact.email = txtAddEmail.Text;
            newContact.emailType = cbAddEmailType.Text;
            newContact.phone = mtxtAddPhone.Text;
            newContact.phoneType = cbAddPhoneType.Text;

            if (txtAddFirstName.Text != "" && txtAddLastName.Text != "")
            {
                ((ContactManagerForm)Owner).lbContactList.Items.Add(newContact);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("First and Last name need to be filled.");
                txtAddFirstName.Focus();
            }
        }

        private void btnAddPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialogAddPhoto = new OpenFileDialog();
            openFileDialogAddPhoto.InitialDirectory = @"C:\";
            openFileDialogAddPhoto.Filter = "Image files (*.png)|*.png|(*.jpg)|*.jpg";
            openFileDialogAddPhoto.Title = "Open image file";
            if (openFileDialogAddPhoto.ShowDialog() == DialogResult.OK)
            {
                pbAddContactPhoto.ImageLocation = openFileDialogAddPhoto.FileName;
                newContact.photo = openFileDialogAddPhoto.FileName;
                pbAddContactPhoto.BackgroundImage.Dispose();
            }
        }
    }
}
