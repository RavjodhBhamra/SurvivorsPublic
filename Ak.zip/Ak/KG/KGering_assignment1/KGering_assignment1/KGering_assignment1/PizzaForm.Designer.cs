﻿namespace KGering_assignment1
{
    partial class PizzaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlOrderStart = new System.Windows.Forms.Panel();
            this.btnOrderStart = new System.Windows.Forms.Button();
            this.txtPizzaOrder = new System.Windows.Forms.TextBox();
            this.lblOrderNumber = new System.Windows.Forms.Label();
            this.pnlPizzas = new System.Windows.Forms.Panel();
            this.pnlOrderDetails = new System.Windows.Forms.Panel();
            this.lblSpecialInstructions = new System.Windows.Forms.Label();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.txtSpecial = new System.Windows.Forms.TextBox();
            this.grbCheese = new System.Windows.Forms.GroupBox();
            this.rdbCheeseHeavy = new System.Windows.Forms.RadioButton();
            this.rdbCheeseNormal = new System.Windows.Forms.RadioButton();
            this.rdbCheeseLight = new System.Windows.Forms.RadioButton();
            this.rdbCheeseNone = new System.Windows.Forms.RadioButton();
            this.grbToppings = new System.Windows.Forms.GroupBox();
            this.chkSpinach = new System.Windows.Forms.CheckBox();
            this.chkTomato = new System.Windows.Forms.CheckBox();
            this.chkHam = new System.Windows.Forms.CheckBox();
            this.chkOlivesGreen = new System.Windows.Forms.CheckBox();
            this.chkOnion = new System.Windows.Forms.CheckBox();
            this.chkPineapple = new System.Windows.Forms.CheckBox();
            this.chkBacon = new System.Windows.Forms.CheckBox();
            this.chkOlivesBlack = new System.Windows.Forms.CheckBox();
            this.chkGreenPeppers = new System.Windows.Forms.CheckBox();
            this.chkMushrooms = new System.Windows.Forms.CheckBox();
            this.chkPepperoni = new System.Windows.Forms.CheckBox();
            this.grbSauce = new System.Windows.Forms.GroupBox();
            this.rdbSauceHeavy = new System.Windows.Forms.RadioButton();
            this.rdbSauceNormal = new System.Windows.Forms.RadioButton();
            this.rdbSauceLight = new System.Windows.Forms.RadioButton();
            this.rdbSauceNone = new System.Windows.Forms.RadioButton();
            this.pnlOrderSummary = new System.Windows.Forms.Panel();
            this.lblOrderSummary = new System.Windows.Forms.Label();
            this.btnNewOrder = new System.Windows.Forms.Button();
            this.lblorderOutput = new System.Windows.Forms.Label();
            this.pnlOrderStart.SuspendLayout();
            this.pnlOrderDetails.SuspendLayout();
            this.grbCheese.SuspendLayout();
            this.grbToppings.SuspendLayout();
            this.grbSauce.SuspendLayout();
            this.pnlOrderSummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlOrderStart
            // 
            this.pnlOrderStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOrderStart.Controls.Add(this.btnOrderStart);
            this.pnlOrderStart.Controls.Add(this.txtPizzaOrder);
            this.pnlOrderStart.Controls.Add(this.lblOrderNumber);
            this.pnlOrderStart.Location = new System.Drawing.Point(13, 13);
            this.pnlOrderStart.Name = "pnlOrderStart";
            this.pnlOrderStart.Size = new System.Drawing.Size(180, 73);
            this.pnlOrderStart.TabIndex = 0;
            // 
            // btnOrderStart
            // 
            this.btnOrderStart.Location = new System.Drawing.Point(49, 38);
            this.btnOrderStart.Name = "btnOrderStart";
            this.btnOrderStart.Size = new System.Drawing.Size(75, 23);
            this.btnOrderStart.TabIndex = 2;
            this.btnOrderStart.Text = "Start Order";
            this.btnOrderStart.UseVisualStyleBackColor = true;
            this.btnOrderStart.Click += new System.EventHandler(this.btnOrderStart_Click);
            // 
            // txtPizzaOrder
            // 
            this.txtPizzaOrder.Location = new System.Drawing.Point(114, 12);
            this.txtPizzaOrder.Name = "txtPizzaOrder";
            this.txtPizzaOrder.Size = new System.Drawing.Size(31, 20);
            this.txtPizzaOrder.TabIndex = 1;
            // 
            // lblOrderNumber
            // 
            this.lblOrderNumber.AutoSize = true;
            this.lblOrderNumber.Location = new System.Drawing.Point(12, 15);
            this.lblOrderNumber.Name = "lblOrderNumber";
            this.lblOrderNumber.Size = new System.Drawing.Size(96, 13);
            this.lblOrderNumber.TabIndex = 0;
            this.lblOrderNumber.Text = "How many Pizzas?";
            // 
            // pnlPizzas
            // 
            this.pnlPizzas.AutoScroll = true;
            this.pnlPizzas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPizzas.Location = new System.Drawing.Point(13, 92);
            this.pnlPizzas.Name = "pnlPizzas";
            this.pnlPizzas.Size = new System.Drawing.Size(180, 346);
            this.pnlPizzas.TabIndex = 1;
            // 
            // pnlOrderDetails
            // 
            this.pnlOrderDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOrderDetails.Controls.Add(this.lblSpecialInstructions);
            this.pnlOrderDetails.Controls.Add(this.btnCheckout);
            this.pnlOrderDetails.Controls.Add(this.txtSpecial);
            this.pnlOrderDetails.Controls.Add(this.grbCheese);
            this.pnlOrderDetails.Controls.Add(this.grbToppings);
            this.pnlOrderDetails.Controls.Add(this.grbSauce);
            this.pnlOrderDetails.Location = new System.Drawing.Point(199, 13);
            this.pnlOrderDetails.Name = "pnlOrderDetails";
            this.pnlOrderDetails.Size = new System.Drawing.Size(286, 426);
            this.pnlOrderDetails.TabIndex = 2;
            // 
            // lblSpecialInstructions
            // 
            this.lblSpecialInstructions.AutoSize = true;
            this.lblSpecialInstructions.Location = new System.Drawing.Point(13, 271);
            this.lblSpecialInstructions.Name = "lblSpecialInstructions";
            this.lblSpecialInstructions.Size = new System.Drawing.Size(102, 13);
            this.lblSpecialInstructions.TabIndex = 7;
            this.lblSpecialInstructions.Text = "Special Instructions:";
            // 
            // btnCheckout
            // 
            this.btnCheckout.BackColor = System.Drawing.Color.Red;
            this.btnCheckout.Enabled = false;
            this.btnCheckout.Location = new System.Drawing.Point(13, 397);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(261, 23);
            this.btnCheckout.TabIndex = 6;
            this.btnCheckout.Text = "Check Out";
            this.btnCheckout.UseVisualStyleBackColor = false;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // txtSpecial
            // 
            this.txtSpecial.Enabled = false;
            this.txtSpecial.Location = new System.Drawing.Point(13, 290);
            this.txtSpecial.Multiline = true;
            this.txtSpecial.Name = "txtSpecial";
            this.txtSpecial.Size = new System.Drawing.Size(261, 100);
            this.txtSpecial.TabIndex = 5;
            this.txtSpecial.TextChanged += new System.EventHandler(this.SpecialOrder_Check);
            // 
            // grbCheese
            // 
            this.grbCheese.Controls.Add(this.rdbCheeseHeavy);
            this.grbCheese.Controls.Add(this.rdbCheeseNormal);
            this.grbCheese.Controls.Add(this.rdbCheeseLight);
            this.grbCheese.Controls.Add(this.rdbCheeseNone);
            this.grbCheese.Enabled = false;
            this.grbCheese.Location = new System.Drawing.Point(13, 210);
            this.grbCheese.Name = "grbCheese";
            this.grbCheese.Size = new System.Drawing.Size(261, 58);
            this.grbCheese.TabIndex = 4;
            this.grbCheese.TabStop = false;
            this.grbCheese.Text = "Cheese";
            // 
            // rdbCheeseHeavy
            // 
            this.rdbCheeseHeavy.AutoSize = true;
            this.rdbCheeseHeavy.Location = new System.Drawing.Point(191, 26);
            this.rdbCheeseHeavy.Name = "rdbCheeseHeavy";
            this.rdbCheeseHeavy.Size = new System.Drawing.Size(56, 17);
            this.rdbCheeseHeavy.TabIndex = 3;
            this.rdbCheeseHeavy.Text = "Heavy";
            this.rdbCheeseHeavy.UseVisualStyleBackColor = true;
            this.rdbCheeseHeavy.CheckedChanged += new System.EventHandler(this.Cheese_Check);
            // 
            // rdbCheeseNormal
            // 
            this.rdbCheeseNormal.AutoSize = true;
            this.rdbCheeseNormal.Location = new System.Drawing.Point(127, 26);
            this.rdbCheeseNormal.Name = "rdbCheeseNormal";
            this.rdbCheeseNormal.Size = new System.Drawing.Size(58, 17);
            this.rdbCheeseNormal.TabIndex = 2;
            this.rdbCheeseNormal.Text = "Normal";
            this.rdbCheeseNormal.UseVisualStyleBackColor = true;
            this.rdbCheeseNormal.CheckedChanged += new System.EventHandler(this.Cheese_Check);
            // 
            // rdbCheeseLight
            // 
            this.rdbCheeseLight.AutoSize = true;
            this.rdbCheeseLight.Location = new System.Drawing.Point(73, 26);
            this.rdbCheeseLight.Name = "rdbCheeseLight";
            this.rdbCheeseLight.Size = new System.Drawing.Size(48, 17);
            this.rdbCheeseLight.TabIndex = 1;
            this.rdbCheeseLight.Text = "Light";
            this.rdbCheeseLight.UseVisualStyleBackColor = true;
            this.rdbCheeseLight.CheckedChanged += new System.EventHandler(this.Cheese_Check);
            // 
            // rdbCheeseNone
            // 
            this.rdbCheeseNone.AutoSize = true;
            this.rdbCheeseNone.Checked = true;
            this.rdbCheeseNone.Location = new System.Drawing.Point(12, 26);
            this.rdbCheeseNone.Name = "rdbCheeseNone";
            this.rdbCheeseNone.Size = new System.Drawing.Size(51, 17);
            this.rdbCheeseNone.TabIndex = 0;
            this.rdbCheeseNone.TabStop = true;
            this.rdbCheeseNone.Text = "None";
            this.rdbCheeseNone.UseVisualStyleBackColor = true;
            this.rdbCheeseNone.CheckedChanged += new System.EventHandler(this.Cheese_Check);
            // 
            // grbToppings
            // 
            this.grbToppings.Controls.Add(this.chkSpinach);
            this.grbToppings.Controls.Add(this.chkTomato);
            this.grbToppings.Controls.Add(this.chkHam);
            this.grbToppings.Controls.Add(this.chkOlivesGreen);
            this.grbToppings.Controls.Add(this.chkOnion);
            this.grbToppings.Controls.Add(this.chkPineapple);
            this.grbToppings.Controls.Add(this.chkBacon);
            this.grbToppings.Controls.Add(this.chkOlivesBlack);
            this.grbToppings.Controls.Add(this.chkGreenPeppers);
            this.grbToppings.Controls.Add(this.chkMushrooms);
            this.grbToppings.Controls.Add(this.chkPepperoni);
            this.grbToppings.Enabled = false;
            this.grbToppings.Location = new System.Drawing.Point(13, 88);
            this.grbToppings.Name = "grbToppings";
            this.grbToppings.Size = new System.Drawing.Size(261, 116);
            this.grbToppings.TabIndex = 4;
            this.grbToppings.TabStop = false;
            this.grbToppings.Text = "Toppings";
            // 
            // chkSpinach
            // 
            this.chkSpinach.AutoSize = true;
            this.chkSpinach.Location = new System.Drawing.Point(191, 66);
            this.chkSpinach.Name = "chkSpinach";
            this.chkSpinach.Size = new System.Drawing.Size(65, 17);
            this.chkSpinach.TabIndex = 10;
            this.chkSpinach.Text = "Spinach";
            this.chkSpinach.UseVisualStyleBackColor = true;
            this.chkSpinach.CheckedChanged += new System.EventHandler(this.Spinach_Check);
            // 
            // chkTomato
            // 
            this.chkTomato.AutoSize = true;
            this.chkTomato.Location = new System.Drawing.Point(191, 43);
            this.chkTomato.Name = "chkTomato";
            this.chkTomato.Size = new System.Drawing.Size(62, 17);
            this.chkTomato.TabIndex = 9;
            this.chkTomato.Text = "Tomato";
            this.chkTomato.UseVisualStyleBackColor = true;
            this.chkTomato.CheckedChanged += new System.EventHandler(this.Tomato_Check);
            // 
            // chkHam
            // 
            this.chkHam.AutoSize = true;
            this.chkHam.Location = new System.Drawing.Point(191, 20);
            this.chkHam.Name = "chkHam";
            this.chkHam.Size = new System.Drawing.Size(48, 17);
            this.chkHam.TabIndex = 8;
            this.chkHam.Text = "Ham";
            this.chkHam.UseVisualStyleBackColor = true;
            this.chkHam.CheckedChanged += new System.EventHandler(this.Ham_Check);
            // 
            // chkOlivesGreen
            // 
            this.chkOlivesGreen.AutoSize = true;
            this.chkOlivesGreen.Location = new System.Drawing.Point(111, 89);
            this.chkOlivesGreen.Name = "chkOlivesGreen";
            this.chkOlivesGreen.Size = new System.Drawing.Size(90, 17);
            this.chkOlivesGreen.TabIndex = 7;
            this.chkOlivesGreen.Text = "Olives, Green";
            this.chkOlivesGreen.UseVisualStyleBackColor = true;
            this.chkOlivesGreen.CheckedChanged += new System.EventHandler(this.GreenOlives_Check);
            // 
            // chkOnion
            // 
            this.chkOnion.AutoSize = true;
            this.chkOnion.Location = new System.Drawing.Point(111, 66);
            this.chkOnion.Name = "chkOnion";
            this.chkOnion.Size = new System.Drawing.Size(54, 17);
            this.chkOnion.TabIndex = 6;
            this.chkOnion.Text = "Onion";
            this.chkOnion.UseVisualStyleBackColor = true;
            this.chkOnion.CheckedChanged += new System.EventHandler(this.Onion_Check);
            // 
            // chkPineapple
            // 
            this.chkPineapple.AutoSize = true;
            this.chkPineapple.Location = new System.Drawing.Point(111, 43);
            this.chkPineapple.Name = "chkPineapple";
            this.chkPineapple.Size = new System.Drawing.Size(73, 17);
            this.chkPineapple.TabIndex = 5;
            this.chkPineapple.Text = "Pineapple";
            this.chkPineapple.UseVisualStyleBackColor = true;
            this.chkPineapple.CheckedChanged += new System.EventHandler(this.Pineapple_Check);
            // 
            // chkBacon
            // 
            this.chkBacon.AutoSize = true;
            this.chkBacon.Location = new System.Drawing.Point(111, 20);
            this.chkBacon.Name = "chkBacon";
            this.chkBacon.Size = new System.Drawing.Size(57, 17);
            this.chkBacon.TabIndex = 4;
            this.chkBacon.Text = "Bacon";
            this.chkBacon.UseVisualStyleBackColor = true;
            this.chkBacon.CheckedChanged += new System.EventHandler(this.Bacon_Check);
            // 
            // chkOlivesBlack
            // 
            this.chkOlivesBlack.AutoSize = true;
            this.chkOlivesBlack.Location = new System.Drawing.Point(12, 89);
            this.chkOlivesBlack.Name = "chkOlivesBlack";
            this.chkOlivesBlack.Size = new System.Drawing.Size(88, 17);
            this.chkOlivesBlack.TabIndex = 3;
            this.chkOlivesBlack.Text = "Olives, Black";
            this.chkOlivesBlack.UseVisualStyleBackColor = true;
            this.chkOlivesBlack.CheckedChanged += new System.EventHandler(this.BlackOlives_Check);
            // 
            // chkGreenPeppers
            // 
            this.chkGreenPeppers.AutoSize = true;
            this.chkGreenPeppers.Location = new System.Drawing.Point(12, 66);
            this.chkGreenPeppers.Name = "chkGreenPeppers";
            this.chkGreenPeppers.Size = new System.Drawing.Size(97, 17);
            this.chkGreenPeppers.TabIndex = 2;
            this.chkGreenPeppers.Text = "Green Peppers";
            this.chkGreenPeppers.UseVisualStyleBackColor = true;
            this.chkGreenPeppers.CheckedChanged += new System.EventHandler(this.GreenPepper_Check);
            // 
            // chkMushrooms
            // 
            this.chkMushrooms.AutoSize = true;
            this.chkMushrooms.Location = new System.Drawing.Point(12, 43);
            this.chkMushrooms.Name = "chkMushrooms";
            this.chkMushrooms.Size = new System.Drawing.Size(80, 17);
            this.chkMushrooms.TabIndex = 1;
            this.chkMushrooms.Text = "Mushrooms";
            this.chkMushrooms.UseVisualStyleBackColor = true;
            this.chkMushrooms.CheckedChanged += new System.EventHandler(this.Mushroom_Check);
            // 
            // chkPepperoni
            // 
            this.chkPepperoni.AutoSize = true;
            this.chkPepperoni.Location = new System.Drawing.Point(12, 20);
            this.chkPepperoni.Name = "chkPepperoni";
            this.chkPepperoni.Size = new System.Drawing.Size(74, 17);
            this.chkPepperoni.TabIndex = 0;
            this.chkPepperoni.Text = "Pepperoni";
            this.chkPepperoni.UseVisualStyleBackColor = true;
            this.chkPepperoni.CheckedChanged += new System.EventHandler(this.Pepperoni_Check);
            // 
            // grbSauce
            // 
            this.grbSauce.Controls.Add(this.rdbSauceHeavy);
            this.grbSauce.Controls.Add(this.rdbSauceNormal);
            this.grbSauce.Controls.Add(this.rdbSauceLight);
            this.grbSauce.Controls.Add(this.rdbSauceNone);
            this.grbSauce.Enabled = false;
            this.grbSauce.Location = new System.Drawing.Point(13, 15);
            this.grbSauce.Name = "grbSauce";
            this.grbSauce.Size = new System.Drawing.Size(261, 58);
            this.grbSauce.TabIndex = 0;
            this.grbSauce.TabStop = false;
            this.grbSauce.Text = "Sauce";
            // 
            // rdbSauceHeavy
            // 
            this.rdbSauceHeavy.AutoSize = true;
            this.rdbSauceHeavy.Location = new System.Drawing.Point(191, 26);
            this.rdbSauceHeavy.Name = "rdbSauceHeavy";
            this.rdbSauceHeavy.Size = new System.Drawing.Size(56, 17);
            this.rdbSauceHeavy.TabIndex = 3;
            this.rdbSauceHeavy.Text = "Heavy";
            this.rdbSauceHeavy.UseVisualStyleBackColor = true;
            this.rdbSauceHeavy.CheckedChanged += new System.EventHandler(this.Sauce_Check);
            // 
            // rdbSauceNormal
            // 
            this.rdbSauceNormal.AutoSize = true;
            this.rdbSauceNormal.Location = new System.Drawing.Point(127, 26);
            this.rdbSauceNormal.Name = "rdbSauceNormal";
            this.rdbSauceNormal.Size = new System.Drawing.Size(58, 17);
            this.rdbSauceNormal.TabIndex = 2;
            this.rdbSauceNormal.Text = "Normal";
            this.rdbSauceNormal.UseVisualStyleBackColor = true;
            this.rdbSauceNormal.CheckedChanged += new System.EventHandler(this.Sauce_Check);
            // 
            // rdbSauceLight
            // 
            this.rdbSauceLight.AutoSize = true;
            this.rdbSauceLight.Location = new System.Drawing.Point(73, 26);
            this.rdbSauceLight.Name = "rdbSauceLight";
            this.rdbSauceLight.Size = new System.Drawing.Size(48, 17);
            this.rdbSauceLight.TabIndex = 1;
            this.rdbSauceLight.Text = "Light";
            this.rdbSauceLight.UseVisualStyleBackColor = true;
            this.rdbSauceLight.CheckedChanged += new System.EventHandler(this.Sauce_Check);
            // 
            // rdbSauceNone
            // 
            this.rdbSauceNone.AutoSize = true;
            this.rdbSauceNone.Checked = true;
            this.rdbSauceNone.Location = new System.Drawing.Point(12, 26);
            this.rdbSauceNone.Name = "rdbSauceNone";
            this.rdbSauceNone.Size = new System.Drawing.Size(51, 17);
            this.rdbSauceNone.TabIndex = 0;
            this.rdbSauceNone.TabStop = true;
            this.rdbSauceNone.Text = "None";
            this.rdbSauceNone.UseVisualStyleBackColor = true;
            this.rdbSauceNone.CheckedChanged += new System.EventHandler(this.Sauce_Check);
            // 
            // pnlOrderSummary
            // 
            this.pnlOrderSummary.AutoScroll = true;
            this.pnlOrderSummary.Controls.Add(this.lblorderOutput);
            this.pnlOrderSummary.Controls.Add(this.lblOrderSummary);
            this.pnlOrderSummary.Location = new System.Drawing.Point(492, 12);
            this.pnlOrderSummary.Name = "pnlOrderSummary";
            this.pnlOrderSummary.Size = new System.Drawing.Size(260, 392);
            this.pnlOrderSummary.TabIndex = 3;
            // 
            // lblOrderSummary
            // 
            this.lblOrderSummary.AutoSize = true;
            this.lblOrderSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderSummary.Location = new System.Drawing.Point(3, 1);
            this.lblOrderSummary.Name = "lblOrderSummary";
            this.lblOrderSummary.Size = new System.Drawing.Size(231, 35);
            this.lblOrderSummary.TabIndex = 0;
            this.lblOrderSummary.Text = "Order Summary";
            // 
            // btnNewOrder
            // 
            this.btnNewOrder.BackColor = System.Drawing.Color.ForestGreen;
            this.btnNewOrder.Enabled = false;
            this.btnNewOrder.Location = new System.Drawing.Point(492, 411);
            this.btnNewOrder.Name = "btnNewOrder";
            this.btnNewOrder.Size = new System.Drawing.Size(260, 23);
            this.btnNewOrder.TabIndex = 4;
            this.btnNewOrder.Text = "Start New Order";
            this.btnNewOrder.UseVisualStyleBackColor = false;
            this.btnNewOrder.Click += new System.EventHandler(this.btnNewOrder_Click);
            // 
            // lblorderOutput
            // 
            this.lblorderOutput.AutoSize = true;
            this.lblorderOutput.Location = new System.Drawing.Point(9, 40);
            this.lblorderOutput.Name = "lblorderOutput";
            this.lblorderOutput.Size = new System.Drawing.Size(0, 13);
            this.lblorderOutput.TabIndex = 1;
            // 
            // PizzaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 450);
            this.Controls.Add(this.btnNewOrder);
            this.Controls.Add(this.pnlOrderSummary);
            this.Controls.Add(this.pnlOrderDetails);
            this.Controls.Add(this.pnlPizzas);
            this.Controls.Add(this.pnlOrderStart);
            this.Name = "PizzaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pizza Order Form";
            this.pnlOrderStart.ResumeLayout(false);
            this.pnlOrderStart.PerformLayout();
            this.pnlOrderDetails.ResumeLayout(false);
            this.pnlOrderDetails.PerformLayout();
            this.grbCheese.ResumeLayout(false);
            this.grbCheese.PerformLayout();
            this.grbToppings.ResumeLayout(false);
            this.grbToppings.PerformLayout();
            this.grbSauce.ResumeLayout(false);
            this.grbSauce.PerformLayout();
            this.pnlOrderSummary.ResumeLayout(false);
            this.pnlOrderSummary.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlOrderStart;
        private System.Windows.Forms.Panel pnlPizzas;
        private System.Windows.Forms.Panel pnlOrderDetails;
        private System.Windows.Forms.Button btnOrderStart;
        private System.Windows.Forms.TextBox txtPizzaOrder;
        private System.Windows.Forms.Label lblOrderNumber;
        private System.Windows.Forms.GroupBox grbSauce;
        private System.Windows.Forms.RadioButton rdbSauceHeavy;
        private System.Windows.Forms.RadioButton rdbSauceNormal;
        private System.Windows.Forms.RadioButton rdbSauceLight;
        private System.Windows.Forms.RadioButton rdbSauceNone;
        private System.Windows.Forms.GroupBox grbCheese;
        private System.Windows.Forms.RadioButton rdbCheeseHeavy;
        private System.Windows.Forms.RadioButton rdbCheeseNormal;
        private System.Windows.Forms.RadioButton rdbCheeseLight;
        private System.Windows.Forms.RadioButton rdbCheeseNone;
        private System.Windows.Forms.GroupBox grbToppings;
        private System.Windows.Forms.CheckBox chkSpinach;
        private System.Windows.Forms.CheckBox chkTomato;
        private System.Windows.Forms.CheckBox chkHam;
        private System.Windows.Forms.CheckBox chkOlivesGreen;
        private System.Windows.Forms.CheckBox chkOnion;
        private System.Windows.Forms.CheckBox chkPineapple;
        private System.Windows.Forms.CheckBox chkBacon;
        private System.Windows.Forms.CheckBox chkOlivesBlack;
        private System.Windows.Forms.CheckBox chkGreenPeppers;
        private System.Windows.Forms.CheckBox chkMushrooms;
        private System.Windows.Forms.CheckBox chkPepperoni;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.TextBox txtSpecial;
        private System.Windows.Forms.Label lblSpecialInstructions;
        private System.Windows.Forms.Panel pnlOrderSummary;
        private System.Windows.Forms.Label lblOrderSummary;
        private System.Windows.Forms.Button btnNewOrder;
        private System.Windows.Forms.Label lblorderOutput;
    }
}

