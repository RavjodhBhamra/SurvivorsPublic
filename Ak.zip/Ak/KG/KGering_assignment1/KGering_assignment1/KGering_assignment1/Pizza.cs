﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KGering_assignment1
{
    /// <summary>
    /// The pizza class used for storing information
    /// </summary>
    public class Pizza
    {
        public string sauce = "None";
        public bool pepperoni;
        public bool mushrooms;
        public bool greenPeppers;
        public bool blackOlives;
        public bool bacon;
        public bool pineapple;
        public bool onion;
        public bool greenOlives;
        public bool ham;
        public bool tomato;
        public bool spinach;
        public string cheese = "None";
        public string specialInstructions;

        /// <summary>
        /// order details method for simplistic presentation
        /// </summary>
        /// <param name="i">Accepts an int for the counter to dynamically change pizza number</param>
        /// <returns></returns>
        public string OrderDetails(int i)
        {
            StringBuilder orderDetails = new StringBuilder();

            orderDetails.AppendLine($"Pizza {i}:");
            orderDetails.AppendLine($"Sauce: {sauce}");
            orderDetails.AppendLine("Toppings: ");
            if (pepperoni)
            {
                orderDetails.Append("    -Pepperoni\t");
            }
            if (bacon)
            {
                orderDetails.Append("    -Bacon\t");
            }
            if (ham)
            {
                orderDetails.Append("    -Ham\r\n");
            }
            if (mushrooms)
            {
                orderDetails.Append("    -Mushrooms\t");
            }
            if (pineapple)
            {
                orderDetails.Append("    -Pineapple\t");
            }
            if (tomato)
            {
                orderDetails.Append("    -Tomato\r\n");
            }
            if (greenPeppers)
            {
                orderDetails.Append("    -Green Peppers\t");
            }
            if (onion)
            {
                orderDetails.Append("    -Onion\t");
            }
            if (spinach)
            {
                orderDetails.Append("    -Spinach\r\n");
            }
            if (blackOlives)
            {
                orderDetails.Append("    -Black Olives\t");
            }
            if (greenOlives)
            {
                orderDetails.Append("    -Green Olives");
            }
            orderDetails.AppendLine();
            orderDetails.AppendLine($"Cheese: {cheese}");
            orderDetails.AppendLine($"Special instructions: {specialInstructions}");

            return orderDetails.ToString();
        }
    }
}
