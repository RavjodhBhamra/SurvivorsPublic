﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KGering_assignment1
{
    public partial class PizzaForm : Form
    {
        public PizzaForm()
        {
            InitializeComponent();
        }

        //Active pizza object
        Pizza selectedPizza;

        /// <summary>
        /// Method to create radio pizza boxes dynamically
        /// </summary>
        /// <param name="pizzaNumber">accepts an int for the counter</param>
        public void pizzaRadioCreate(int pizzaNumber)
        {
            for (int i = 0; i < pizzaNumber; i++)
            {
                RadioButton pizzaRadio = new RadioButton();
                pizzaRadio.Appearance = Appearance.Button;
                pizzaRadio.Location = new Point(3, (i*150));
                pizzaRadio.Size = new Size(150, 150);
                pizzaRadio.Tag = new Pizza();
                pizzaRadio.Name = $"pizza{i}";
                pizzaRadio.Click += PizzaSelect;
                pnlPizzas.Controls.Add(pizzaRadio);
            }
        }


        /// <summary>
        /// Starts the order and runs the radio button creator method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOrderStart_Click(object sender, EventArgs e)
        {
            int pizzaNumber = int.Parse(txtPizzaOrder.Text);

            if (pizzaNumber <= 9 && pizzaNumber >= 1)
            {
                pizzaRadioCreate(pizzaNumber);
                grbCheese.Enabled = true;
                grbSauce.Enabled = true;
                grbToppings.Enabled = true;
                txtSpecial.Enabled = true;
                btnCheckout.Enabled = true;
                btnOrderStart.Enabled = false;
            }

            else
            {
                MessageBox.Show("You didn't enter a number between 1 and 9");
            }
        }

        /// <summary>
        /// event created for radio button click on the dynamic pizzas
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PizzaSelect(object sender, EventArgs e)
        {
            RadioButton pizzaRadio = (RadioButton)sender;
            selectedPizza = (Pizza)pizzaRadio.Tag;
            UpdateToppings();
        }

        /// <summary>
        /// Method run to check and update the current pizza
        /// </summary>
        private void UpdateToppings()
        {
            switch (selectedPizza.sauce)
            {
                case "None":
                    rdbSauceNone.Checked = true;
                    break;
                case "Light":
                    rdbSauceLight.Checked = true;
                    break;
                case "Normal":
                    rdbSauceNormal.Checked = true;
                    break;
                case "Heavy":
                    rdbSauceHeavy.Checked = true;
                    break;
            }

            chkBacon.Checked = selectedPizza.bacon;
            chkGreenPeppers.Checked = selectedPizza.greenPeppers;
            chkHam.Checked = selectedPizza.ham;
            chkMushrooms.Checked = selectedPizza.mushrooms;
            chkOlivesBlack.Checked = selectedPizza.blackOlives;
            chkOlivesGreen.Checked = selectedPizza.greenOlives;
            chkOnion.Checked = selectedPizza.onion;
            chkPepperoni.Checked = selectedPizza.pepperoni;
            chkPineapple.Checked = selectedPizza.pineapple;
            chkSpinach.Checked = selectedPizza.spinach;
            chkTomato.Checked = selectedPizza.tomato;

            switch (selectedPizza.cheese)
            {
                case "None":
                    rdbCheeseNone.Checked = true;
                    break;
                case "Light":
                    rdbCheeseLight.Checked = true;
                    break;
                case "Normal":
                    rdbCheeseNormal.Checked = true;
                    break;
                case "Heavy":
                    rdbCheeseHeavy.Checked = true;
                    break;
            }

            txtSpecial.Text = selectedPizza.specialInstructions;
        }

        /// <summary>
        /// This whole region is events updating and checking changes in toppings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region
        private void Pepperoni_Check(object sender, EventArgs e)
        {
            selectedPizza.pepperoni = ((CheckBox)sender).Checked;
        }

        private void Mushroom_Check(object sender, EventArgs e)
        {
            selectedPizza.mushrooms = ((CheckBox)sender).Checked;
        }

        private void GreenPepper_Check(object sender, EventArgs e)
        {
            selectedPizza.greenPeppers = ((CheckBox)sender).Checked;
        }

        private void BlackOlives_Check(object sender, EventArgs e)
        {
            selectedPizza.blackOlives = ((CheckBox)sender).Checked;
        }

        private void Bacon_Check(object sender, EventArgs e)
        {
            selectedPizza.bacon = ((CheckBox)sender).Checked;
        }

        private void Pineapple_Check(object sender, EventArgs e)
        {
            selectedPizza.pineapple = ((CheckBox)sender).Checked;
        }

        private void Onion_Check(object sender, EventArgs e)
        {
            selectedPizza.onion = ((CheckBox)sender).Checked;
        }

        private void GreenOlives_Check(object sender, EventArgs e)
        {
            selectedPizza.greenOlives = ((CheckBox)sender).Checked;
        }

        private void Ham_Check(object sender, EventArgs e)
        {
            selectedPizza.ham = ((CheckBox)sender).Checked;
        }

        private void Tomato_Check(object sender, EventArgs e)
        {
            selectedPizza.tomato = ((CheckBox)sender).Checked;
        }

        private void Spinach_Check(object sender, EventArgs e)
        {
            selectedPizza.spinach = ((CheckBox)sender).Checked;
        }

        private void Sauce_Check(object sender, EventArgs e)
        {
            selectedPizza.sauce = ((RadioButton)sender).Text;
        }

        private void Cheese_Check(object sender, EventArgs e)
        {
            selectedPizza.cheese = ((RadioButton)sender).Text;
        }

        private void SpecialOrder_Check(object sender, EventArgs e)
        {
            selectedPizza.specialInstructions = txtSpecial.Text;
        }
        #endregion

        /// <summary>
        /// Displays all the pizzas
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCheckout_Click(object sender, EventArgs e)
        {
            btnNewOrder.Enabled = true;
            pnlOrderDetails.Enabled = false;
            pnlOrderStart.Enabled = false;
            pnlPizzas.Enabled = false;
            int pizzaCount = 0;

            StringBuilder orderDetails = new StringBuilder();

            foreach (Control control in pnlPizzas.Controls)
            {
                pizzaCount++;
                RadioButton radioButton = (RadioButton)control;
                Pizza pizza = (Pizza)radioButton.Tag;
                orderDetails.AppendLine(pizza.OrderDetails(pizzaCount));
            }

            lblorderOutput.Text += orderDetails.ToString();
        }

        /// <summary>
        /// disposes of the current form and brings up a new one
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            PizzaForm newForm = new PizzaForm();
            newForm.Show();
            this.Dispose(false);
        }
    }
}
