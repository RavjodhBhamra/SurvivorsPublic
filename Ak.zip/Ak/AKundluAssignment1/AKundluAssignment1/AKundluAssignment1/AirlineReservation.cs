﻿




/*
 * Purpose : Assignment #1
 * 
 * Purpose ID : To create Airplane Seat Reservation system
 * 
 * Revision History : Created by Ankit Kundlu on 5th Feb 2018.
 * 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AKundluAssignment1
{
    public partial class AirlineReservation : Form
    {

        string[,] arrayOfSeats = new string[5, 3];
        string[] arrayWaitingList = new string[10];
        int waitListNumber = 0;
        string passengerName;

        private void MovingWaitingCustomer()
        {
            richTextBox1.Clear();

            for (int i = 0; i < arrayWaitingList.Length - 1; i++)
            {
                arrayWaitingList[i] = arrayWaitingList[i + 1];
            }
        }

        public AirlineReservation()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            passengerName = textBoxName.Text;
            int column = listBox1.SelectedIndex;
            int row = listBox2.SelectedIndex;

            if (passengerName == null || passengerName == "")
            {
                MessageBox.Show("Please enter the name of the passenger");
            }
            else if (column == -1)
            {
                MessageBox.Show("Please select a column");

            }
            else if (row == -1)
            {
                MessageBox.Show("Please select a row");
            }
            else
            {
                arrayOfSeats[column, row] = passengerName;
                MessageBox.Show("Passenger is successfully added to the waiting list");
            }
            arrayWaitingList[waitListNumber] = passengerName;
            waitListNumber++;
            richTextBox1.Clear();

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ButtonShowAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    richTextBox1.Text += "[" + i + "," + j + "]" + arrayOfSeats[i, j] + "\n";
                }
            }

        }

        private void ButtonShowWaitingList_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                richTextBox1.Text += "[" + i + "]" + arrayWaitingList[i] + "\n";
            }
        }

        private void buttonBook_Click(object sender, EventArgs e)
        {
            int column = listBox1.SelectedIndex;
            int row = listBox2.SelectedIndex;


            passengerName = textBoxName.Text;
            richTextBox1.Clear();

            if (passengerName == null || passengerName == "")
            {
                MessageBox.Show("Please enter the name of the passenger");
            }
            else if (column == -1)
            {
                MessageBox.Show("Please select a column");

            }
            else if (row == -1)
            {
                MessageBox.Show("Please select a row");
            }

            else
            {
                arrayOfSeats[column, row] = passengerName;
                MessageBox.Show("Passenger is successfully added");
            }

        }

        private void ButtonFillAll_Click(object sender, EventArgs e)
        {
            passengerName = textBoxName.Text;
            richTextBox1.Clear();
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arrayOfSeats[i, j] = passengerName;
                }
            }

        }



        private void buttonStatus_Click(object sender, EventArgs e)
        {
            int column = listBox1.SelectedIndex;
            int row = listBox2.SelectedIndex;
            passengerName = textBoxName.Text;
            if (arrayOfSeats[column, row] == null || arrayOfSeats[column, row] == "")
            {
                textBoxStatus.Text = "Available";
            }
            else
            {
                textBoxStatus.Text = "Occupied";
            }

        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            int column = listBox1.SelectedIndex;
            int row = listBox2.SelectedIndex;
            passengerName = textBoxName.Text;
            if (passengerName == null || passengerName == "")
            {
                MessageBox.Show("Please enter the name of the passenger");
            }
            else if (column == -1)
            {
                MessageBox.Show("Please select a column");

            }
            else if (row == -1)
            {
                MessageBox.Show("Please select a row");
            }
            richTextBox1.Clear();
            if (arrayOfSeats[column, row] == null || arrayOfSeats[column, row] == "")
            {
                MessageBox.Show("This seat is already free");
            }
            else
            {
                arrayOfSeats[column, row] = null;
                MessageBox.Show("You have cancelled the seat successfully");
            }
            arrayOfSeats[column, row] = arrayWaitingList[0];
            MovingWaitingCustomer();


        }

    }
    }

