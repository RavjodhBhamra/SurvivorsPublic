﻿namespace AKundluAssignment1
{
    partial class AirlineReservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Seat00 = new System.Windows.Forms.Button();
            this.Seat01 = new System.Windows.Forms.Button();
            this.Seat02 = new System.Windows.Forms.Button();
            this.Seat12 = new System.Windows.Forms.Button();
            this.Seat11 = new System.Windows.Forms.Button();
            this.Seat10 = new System.Windows.Forms.Button();
            this.Seat22 = new System.Windows.Forms.Button();
            this.Seat21 = new System.Windows.Forms.Button();
            this.Seat20 = new System.Windows.Forms.Button();
            this.Seat32 = new System.Windows.Forms.Button();
            this.Seat31 = new System.Windows.Forms.Button();
            this.Seat30 = new System.Windows.Forms.Button();
            this.Seat42 = new System.Windows.Forms.Button();
            this.Seat41 = new System.Windows.Forms.Button();
            this.Seat40 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxStatus = new System.Windows.Forms.TextBox();
            this.labelColumn0 = new System.Windows.Forms.Label();
            this.labelColumn1 = new System.Windows.Forms.Label();
            this.labelCoulmn2 = new System.Windows.Forms.Label();
            this.labelRow0 = new System.Windows.Forms.Label();
            this.labelRow1 = new System.Windows.Forms.Label();
            this.labelRow2 = new System.Windows.Forms.Label();
            this.labelRow3 = new System.Windows.Forms.Label();
            this.labelRow4 = new System.Windows.Forms.Label();
            this.labelSeatReservationAndCancellation = new System.Windows.Forms.Label();
            this.buttonStatus = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.buttonBook = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.btnAddToWaitingList = new System.Windows.Forms.Button();
            this.ButtonShowAll = new System.Windows.Forms.Button();
            this.ButtonShowWaitingList = new System.Windows.Forms.Button();
            this.ButtonFillAll = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // Seat00
            // 
            this.Seat00.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat00.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat00.Location = new System.Drawing.Point(37, 59);
            this.Seat00.Name = "Seat00";
            this.Seat00.Size = new System.Drawing.Size(59, 51);
            this.Seat00.TabIndex = 0;
            this.Seat00.Text = "0-0";
            this.Seat00.UseVisualStyleBackColor = false;
            // 
            // Seat01
            // 
            this.Seat01.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat01.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat01.Location = new System.Drawing.Point(104, 59);
            this.Seat01.Name = "Seat01";
            this.Seat01.Size = new System.Drawing.Size(59, 51);
            this.Seat01.TabIndex = 1;
            this.Seat01.Text = "0-1";
            this.Seat01.UseVisualStyleBackColor = false;
            // 
            // Seat02
            // 
            this.Seat02.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat02.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat02.Location = new System.Drawing.Point(170, 59);
            this.Seat02.Name = "Seat02";
            this.Seat02.Size = new System.Drawing.Size(59, 51);
            this.Seat02.TabIndex = 2;
            this.Seat02.Text = "0-2";
            this.Seat02.UseVisualStyleBackColor = false;
            // 
            // Seat12
            // 
            this.Seat12.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat12.Location = new System.Drawing.Point(170, 116);
            this.Seat12.Name = "Seat12";
            this.Seat12.Size = new System.Drawing.Size(59, 51);
            this.Seat12.TabIndex = 5;
            this.Seat12.Text = "1-2";
            this.Seat12.UseVisualStyleBackColor = false;
            // 
            // Seat11
            // 
            this.Seat11.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat11.Location = new System.Drawing.Point(104, 116);
            this.Seat11.Name = "Seat11";
            this.Seat11.Size = new System.Drawing.Size(59, 51);
            this.Seat11.TabIndex = 4;
            this.Seat11.Text = "1-1";
            this.Seat11.UseVisualStyleBackColor = false;
            // 
            // Seat10
            // 
            this.Seat10.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat10.Location = new System.Drawing.Point(37, 116);
            this.Seat10.Name = "Seat10";
            this.Seat10.Size = new System.Drawing.Size(59, 51);
            this.Seat10.TabIndex = 3;
            this.Seat10.Text = "1-0";
            this.Seat10.UseVisualStyleBackColor = false;
            // 
            // Seat22
            // 
            this.Seat22.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat22.Location = new System.Drawing.Point(170, 173);
            this.Seat22.Name = "Seat22";
            this.Seat22.Size = new System.Drawing.Size(59, 51);
            this.Seat22.TabIndex = 8;
            this.Seat22.Text = "2-2";
            this.Seat22.UseVisualStyleBackColor = false;
            // 
            // Seat21
            // 
            this.Seat21.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat21.Location = new System.Drawing.Point(104, 173);
            this.Seat21.Name = "Seat21";
            this.Seat21.Size = new System.Drawing.Size(59, 51);
            this.Seat21.TabIndex = 7;
            this.Seat21.Text = "2-1";
            this.Seat21.UseVisualStyleBackColor = false;
            // 
            // Seat20
            // 
            this.Seat20.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat20.Location = new System.Drawing.Point(37, 173);
            this.Seat20.Name = "Seat20";
            this.Seat20.Size = new System.Drawing.Size(59, 51);
            this.Seat20.TabIndex = 6;
            this.Seat20.Text = "2-0";
            this.Seat20.UseVisualStyleBackColor = false;
            // 
            // Seat32
            // 
            this.Seat32.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat32.Location = new System.Drawing.Point(170, 230);
            this.Seat32.Name = "Seat32";
            this.Seat32.Size = new System.Drawing.Size(59, 51);
            this.Seat32.TabIndex = 11;
            this.Seat32.Text = "3-2";
            this.Seat32.UseVisualStyleBackColor = false;
            // 
            // Seat31
            // 
            this.Seat31.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat31.Location = new System.Drawing.Point(104, 230);
            this.Seat31.Name = "Seat31";
            this.Seat31.Size = new System.Drawing.Size(59, 51);
            this.Seat31.TabIndex = 10;
            this.Seat31.Text = "3-1";
            this.Seat31.UseVisualStyleBackColor = false;
            // 
            // Seat30
            // 
            this.Seat30.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat30.Location = new System.Drawing.Point(37, 230);
            this.Seat30.Name = "Seat30";
            this.Seat30.Size = new System.Drawing.Size(59, 51);
            this.Seat30.TabIndex = 9;
            this.Seat30.Text = "3-0";
            this.Seat30.UseVisualStyleBackColor = false;
            // 
            // Seat42
            // 
            this.Seat42.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat42.Location = new System.Drawing.Point(170, 287);
            this.Seat42.Name = "Seat42";
            this.Seat42.Size = new System.Drawing.Size(59, 51);
            this.Seat42.TabIndex = 14;
            this.Seat42.Text = "4-2";
            this.Seat42.UseVisualStyleBackColor = false;
            // 
            // Seat41
            // 
            this.Seat41.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat41.Location = new System.Drawing.Point(104, 287);
            this.Seat41.Name = "Seat41";
            this.Seat41.Size = new System.Drawing.Size(59, 51);
            this.Seat41.TabIndex = 13;
            this.Seat41.Text = "4-1";
            this.Seat41.UseVisualStyleBackColor = false;
            // 
            // Seat40
            // 
            this.Seat40.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Seat40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seat40.Location = new System.Drawing.Point(37, 287);
            this.Seat40.Name = "Seat40";
            this.Seat40.Size = new System.Drawing.Size(59, 51);
            this.Seat40.TabIndex = 12;
            this.Seat40.Text = "4-0";
            this.Seat40.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 22);
            this.label1.TabIndex = 15;
            this.label1.Text = "Seat Arrangement";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(385, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 16;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(271, 91);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(53, 15);
            this.labelName.TabIndex = 17;
            this.labelName.Text = "Name :";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(339, 82);
            this.textBoxName.Multiline = true;
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(291, 28);
            this.textBoxName.TabIndex = 18;
            
            // 
            // textBoxStatus
            // 
            this.textBoxStatus.Location = new System.Drawing.Point(497, 173);
            this.textBoxStatus.Multiline = true;
            this.textBoxStatus.Name = "textBoxStatus";
            this.textBoxStatus.Size = new System.Drawing.Size(133, 31);
            this.textBoxStatus.TabIndex = 19;
            // 
            // labelColumn0
            // 
            this.labelColumn0.AutoSize = true;
            this.labelColumn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelColumn0.Location = new System.Drawing.Point(56, 43);
            this.labelColumn0.Name = "labelColumn0";
            this.labelColumn0.Size = new System.Drawing.Size(14, 13);
            this.labelColumn0.TabIndex = 20;
            this.labelColumn0.Text = "0";
            
            // 
            // labelColumn1
            // 
            this.labelColumn1.AutoSize = true;
            this.labelColumn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelColumn1.Location = new System.Drawing.Point(126, 43);
            this.labelColumn1.Name = "labelColumn1";
            this.labelColumn1.Size = new System.Drawing.Size(14, 13);
            this.labelColumn1.TabIndex = 21;
            this.labelColumn1.Text = "1";
        
            // 
            // labelCoulmn2
            // 
            this.labelCoulmn2.AutoSize = true;
            this.labelCoulmn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCoulmn2.Location = new System.Drawing.Point(190, 43);
            this.labelCoulmn2.Name = "labelCoulmn2";
            this.labelCoulmn2.Size = new System.Drawing.Size(14, 13);
            this.labelCoulmn2.TabIndex = 22;
            this.labelCoulmn2.Text = "2";
            // 
            // labelRow0
            // 
            this.labelRow0.AutoSize = true;
            this.labelRow0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRow0.Location = new System.Drawing.Point(14, 78);
            this.labelRow0.Name = "labelRow0";
            this.labelRow0.Size = new System.Drawing.Size(14, 13);
            this.labelRow0.TabIndex = 23;
            this.labelRow0.Text = "0";
           
            // 
            // labelRow1
            // 
            this.labelRow1.AutoSize = true;
            this.labelRow1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRow1.Location = new System.Drawing.Point(15, 135);
            this.labelRow1.Name = "labelRow1";
            this.labelRow1.Size = new System.Drawing.Size(14, 13);
            this.labelRow1.TabIndex = 24;
            this.labelRow1.Text = "1";
        
            // 
            // labelRow2
            // 
            this.labelRow2.AutoSize = true;
            this.labelRow2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRow2.Location = new System.Drawing.Point(14, 192);
            this.labelRow2.Name = "labelRow2";
            this.labelRow2.Size = new System.Drawing.Size(14, 13);
            this.labelRow2.TabIndex = 25;
            this.labelRow2.Text = "2";
            // 
            // labelRow3
            // 
            this.labelRow3.AutoSize = true;
            this.labelRow3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRow3.Location = new System.Drawing.Point(14, 249);
            this.labelRow3.Name = "labelRow3";
            this.labelRow3.Size = new System.Drawing.Size(14, 13);
            this.labelRow3.TabIndex = 26;
            this.labelRow3.Text = "3";
            // 
            // labelRow4
            // 
            this.labelRow4.AutoSize = true;
            this.labelRow4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRow4.Location = new System.Drawing.Point(14, 306);
            this.labelRow4.Name = "labelRow4";
            this.labelRow4.Size = new System.Drawing.Size(14, 13);
            this.labelRow4.TabIndex = 27;
            this.labelRow4.Text = "4";
            // 
            // labelSeatReservationAndCancellation
            // 
            this.labelSeatReservationAndCancellation.AutoSize = true;
            this.labelSeatReservationAndCancellation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeatReservationAndCancellation.ForeColor = System.Drawing.Color.Black;
            this.labelSeatReservationAndCancellation.Location = new System.Drawing.Point(235, 33);
            this.labelSeatReservationAndCancellation.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
            this.labelSeatReservationAndCancellation.Name = "labelSeatReservationAndCancellation";
            this.labelSeatReservationAndCancellation.Size = new System.Drawing.Size(409, 28);
            this.labelSeatReservationAndCancellation.TabIndex = 28;
            this.labelSeatReservationAndCancellation.Text = "Seat Reservation and Cancellation";
            // 
            // buttonStatus
            // 
            this.buttonStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStatus.ForeColor = System.Drawing.Color.Black;
            this.buttonStatus.Location = new System.Drawing.Point(514, 129);
            this.buttonStatus.Name = "buttonStatus";
            this.buttonStatus.Size = new System.Drawing.Size(87, 32);
            this.buttonStatus.TabIndex = 29;
            this.buttonStatus.Text = "Status";
            this.buttonStatus.UseVisualStyleBackColor = false;
            this.buttonStatus.Click += new System.EventHandler(this.buttonStatus_Click);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
            this.listBox1.Location = new System.Drawing.Point(259, 129);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(101, 121);
            this.listBox1.TabIndex = 30;
            // 
            // listBox2
            // 
            this.listBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.listBox2.Location = new System.Drawing.Point(367, 129);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(108, 121);
            this.listBox2.TabIndex = 31;
            // 
            // buttonBook
            // 
            this.buttonBook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBook.ForeColor = System.Drawing.Color.Black;
            this.buttonBook.Location = new System.Drawing.Point(258, 256);
            this.buttonBook.Name = "buttonBook";
            this.buttonBook.Size = new System.Drawing.Size(101, 37);
            this.buttonBook.TabIndex = 32;
            this.buttonBook.Text = "Book";
            this.buttonBook.UseVisualStyleBackColor = false;
            this.buttonBook.Click += new System.EventHandler(this.buttonBook_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.ForeColor = System.Drawing.Color.Black;
            this.buttonCancel.Location = new System.Drawing.Point(366, 256);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(108, 37);
            this.buttonCancel.TabIndex = 33;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // btnAddToWaitingList
            // 
            this.btnAddToWaitingList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnAddToWaitingList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToWaitingList.ForeColor = System.Drawing.Color.Black;
            this.btnAddToWaitingList.Location = new System.Drawing.Point(258, 299);
            this.btnAddToWaitingList.Name = "btnAddToWaitingList";
            this.btnAddToWaitingList.Size = new System.Drawing.Size(218, 38);
            this.btnAddToWaitingList.TabIndex = 34;
            this.btnAddToWaitingList.Text = "Add to waiting list";
            this.btnAddToWaitingList.UseVisualStyleBackColor = false;
            this.btnAddToWaitingList.Click += new System.EventHandler(this.button4_Click);
            // 
            // ButtonShowAll
            // 
            this.ButtonShowAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ButtonShowAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonShowAll.ForeColor = System.Drawing.Color.Black;
            this.ButtonShowAll.Location = new System.Drawing.Point(37, 343);
            this.ButtonShowAll.Name = "ButtonShowAll";
            this.ButtonShowAll.Size = new System.Drawing.Size(117, 49);
            this.ButtonShowAll.TabIndex = 35;
            this.ButtonShowAll.Text = "Show All";
            this.ButtonShowAll.UseVisualStyleBackColor = false;
            this.ButtonShowAll.Click += new System.EventHandler(this.ButtonShowAll_Click);
            // 
            // ButtonShowWaitingList
            // 
            this.ButtonShowWaitingList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ButtonShowWaitingList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonShowWaitingList.ForeColor = System.Drawing.Color.Black;
            this.ButtonShowWaitingList.Location = new System.Drawing.Point(160, 343);
            this.ButtonShowWaitingList.Name = "ButtonShowWaitingList";
            this.ButtonShowWaitingList.Size = new System.Drawing.Size(117, 50);
            this.ButtonShowWaitingList.TabIndex = 36;
            this.ButtonShowWaitingList.Text = "Show waiting list";
            this.ButtonShowWaitingList.UseVisualStyleBackColor = false;
            this.ButtonShowWaitingList.Click += new System.EventHandler(this.ButtonShowWaitingList_Click);
            // 
            // ButtonFillAll
            // 
            this.ButtonFillAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ButtonFillAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonFillAll.ForeColor = System.Drawing.Color.Black;
            this.ButtonFillAll.Location = new System.Drawing.Point(366, 386);
            this.ButtonFillAll.Name = "ButtonFillAll";
            this.ButtonFillAll.Size = new System.Drawing.Size(115, 86);
            this.ButtonFillAll.TabIndex = 37;
            this.ButtonFillAll.Text = "Fill All (Debug)";
            this.ButtonFillAll.UseVisualStyleBackColor = false;
            this.ButtonFillAll.Click += new System.EventHandler(this.ButtonFillAll_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(38, 397);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(116, 115);
            this.richTextBox1.TabIndex = 38;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(160, 397);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(116, 115);
            this.richTextBox2.TabIndex = 39;
            this.richTextBox2.Text = "";
            // 
            // AirlineReservation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(645, 524);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.ButtonFillAll);
            this.Controls.Add(this.ButtonShowWaitingList);
            this.Controls.Add(this.ButtonShowAll);
            this.Controls.Add(this.btnAddToWaitingList);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonBook);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.buttonStatus);
            this.Controls.Add(this.labelSeatReservationAndCancellation);
            this.Controls.Add(this.labelRow4);
            this.Controls.Add(this.labelRow3);
            this.Controls.Add(this.labelRow2);
            this.Controls.Add(this.labelRow1);
            this.Controls.Add(this.labelRow0);
            this.Controls.Add(this.labelCoulmn2);
            this.Controls.Add(this.labelColumn1);
            this.Controls.Add(this.labelColumn0);
            this.Controls.Add(this.textBoxStatus);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Seat42);
            this.Controls.Add(this.Seat41);
            this.Controls.Add(this.Seat40);
            this.Controls.Add(this.Seat32);
            this.Controls.Add(this.Seat31);
            this.Controls.Add(this.Seat30);
            this.Controls.Add(this.Seat22);
            this.Controls.Add(this.Seat21);
            this.Controls.Add(this.Seat20);
            this.Controls.Add(this.Seat12);
            this.Controls.Add(this.Seat11);
            this.Controls.Add(this.Seat10);
            this.Controls.Add(this.Seat02);
            this.Controls.Add(this.Seat01);
            this.Controls.Add(this.Seat00);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "AirlineReservation";
            this.Text = "Airline Reservation by Ankit Kundlu";
        
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Seat00;
        private System.Windows.Forms.Button Seat01;
        private System.Windows.Forms.Button Seat02;
        private System.Windows.Forms.Button Seat12;
        private System.Windows.Forms.Button Seat11;
        private System.Windows.Forms.Button Seat10;
        private System.Windows.Forms.Button Seat22;
        private System.Windows.Forms.Button Seat21;
        private System.Windows.Forms.Button Seat20;
        private System.Windows.Forms.Button Seat32;
        private System.Windows.Forms.Button Seat31;
        private System.Windows.Forms.Button Seat30;
        private System.Windows.Forms.Button Seat42;
        private System.Windows.Forms.Button Seat41;
        private System.Windows.Forms.Button Seat40;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxStatus;
        private System.Windows.Forms.Label labelColumn0;
        private System.Windows.Forms.Label labelColumn1;
        private System.Windows.Forms.Label labelCoulmn2;
        private System.Windows.Forms.Label labelRow0;
        private System.Windows.Forms.Label labelRow1;
        private System.Windows.Forms.Label labelRow2;
        private System.Windows.Forms.Label labelRow3;
        private System.Windows.Forms.Label labelRow4;
        private System.Windows.Forms.Label labelSeatReservationAndCancellation;
        private System.Windows.Forms.Button buttonStatus;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button buttonBook;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button btnAddToWaitingList;
        private System.Windows.Forms.Button ButtonShowAll;
        private System.Windows.Forms.Button ButtonShowWaitingList;
        private System.Windows.Forms.Button ButtonFillAll;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
    }
}

