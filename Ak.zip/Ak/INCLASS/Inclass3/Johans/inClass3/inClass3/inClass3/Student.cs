﻿/*
 *ProgID : inClass3
 *FormId: Student
 * 
 * Purpose: to Calculate a person's Age
 * 
 * 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inClass3
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int yearOfBirth;

            yearOfBirth = Convert.ToInt32(txtYear.Text);

            Person sample = new Person(txtLastName.Text,txtFirstName.Text,yearOfBirth);

            if (sample.ValidateName(txtLastName.Text, txtFirstName.Text) )
            {


                int answer;
                answer = 0;

                answer = sample.CalculateAge(yearOfBirth);

                MessageBox.Show("Hi, " + txtFirstName.Text + " , " + txtLastName.Text + " your age this year will be: " + answer);
            }
            else
            {
                MessageBox.Show("Name first or Last name not large enough");
            }
        }

        private void Student_Load(object sender, EventArgs e)
        {

        }
    }
}
