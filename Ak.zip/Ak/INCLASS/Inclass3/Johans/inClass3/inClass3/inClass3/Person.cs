﻿/*
 *Class: Person
 * 
 * Purpose to define class And the method age calculation 
 * 
 * 
 */ 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inClass3
{
    class Person
    {
        private string lastName;
        private string firstName;
        private int yearOfBirth;

        public Person()
        {
            lastName = "";
            firstName = "";
            yearOfBirth = 0;
        }
        public Person(string lastName, string firstName, int yearOfBirth)
        {
            this.lastName = lastName;
            this.firstName = firstName;
            this.yearOfBirth = yearOfBirth;
        }
        public int CalculateAge(int yearOfBirth)
        {
            return 2018 - yearOfBirth;
        }
        public bool ValidateName(string firstName,string lastName)
        {
            bool answer = false;
            if (lastName.Length >= 3)
            {
                answer = true;
                
            }
            else if(lastName.Length < 3)
            {
                answer = false;
            }
            if (firstName.Length >= 3)
            {
                answer = true;
            }
            else if (firstName.Length < 3)
            {
                answer = false;
                
            }
            return answer;
        }
    }
}
