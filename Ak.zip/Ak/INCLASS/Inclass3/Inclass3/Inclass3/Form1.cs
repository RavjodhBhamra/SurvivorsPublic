﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inclass3
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            
            

            Person sample = new Person();
            sample.firstName = txtFirstName.Text;
            sample.lastName = txtLastName.Text;

            sample.dateOfBirth = dateTimePicker1.Value;


        }
        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            txtFirstName.Text = System.Threading.Thread.CurrentThread.
                   CurrentCulture.TextInfo.ToTitleCase(this.txtFirstName.Text);
            txtFirstName.Select(txtFirstName.Text.Length, 0);
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            txtLastName.Text = System.Threading.Thread.CurrentThread.
                   CurrentCulture.TextInfo.ToTitleCase(this.txtLastName.Text);
            txtLastName.Select(txtLastName.Text.Length, 0);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Student_Load(object sender, EventArgs e)
        {

        }
    }
}
