﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inclass3
{
    class Person
    {
        public string firstName;
        public string lastName;
        public DateTime dateOfBirth;


        public int CalculateAge()
        {
            int calculateAge = DateTime.Today.Year - dateOfBirth.Year;


            return  calculateAge;
        }

        /*public bool ValidateName(string firstName, string lastName)
        {
            bool answer = false;

            if (firstName.Length >= 3)
            {
                answer = true;
            }
            else if (firstName.Length < 3)
            {
                answer = false;
            }

            if (lastName.Length >= 3)
            {
                answer = true;
            }
            else if (lastName.Length < 3)
            {
                answer = false;
            }
            return answer;*/

        }
    }

