using Nunit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace Inclass5.Test.Classes
{
  [TestFixture]
  public class AKValidate
  {
     [Test]
	 public Boolean ValidLength(0)
	 {
	    Assert.IsTrue(result, 0, "So true");
	 
	 }
  
  
  }
}