﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace Inclass5
{
    class AKValidate
    {
       public Boolean AKIsNumeric(string num)
        {
            int value;
            return int.TryParse(num, out value);

        }
        public Boolean AKOneCharacter(string value)
        {
            if (value == null || value == "")
                return false;

            string pattern = @"(^.$)";
            Regex oneChar = new Regex(pattern, RegexOptions.IgnoreCase);

            if (oneChar.IsMatch(value))
                return true;
            else
                return false;
        }

        
        public Boolean AKLength(string num)
        {
            Boolean numResult;
            if (num.Length == 2)
                numResult = false;
            else
                numResult = true;

            return numResult;
        }
        public Boolean AKAlphabet(string values)
        {
            if (values == null || values == "")
                return false;

            string newPattern = @"[a-zA-Z]*$";
            Regex newChar = new Regex(newPattern, RegexOptions.IgnoreCase);

            if (newChar.IsMatch(values))
                return true;
            else
                return false;
        }

    }
}
