﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Inclass5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheckNumber_Click(object sender, EventArgs e)
        {
            rchMessage.Clear();
            AKValidate akValidate = new AKValidate();

            if (!akValidate.AKIsNumeric(txtFirst.Text))
            {
                rchMessage.Text += "Please enter a number in first textbox\n";
            }

           if (!akValidate.AKLength(txtFirst.Text))
            {
                rchMessage.Text += "Number length should be 2\n";
            }
           if(txtFirst.Text.Length != 2)
            {
                rchMessage.Text += "Number length should be 2\n";
            }

            if (!akValidate.AKOneCharacter(txtSecond.Text))
                rchMessage.Text += "Invalid single Character\n";

            if (!akValidate.AKAlphabet(txtThird.Text))
                rchMessage.Text += "Invalid letters\n" + " ";
        }

        private void btnGenerateArray_Click(object sender, EventArgs e)
        {
            string[] str = { "!1", "@2", "?3" };
            int[] numArray = { 0, 0, 0 };

            for (int i = 0; i < str.Length; i++)
            {
                numArray[i] = Convert.ToInt32(str[i].Substring(1, 1));
            }

            rchMessage.Text = "ARRAY LIST : \n " + "\n" + numArray[0] + " " + numArray[1] + " " + numArray[2];
        }
        private void btnGenerateFile_Click(object sender, EventArgs e)
        {
            string path = txtSecond.Text;

            if (txtSecond.Text == "")
            {
                rchMessage.Text = " Please enter name of the file to be created";
            }
            else
            {
                if (!File.Exists(txtSecond.Text = String.Format(path))
                         && path != null)
                {
                    StreamWriter textfile = new StreamWriter("fred.txt ", append: true);
                    if (rchMessage.Text.Length < 1)
                    {
                        string fileRecord = txtFirst.Text + "::" + txtSecond.Text + "::" + txtThird.Text;
                        textfile.WriteLine(fileRecord);
                        textfile.Close();
                    }
                }
                else
                {
                    rchMessage.Text = "File Already Exist, \n Try with different for new file to be generated";
                }
            }
        }
        private void txtThird_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtThird.Text, "^[a-zA-Z]+$"))
            {
                MessageBox.Show("This textbox accepts only alphabetical characters");
                txtThird.Text = "";
                txtThird.Text.Remove(txtThird.Text.Length - 1);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

       
    }
}
