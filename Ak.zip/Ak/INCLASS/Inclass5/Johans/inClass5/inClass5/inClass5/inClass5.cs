﻿//
//Program Name:  Inclass5
//Class Name: ReviewClass
//Purpose: To Validate data
//Revision History: april 18 2108 by Johan Tom 
//
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace inClass5
{
    public partial class inClass5 : Form
    {
        public inClass5()
        {
            InitializeComponent();
        }

        private void btnchkNumerics_Click(object sender, EventArgs e)
        {
            txtMessage.Clear();
            ReviewClass example = new ReviewClass();
       
            if(!example.IsNumeric(txtField1.Text))
            {
                txtMessage.Text = "Please Enter numeric Data into Feild 1";
            }
      
        }

        private void btngenerate_Click(object sender, EventArgs e)
        {

            StreamWriter file = new StreamWriter(@"test.txt", append: true);
            if (txtMessage.Text.Length < 1)
            {
                string record = txtField1.Text + "|" 
                    + txtField2.Text + "|" + txtField3.Text;
                file.WriteLine(record);
                file.Close();
            }
        }

        private void btnGenerateArray_Click(object sender, EventArgs e)
        {
            string[] fun = { "!1", "@2", "?3", };
            int[] intFun = { 0, 0, 0 };
            for(int i =0; i<fun.Length;i++)
            {
                intFun[i] = Convert.ToInt32(fun[i].Substring(1, 1));

            }
            txtMessage.Text = "Index 0: " + intFun[0] +" "+
                intFun[1] + " " + intFun[2]+"\n";
        }

        private void inClass5_Load(object sender, EventArgs e)
        {

        }
    }
}
