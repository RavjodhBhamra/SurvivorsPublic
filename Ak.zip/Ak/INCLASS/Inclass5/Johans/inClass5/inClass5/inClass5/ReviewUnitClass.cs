using System;
using Nunit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inClass5.UnitClass
{
   [TestFixture]
   public class reviewTest
   {
       [Test]
	   public ValidReview("People")
	   {
	    Assert.IsTrue("Valid");
	   
	   }
   
   
   }


}