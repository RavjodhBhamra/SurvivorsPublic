﻿namespace inClass5
{
    partial class inClass5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtField1 = new System.Windows.Forms.TextBox();
            this.txtField2 = new System.Windows.Forms.TextBox();
            this.txtField3 = new System.Windows.Forms.TextBox();
            this.btnchkNumerics = new System.Windows.Forms.Button();
            this.txtMessage = new System.Windows.Forms.RichTextBox();
            this.btngenerate = new System.Windows.Forms.Button();
            this.btnGenerateArray = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtField1
            // 
            this.txtField1.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtField1.Location = new System.Drawing.Point(196, 65);
            this.txtField1.Name = "txtField1";
            this.txtField1.Size = new System.Drawing.Size(250, 29);
            this.txtField1.TabIndex = 0;
            // 
            // txtField2
            // 
            this.txtField2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtField2.Location = new System.Drawing.Point(196, 108);
            this.txtField2.Name = "txtField2";
            this.txtField2.Size = new System.Drawing.Size(250, 29);
            this.txtField2.TabIndex = 1;
            // 
            // txtField3
            // 
            this.txtField3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtField3.Location = new System.Drawing.Point(196, 167);
            this.txtField3.Name = "txtField3";
            this.txtField3.Size = new System.Drawing.Size(250, 29);
            this.txtField3.TabIndex = 2;
            // 
            // btnchkNumerics
            // 
            this.btnchkNumerics.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchkNumerics.Location = new System.Drawing.Point(589, 224);
            this.btnchkNumerics.Name = "btnchkNumerics";
            this.btnchkNumerics.Size = new System.Drawing.Size(230, 109);
            this.btnchkNumerics.TabIndex = 3;
            this.btnchkNumerics.Text = "Check for Numerics";
            this.btnchkNumerics.UseVisualStyleBackColor = true;
            this.btnchkNumerics.Click += new System.EventHandler(this.btnchkNumerics_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(27, 365);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(407, 268);
            this.txtMessage.TabIndex = 4;
            this.txtMessage.Text = "";
            // 
            // btngenerate
            // 
            this.btngenerate.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngenerate.Location = new System.Drawing.Point(580, 377);
            this.btngenerate.Name = "btngenerate";
            this.btngenerate.Size = new System.Drawing.Size(189, 124);
            this.btngenerate.TabIndex = 5;
            this.btngenerate.Text = "Generate a File";
            this.btngenerate.UseVisualStyleBackColor = true;
            this.btngenerate.Click += new System.EventHandler(this.btngenerate_Click);
            // 
            // btnGenerateArray
            // 
            this.btnGenerateArray.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerateArray.Location = new System.Drawing.Point(589, 527);
            this.btnGenerateArray.Name = "btnGenerateArray";
            this.btnGenerateArray.Size = new System.Drawing.Size(189, 124);
            this.btnGenerateArray.TabIndex = 6;
            this.btnGenerateArray.Text = "Generate an Array";
            this.btnGenerateArray.UseVisualStyleBackColor = true;
            this.btnGenerateArray.Click += new System.EventHandler(this.btnGenerateArray_Click);
            // 
            // inClass5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 674);
            this.Controls.Add(this.btnGenerateArray);
            this.Controls.Add(this.btngenerate);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.btnchkNumerics);
            this.Controls.Add(this.txtField3);
            this.Controls.Add(this.txtField2);
            this.Controls.Add(this.txtField1);
            this.Name = "inClass5";
            this.Text = "inClass5 - Liz Stacey";
            this.Load += new System.EventHandler(this.inClass5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtField1;
        private System.Windows.Forms.TextBox txtField2;
        private System.Windows.Forms.TextBox txtField3;
        private System.Windows.Forms.Button btnchkNumerics;
        private System.Windows.Forms.RichTextBox txtMessage;
        private System.Windows.Forms.Button btngenerate;
        private System.Windows.Forms.Button btnGenerateArray;
    }
}

