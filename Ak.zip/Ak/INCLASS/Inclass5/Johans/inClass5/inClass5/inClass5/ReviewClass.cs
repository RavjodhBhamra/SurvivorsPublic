﻿//
//Program Name:  Inclass5
//Class Name: ReviewClass
//Purpose: To Validate data
//Revision History: april 18 2108 by Johan Tom 
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inClass5
{
    class ReviewClass
    {

        string sample1;
        string sample2;
        string sample3;

        public ReviewClass()
        {
            sample1 = "";
            sample2 = "";
            sample3 = "";

        }
        public Boolean IsNumeric(string snumbers)
        {

            int result;
            return int.TryParse(snumbers, out result);

        }
        public Boolean CheckForLength(string snumbers)
        {

            Boolean result;
            if (snumbers.Length <= 2)
            {
                result = false;
            }
            else
            {
                result = true;
            }
            return result;
        }
    }

 
}
