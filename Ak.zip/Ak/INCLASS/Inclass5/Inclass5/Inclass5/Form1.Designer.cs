﻿namespace Inclass5
{
    partial class AKInclass5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCreateNumeric = new System.Windows.Forms.TextBox();
            this.txtGenerateArray = new System.Windows.Forms.TextBox();
            this.txtCreateFile = new System.Windows.Forms.TextBox();
            this.btnCheckNumeric = new System.Windows.Forms.Button();
            this.btnCreateFile = new System.Windows.Forms.Button();
            this.btnGenerateArray = new System.Windows.Forms.Button();
            this.rtMsg = new System.Windows.Forms.RichTextBox();
            this.lblMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCreateNumeric
            // 
            this.txtCreateNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCreateNumeric.Location = new System.Drawing.Point(94, 79);
            this.txtCreateNumeric.Multiline = true;
            this.txtCreateNumeric.Name = "txtCreateNumeric";
            this.txtCreateNumeric.Size = new System.Drawing.Size(307, 39);
            this.txtCreateNumeric.TabIndex = 0;
            // 
            // txtGenerateArray
            // 
            this.txtGenerateArray.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGenerateArray.Location = new System.Drawing.Point(94, 221);
            this.txtGenerateArray.Multiline = true;
            this.txtGenerateArray.Name = "txtGenerateArray";
            this.txtGenerateArray.Size = new System.Drawing.Size(307, 39);
            this.txtGenerateArray.TabIndex = 1;
            // 
            // txtCreateFile
            // 
            this.txtCreateFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCreateFile.Location = new System.Drawing.Point(94, 149);
            this.txtCreateFile.Multiline = true;
            this.txtCreateFile.Name = "txtCreateFile";
            this.txtCreateFile.Size = new System.Drawing.Size(307, 39);
            this.txtCreateFile.TabIndex = 2;
            // 
            // btnCheckNumeric
            // 
            this.btnCheckNumeric.BackColor = System.Drawing.Color.Teal;
            this.btnCheckNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckNumeric.Location = new System.Drawing.Point(487, 77);
            this.btnCheckNumeric.Name = "btnCheckNumeric";
            this.btnCheckNumeric.Size = new System.Drawing.Size(191, 41);
            this.btnCheckNumeric.TabIndex = 3;
            this.btnCheckNumeric.Text = "Check Numreic";
            this.btnCheckNumeric.UseVisualStyleBackColor = false;
            this.btnCheckNumeric.Click += new System.EventHandler(this.btnCheckNumeric_Click);
            // 
            // btnCreateFile
            // 
            this.btnCreateFile.BackColor = System.Drawing.Color.Teal;
            this.btnCreateFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateFile.Location = new System.Drawing.Point(487, 149);
            this.btnCreateFile.Name = "btnCreateFile";
            this.btnCreateFile.Size = new System.Drawing.Size(191, 41);
            this.btnCreateFile.TabIndex = 4;
            this.btnCreateFile.Text = "Create File";
            this.btnCreateFile.UseVisualStyleBackColor = false;
            // 
            // btnGenerateArray
            // 
            this.btnGenerateArray.BackColor = System.Drawing.Color.Teal;
            this.btnGenerateArray.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerateArray.Location = new System.Drawing.Point(487, 221);
            this.btnGenerateArray.Name = "btnGenerateArray";
            this.btnGenerateArray.Size = new System.Drawing.Size(191, 41);
            this.btnGenerateArray.TabIndex = 5;
            this.btnGenerateArray.Text = "Generate Array";
            this.btnGenerateArray.UseVisualStyleBackColor = false;
            // 
            // rtMsg
            // 
            this.rtMsg.Location = new System.Drawing.Point(54, 334);
            this.rtMsg.Name = "rtMsg";
            this.rtMsg.Size = new System.Drawing.Size(718, 177);
            this.rtMsg.TabIndex = 6;
            this.rtMsg.Text = "";
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsg.Location = new System.Drawing.Point(61, 301);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(87, 24);
            this.lblMsg.TabIndex = 7;
            this.lblMsg.Text = "Message";
            // 
            // AKInclass5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(838, 536);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.rtMsg);
            this.Controls.Add(this.btnGenerateArray);
            this.Controls.Add(this.btnCreateFile);
            this.Controls.Add(this.btnCheckNumeric);
            this.Controls.Add(this.txtCreateFile);
            this.Controls.Add(this.txtGenerateArray);
            this.Controls.Add(this.txtCreateNumeric);
            this.Name = "AKInclass5";
            this.Text = "Inclass5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCreateNumeric;
        private System.Windows.Forms.TextBox txtGenerateArray;
        private System.Windows.Forms.TextBox txtCreateFile;
        private System.Windows.Forms.Button btnCheckNumeric;
        private System.Windows.Forms.Button btnCreateFile;
        private System.Windows.Forms.Button btnGenerateArray;
        private System.Windows.Forms.RichTextBox rtMsg;
        private System.Windows.Forms.Label lblMsg;
    }
}

