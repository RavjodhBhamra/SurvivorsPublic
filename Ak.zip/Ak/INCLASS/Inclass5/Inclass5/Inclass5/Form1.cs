﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inclass5
{
    public partial class AKInclass5 : Form
    {
        public AKInclass5()
        {
            InitializeComponent();
        }

        private void btnCheckNumeric_Click(object sender, EventArgs e)
        {
            rtMsg.Clear();
            AKValidations isNum = new AKValidations();

            if (!isNum.AKIsNumeric(txtCreateNumeric.Text))
            {
                rtMsg.Text += "Please enter a number in first textbox";
            }
            if (!isNum.AKLength(txtCreateNumeric.Text))
            {
                rtMsg.Text += "Please enter number more than length of 2";
            }

            if (!isNum.AKOneCharacter(txtCreateFile.Text))
                rtMsg.Text += "Invalid single";

            if (!isNum.AKletter(txtGenerateArray.Text))
                rtMsg.Text += "Invalid letters" +
                    "";
        }
        private void btnCreateFile_Click(object sender, EventArgs e)
        {
            StreamWriter textfile = new StreamWriter(@"AKInclass5.txt", append: true);
            if (rtMsg.Text.Length < 1)
            {
                string fileRecord = txtCreateNumeric.Text + "::" + txtCreateFile.Text + "::" + txtGenerateArray.Text;
                textfile.WriteLine(fileRecord);
                textfile.Close();
            }
        }
        private void btnGenerateArray_Click(object sender, EventArgs e)
        {
            string[] str = { "!1", "@2", "?3" };
            int[] numArray = { 0, 0, 0 };

            for (int i = 0; i < str.Length; i++)
            {
                numArray[i] = Convert.ToInt32(str[i].Substring(1, 1));
            }

            rtMsg.Text = "Array: " + numArray[0] + " " + numArray[1] + " " + numArray[2];
        }
    }
           
}
