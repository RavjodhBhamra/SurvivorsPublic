﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inclass4
{
    class File_Utilities
    {
        public static void File_CreatePath(string fileAndPath,
                                      Boolean deleteFile = false,
                                      Boolean createFile = true)
        {
            string location;
            location = fileAndPath.Substring(0, fileAndPath.LastIndexOf(@"\"));
            CreatePath(location);

            try
            {
                if(deleteFile == true)
                {
                    File.Delete(fileAndPath);
                }

                if(createFile == true)
                {
                    if(!File.Exists(fileAndPath))
                    {
                        File.Create(fileAndPath);
                    }
                }
            }
            catch (Exception ex)
            {

                //throw new Exception ($"Error creating File \n:{ex.Message}");
                MessageBox.Show(ex.Message);
            }

        }
        public static void CreatePath(string filePath)
        {
            bool location;

            try
            {
                location = Directory.Exists(filePath);

                if (location == false)
                {
                    Directory.CreateDirectory(filePath);
                }
            }
            catch (Exception ex)
            {

                throw new Exception($"Error creating file path\n:{ex.Message}");
            }
        }

    }
}
