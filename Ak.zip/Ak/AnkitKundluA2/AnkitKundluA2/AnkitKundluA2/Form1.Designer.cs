﻿namespace AnkitKundluA2
{
    partial class AnkitKundluMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelMemberMaintenance = new System.Windows.Forms.Label();
            this.labelMembersFirstName = new System.Windows.Forms.Label();
            this.labelMembersLastName = new System.Windows.Forms.Label();
            this.labelSpousesFirstname = new System.Windows.Forms.Label();
            this.labelSpousesLastName = new System.Windows.Forms.Label();
            this.labelStreetAddress = new System.Windows.Forms.Label();
            this.labelCity = new System.Windows.Forms.Label();
            this.labelProvinceCode = new System.Windows.Forms.Label();
            this.labelPostalCode = new System.Windows.Forms.Label();
            this.labelHomePhone = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelFee = new System.Windows.Forms.Label();
            this.textBoxMembersFirstName = new System.Windows.Forms.TextBox();
            this.textBoxMembersLastName = new System.Windows.Forms.TextBox();
            this.textBoxSpousesFirstName = new System.Windows.Forms.TextBox();
            this.textBoxSpousesLastName = new System.Windows.Forms.TextBox();
            this.textBoxStreetAddress = new System.Windows.Forms.TextBox();
            this.textBoxCity = new System.Windows.Forms.TextBox();
            this.textBoxProvinceCode = new System.Windows.Forms.TextBox();
            this.textBoxPostalCode = new System.Windows.Forms.TextBox();
            this.textBoxHomePhone = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxFee = new System.Windows.Forms.TextBox();
            this.buttonPreFill = new System.Windows.Forms.Button();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.labelErrorMembersFirstName = new System.Windows.Forms.Label();
            this.labelErrorMembersLastName = new System.Windows.Forms.Label();
            this.labelErrorSpousesFirstName = new System.Windows.Forms.Label();
            this.labelErrorSpousesLastName = new System.Windows.Forms.Label();
            this.labelErrorStreetAddress = new System.Windows.Forms.Label();
            this.labelErrorCity = new System.Windows.Forms.Label();
            this.labelErrorProvinceCode = new System.Windows.Forms.Label();
            this.labelErrorPostalCode = new System.Windows.Forms.Label();
            this.labelErrorPhoneNumber = new System.Windows.Forms.Label();
            this.labelErrorEmail = new System.Windows.Forms.Label();
            this.labelErrorFee = new System.Windows.Forms.Label();
            this.errorProviderMembersFirstName = new System.Windows.Forms.ErrorProvider(this.components);
            this.labelFullName = new System.Windows.Forms.Label();
            this.buttonFullName = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderMembersFirstName)).BeginInit();
            this.SuspendLayout();
            // 
            // labelMemberMaintenance
            // 
            this.labelMemberMaintenance.AutoSize = true;
            this.labelMemberMaintenance.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMemberMaintenance.Location = new System.Drawing.Point(122, 9);
            this.labelMemberMaintenance.Name = "labelMemberMaintenance";
            this.labelMemberMaintenance.Size = new System.Drawing.Size(259, 35);
            this.labelMemberMaintenance.TabIndex = 0;
            this.labelMemberMaintenance.Text = "Member Maintenance";
            // 
            // labelMembersFirstName
            // 
            this.labelMembersFirstName.AutoSize = true;
            this.labelMembersFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMembersFirstName.Location = new System.Drawing.Point(17, 91);
            this.labelMembersFirstName.Name = "labelMembersFirstName";
            this.labelMembersFirstName.Size = new System.Drawing.Size(126, 15);
            this.labelMembersFirstName.TabIndex = 1;
            this.labelMembersFirstName.Text = "Member\'s First Name";
            // 
            // labelMembersLastName
            // 
            this.labelMembersLastName.AutoSize = true;
            this.labelMembersLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMembersLastName.Location = new System.Drawing.Point(17, 125);
            this.labelMembersLastName.Name = "labelMembersLastName";
            this.labelMembersLastName.Size = new System.Drawing.Size(126, 15);
            this.labelMembersLastName.TabIndex = 2;
            this.labelMembersLastName.Text = "Member\'s Last Name";
            // 
            // labelSpousesFirstname
            // 
            this.labelSpousesFirstname.AutoSize = true;
            this.labelSpousesFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSpousesFirstname.Location = new System.Drawing.Point(17, 163);
            this.labelSpousesFirstname.Name = "labelSpousesFirstname";
            this.labelSpousesFirstname.Size = new System.Drawing.Size(121, 15);
            this.labelSpousesFirstname.TabIndex = 3;
            this.labelSpousesFirstname.Text = "Spouse\'s First Name";
            // 
            // labelSpousesLastName
            // 
            this.labelSpousesLastName.AutoSize = true;
            this.labelSpousesLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSpousesLastName.Location = new System.Drawing.Point(17, 205);
            this.labelSpousesLastName.Name = "labelSpousesLastName";
            this.labelSpousesLastName.Size = new System.Drawing.Size(121, 15);
            this.labelSpousesLastName.TabIndex = 4;
            this.labelSpousesLastName.Text = "Spouse\'s Last Name";
            // 
            // labelStreetAddress
            // 
            this.labelStreetAddress.AutoSize = true;
            this.labelStreetAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStreetAddress.Location = new System.Drawing.Point(18, 244);
            this.labelStreetAddress.Name = "labelStreetAddress";
            this.labelStreetAddress.Size = new System.Drawing.Size(86, 15);
            this.labelStreetAddress.TabIndex = 5;
            this.labelStreetAddress.Text = "Street Address";
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCity.Location = new System.Drawing.Point(25, 283);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(26, 15);
            this.labelCity.TabIndex = 6;
            this.labelCity.Text = "City";
            // 
            // labelProvinceCode
            // 
            this.labelProvinceCode.AutoSize = true;
            this.labelProvinceCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProvinceCode.Location = new System.Drawing.Point(17, 321);
            this.labelProvinceCode.Name = "labelProvinceCode";
            this.labelProvinceCode.Size = new System.Drawing.Size(86, 15);
            this.labelProvinceCode.TabIndex = 7;
            this.labelProvinceCode.Text = "Province Code";
            // 
            // labelPostalCode
            // 
            this.labelPostalCode.AutoSize = true;
            this.labelPostalCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPostalCode.Location = new System.Drawing.Point(17, 355);
            this.labelPostalCode.Name = "labelPostalCode";
            this.labelPostalCode.Size = new System.Drawing.Size(73, 15);
            this.labelPostalCode.TabIndex = 8;
            this.labelPostalCode.Text = "Postal Code";
            // 
            // labelHomePhone
            // 
            this.labelHomePhone.AutoSize = true;
            this.labelHomePhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHomePhone.Location = new System.Drawing.Point(17, 395);
            this.labelHomePhone.Name = "labelHomePhone";
            this.labelHomePhone.Size = new System.Drawing.Size(80, 15);
            this.labelHomePhone.TabIndex = 9;
            this.labelHomePhone.Text = "Home Phone";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(17, 433);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(39, 15);
            this.labelEmail.TabIndex = 10;
            this.labelEmail.Text = "Email";
            // 
            // labelFee
            // 
            this.labelFee.AutoSize = true;
            this.labelFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFee.Location = new System.Drawing.Point(17, 475);
            this.labelFee.Name = "labelFee";
            this.labelFee.Size = new System.Drawing.Size(28, 15);
            this.labelFee.TabIndex = 11;
            this.labelFee.Text = "Fee";
            // 
            // textBoxMembersFirstName
            // 
            this.textBoxMembersFirstName.Location = new System.Drawing.Point(149, 85);
            this.textBoxMembersFirstName.Multiline = true;
            this.textBoxMembersFirstName.Name = "textBoxMembersFirstName";
            this.textBoxMembersFirstName.Size = new System.Drawing.Size(204, 21);
            this.textBoxMembersFirstName.TabIndex = 12;
            this.textBoxMembersFirstName.TextChanged += new System.EventHandler(this.textBoxMembersFirstName_TextChanged);
            this.textBoxMembersFirstName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxMembersFirstName_KeyDown);
            this.textBoxMembersFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMembersFirstName_KeyPress);
            // 
            // textBoxMembersLastName
            // 
            this.textBoxMembersLastName.Location = new System.Drawing.Point(149, 120);
            this.textBoxMembersLastName.Name = "textBoxMembersLastName";
            this.textBoxMembersLastName.Size = new System.Drawing.Size(204, 20);
            this.textBoxMembersLastName.TabIndex = 13;
            this.textBoxMembersLastName.TextChanged += new System.EventHandler(this.textBoxMembersLastName_TextChanged);
            this.textBoxMembersLastName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxMembersLastName_KeyDown);
            this.textBoxMembersLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMembersLastName_KeyPress);
            // 
            // textBoxSpousesFirstName
            // 
            this.textBoxSpousesFirstName.Location = new System.Drawing.Point(149, 158);
            this.textBoxSpousesFirstName.Name = "textBoxSpousesFirstName";
            this.textBoxSpousesFirstName.Size = new System.Drawing.Size(204, 20);
            this.textBoxSpousesFirstName.TabIndex = 14;
            this.textBoxSpousesFirstName.TextChanged += new System.EventHandler(this.textBoxSpousesFirstName_TextChanged);
            this.textBoxSpousesFirstName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSpousesFirstName_KeyDown);
            this.textBoxSpousesFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSpousesFirstName_KeyPress);
            // 
            // textBoxSpousesLastName
            // 
            this.textBoxSpousesLastName.Location = new System.Drawing.Point(149, 200);
            this.textBoxSpousesLastName.Name = "textBoxSpousesLastName";
            this.textBoxSpousesLastName.Size = new System.Drawing.Size(204, 20);
            this.textBoxSpousesLastName.TabIndex = 15;
            this.textBoxSpousesLastName.TextChanged += new System.EventHandler(this.textBoxSpousesLastName_TextChanged);
            this.textBoxSpousesLastName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSpousesLastName_KeyDown);
            this.textBoxSpousesLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSpousesLastName_KeyPress);
            // 
            // textBoxStreetAddress
            // 
            this.textBoxStreetAddress.Location = new System.Drawing.Point(149, 243);
            this.textBoxStreetAddress.Name = "textBoxStreetAddress";
            this.textBoxStreetAddress.Size = new System.Drawing.Size(204, 20);
            this.textBoxStreetAddress.TabIndex = 16;
            this.textBoxStreetAddress.TextChanged += new System.EventHandler(this.textBoxStreetAddress_TextChanged);
            this.textBoxStreetAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxStreetAddress_KeyDown);
            this.textBoxStreetAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxStreetAddress_KeyPress);
            // 
            // textBoxCity
            // 
            this.textBoxCity.Location = new System.Drawing.Point(149, 282);
            this.textBoxCity.Name = "textBoxCity";
            this.textBoxCity.Size = new System.Drawing.Size(204, 20);
            this.textBoxCity.TabIndex = 17;
            this.textBoxCity.TextChanged += new System.EventHandler(this.textBoxCity_TextChanged);
            this.textBoxCity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCity_KeyDown);
            this.textBoxCity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCity_KeyPress);
            // 
            // textBoxProvinceCode
            // 
            this.textBoxProvinceCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxProvinceCode.Location = new System.Drawing.Point(149, 316);
            this.textBoxProvinceCode.Name = "textBoxProvinceCode";
            this.textBoxProvinceCode.Size = new System.Drawing.Size(204, 20);
            this.textBoxProvinceCode.TabIndex = 18;
            this.textBoxProvinceCode.TextChanged += new System.EventHandler(this.textBoxProvinceCode_TextChanged);
            this.textBoxProvinceCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxProvinceCode_KeyDown);
            this.textBoxProvinceCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxProvinceCode_KeyPress);
            // 
            // textBoxPostalCode
            // 
            this.textBoxPostalCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxPostalCode.Location = new System.Drawing.Point(149, 350);
            this.textBoxPostalCode.Name = "textBoxPostalCode";
            this.textBoxPostalCode.Size = new System.Drawing.Size(204, 20);
            this.textBoxPostalCode.TabIndex = 19;
            this.textBoxPostalCode.TextChanged += new System.EventHandler(this.textBoxPostalCode_TextChanged);
            this.textBoxPostalCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxPostalCode_KeyDown);
            // 
            // textBoxHomePhone
            // 
            this.textBoxHomePhone.Location = new System.Drawing.Point(149, 390);
            this.textBoxHomePhone.Name = "textBoxHomePhone";
            this.textBoxHomePhone.Size = new System.Drawing.Size(204, 20);
            this.textBoxHomePhone.TabIndex = 20;
            this.textBoxHomePhone.TextChanged += new System.EventHandler(this.textBoxHomePhone_TextChanged);
            this.textBoxHomePhone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxHomePhone_KeyDown);
            this.textBoxHomePhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxHomePhone_KeyPress);
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.textBoxEmail.Location = new System.Drawing.Point(149, 428);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(204, 20);
            this.textBoxEmail.TabIndex = 21;
            this.textBoxEmail.TextChanged += new System.EventHandler(this.textBoxEmail_TextChanged);
            this.textBoxEmail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxEmail_KeyDown);
            this.textBoxEmail.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxEmail_Validating);
            // 
            // textBoxFee
            // 
            this.textBoxFee.Location = new System.Drawing.Point(149, 470);
            this.textBoxFee.Name = "textBoxFee";
            this.textBoxFee.Size = new System.Drawing.Size(204, 20);
            this.textBoxFee.TabIndex = 22;
            this.textBoxFee.TextChanged += new System.EventHandler(this.textBoxFee_TextChanged);
            this.textBoxFee.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxFee_KeyDown);
            this.textBoxFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxFee_KeyPress_1);
            // 
            // buttonPreFill
            // 
            this.buttonPreFill.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPreFill.Location = new System.Drawing.Point(149, 520);
            this.buttonPreFill.Name = "buttonPreFill";
            this.buttonPreFill.Size = new System.Drawing.Size(62, 31);
            this.buttonPreFill.TabIndex = 23;
            this.buttonPreFill.Text = "Pre-Fill";
            this.buttonPreFill.UseVisualStyleBackColor = true;
            this.buttonPreFill.Click += new System.EventHandler(this.buttonPreFill_Click);
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSubmit.Location = new System.Drawing.Point(223, 520);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(62, 31);
            this.buttonSubmit.TabIndex = 24;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.ForeColor = System.Drawing.Color.Red;
            this.buttonClose.Location = new System.Drawing.Point(291, 520);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(62, 31);
            this.buttonClose.TabIndex = 25;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // labelErrorMembersFirstName
            // 
            this.labelErrorMembersFirstName.AutoSize = true;
            this.labelErrorMembersFirstName.ForeColor = System.Drawing.Color.Red;
            this.labelErrorMembersFirstName.Location = new System.Drawing.Point(384, 92);
            this.labelErrorMembersFirstName.Name = "labelErrorMembersFirstName";
            this.labelErrorMembersFirstName.Size = new System.Drawing.Size(10, 13);
            this.labelErrorMembersFirstName.TabIndex = 26;
            this.labelErrorMembersFirstName.Text = ".";
            this.labelErrorMembersFirstName.Click += new System.EventHandler(this.labelErrorMembersFirstName_Click);
            // 
            // labelErrorMembersLastName
            // 
            this.labelErrorMembersLastName.AutoSize = true;
            this.labelErrorMembersLastName.ForeColor = System.Drawing.Color.Red;
            this.labelErrorMembersLastName.Location = new System.Drawing.Point(384, 127);
            this.labelErrorMembersLastName.Name = "labelErrorMembersLastName";
            this.labelErrorMembersLastName.Size = new System.Drawing.Size(10, 13);
            this.labelErrorMembersLastName.TabIndex = 27;
            this.labelErrorMembersLastName.Text = ".";
            this.labelErrorMembersLastName.Click += new System.EventHandler(this.labelErrorMembersLastName_Click);
            // 
            // labelErrorSpousesFirstName
            // 
            this.labelErrorSpousesFirstName.AutoSize = true;
            this.labelErrorSpousesFirstName.ForeColor = System.Drawing.Color.Red;
            this.labelErrorSpousesFirstName.Location = new System.Drawing.Point(384, 165);
            this.labelErrorSpousesFirstName.Name = "labelErrorSpousesFirstName";
            this.labelErrorSpousesFirstName.Size = new System.Drawing.Size(10, 13);
            this.labelErrorSpousesFirstName.TabIndex = 28;
            this.labelErrorSpousesFirstName.Text = ".";
            this.labelErrorSpousesFirstName.Click += new System.EventHandler(this.labelErrorSpousesFirstName_Click);
            // 
            // labelErrorSpousesLastName
            // 
            this.labelErrorSpousesLastName.AutoSize = true;
            this.labelErrorSpousesLastName.ForeColor = System.Drawing.Color.Red;
            this.labelErrorSpousesLastName.Location = new System.Drawing.Point(384, 190);
            this.labelErrorSpousesLastName.Name = "labelErrorSpousesLastName";
            this.labelErrorSpousesLastName.Size = new System.Drawing.Size(10, 13);
            this.labelErrorSpousesLastName.TabIndex = 29;
            this.labelErrorSpousesLastName.Text = ".";
            this.labelErrorSpousesLastName.Click += new System.EventHandler(this.labelErrorSpousesLastName_Click);
            // 
            // labelErrorStreetAddress
            // 
            this.labelErrorStreetAddress.AutoSize = true;
            this.labelErrorStreetAddress.ForeColor = System.Drawing.Color.Red;
            this.labelErrorStreetAddress.Location = new System.Drawing.Point(384, 250);
            this.labelErrorStreetAddress.Name = "labelErrorStreetAddress";
            this.labelErrorStreetAddress.Size = new System.Drawing.Size(10, 13);
            this.labelErrorStreetAddress.TabIndex = 30;
            this.labelErrorStreetAddress.Text = ".";
            this.labelErrorStreetAddress.Click += new System.EventHandler(this.labelErrorStreetAddress_Click);
            // 
            // labelErrorCity
            // 
            this.labelErrorCity.AutoSize = true;
            this.labelErrorCity.ForeColor = System.Drawing.Color.Red;
            this.labelErrorCity.Location = new System.Drawing.Point(384, 289);
            this.labelErrorCity.Name = "labelErrorCity";
            this.labelErrorCity.Size = new System.Drawing.Size(10, 13);
            this.labelErrorCity.TabIndex = 31;
            this.labelErrorCity.Text = ".";
            this.labelErrorCity.Click += new System.EventHandler(this.labelErrorCity_Click);
            // 
            // labelErrorProvinceCode
            // 
            this.labelErrorProvinceCode.AutoSize = true;
            this.labelErrorProvinceCode.ForeColor = System.Drawing.Color.Red;
            this.labelErrorProvinceCode.Location = new System.Drawing.Point(384, 323);
            this.labelErrorProvinceCode.Name = "labelErrorProvinceCode";
            this.labelErrorProvinceCode.Size = new System.Drawing.Size(10, 13);
            this.labelErrorProvinceCode.TabIndex = 32;
            this.labelErrorProvinceCode.Text = ".";
            this.labelErrorProvinceCode.Click += new System.EventHandler(this.labelErrorProvinceCode_Click);
            // 
            // labelErrorPostalCode
            // 
            this.labelErrorPostalCode.AutoSize = true;
            this.labelErrorPostalCode.ForeColor = System.Drawing.Color.Red;
            this.labelErrorPostalCode.Location = new System.Drawing.Point(384, 357);
            this.labelErrorPostalCode.Name = "labelErrorPostalCode";
            this.labelErrorPostalCode.Size = new System.Drawing.Size(10, 13);
            this.labelErrorPostalCode.TabIndex = 33;
            this.labelErrorPostalCode.Text = ".";
            this.labelErrorPostalCode.Click += new System.EventHandler(this.labelErrorPostalCode_Click);
            // 
            // labelErrorPhoneNumber
            // 
            this.labelErrorPhoneNumber.AutoSize = true;
            this.labelErrorPhoneNumber.ForeColor = System.Drawing.Color.Red;
            this.labelErrorPhoneNumber.Location = new System.Drawing.Point(384, 397);
            this.labelErrorPhoneNumber.Name = "labelErrorPhoneNumber";
            this.labelErrorPhoneNumber.Size = new System.Drawing.Size(10, 13);
            this.labelErrorPhoneNumber.TabIndex = 34;
            this.labelErrorPhoneNumber.Text = ".";
            this.labelErrorPhoneNumber.Click += new System.EventHandler(this.labelErrorPhoneNumber_Click);
            // 
            // labelErrorEmail
            // 
            this.labelErrorEmail.AutoSize = true;
            this.labelErrorEmail.ForeColor = System.Drawing.Color.Red;
            this.labelErrorEmail.Location = new System.Drawing.Point(384, 431);
            this.labelErrorEmail.Name = "labelErrorEmail";
            this.labelErrorEmail.Size = new System.Drawing.Size(10, 13);
            this.labelErrorEmail.TabIndex = 35;
            this.labelErrorEmail.Text = ".";
            this.labelErrorEmail.Click += new System.EventHandler(this.labelErrorEmail_Click);
            // 
            // labelErrorFee
            // 
            this.labelErrorFee.AutoSize = true;
            this.labelErrorFee.ForeColor = System.Drawing.Color.Red;
            this.labelErrorFee.Location = new System.Drawing.Point(384, 475);
            this.labelErrorFee.Name = "labelErrorFee";
            this.labelErrorFee.Size = new System.Drawing.Size(10, 13);
            this.labelErrorFee.TabIndex = 36;
            this.labelErrorFee.Text = ".";
            this.labelErrorFee.Click += new System.EventHandler(this.labelErrorFee_Click);
            // 
            // errorProviderMembersFirstName
            // 
            this.errorProviderMembersFirstName.ContainerControl = this;
            // 
            // labelFullName
            // 
            this.labelFullName.AutoSize = true;
            this.labelFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFullName.Location = new System.Drawing.Point(220, 61);
            this.labelFullName.Name = "labelFullName";
            this.labelFullName.Size = new System.Drawing.Size(10, 15);
            this.labelFullName.TabIndex = 38;
            this.labelFullName.Text = ":";
            this.labelFullName.Click += new System.EventHandler(this.labelFullName_Click);
            // 
            // buttonFullName
            // 
            this.buttonFullName.Location = new System.Drawing.Point(136, 58);
            this.buttonFullName.Name = "buttonFullName";
            this.buttonFullName.Size = new System.Drawing.Size(75, 23);
            this.buttonFullName.TabIndex = 39;
            this.buttonFullName.Text = "Full Name";
            this.buttonFullName.UseVisualStyleBackColor = true;
            this.buttonFullName.Click += new System.EventHandler(this.buttonFullName_Click);
            // 
            // AnkitKundluMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 599);
            this.Controls.Add(this.buttonFullName);
            this.Controls.Add(this.labelFullName);
            this.Controls.Add(this.labelErrorFee);
            this.Controls.Add(this.labelErrorEmail);
            this.Controls.Add(this.labelErrorPhoneNumber);
            this.Controls.Add(this.labelErrorPostalCode);
            this.Controls.Add(this.labelErrorProvinceCode);
            this.Controls.Add(this.labelErrorCity);
            this.Controls.Add(this.labelErrorStreetAddress);
            this.Controls.Add(this.labelErrorSpousesLastName);
            this.Controls.Add(this.labelErrorSpousesFirstName);
            this.Controls.Add(this.labelErrorMembersLastName);
            this.Controls.Add(this.labelErrorMembersFirstName);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.buttonPreFill);
            this.Controls.Add(this.textBoxFee);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxHomePhone);
            this.Controls.Add(this.textBoxPostalCode);
            this.Controls.Add(this.textBoxProvinceCode);
            this.Controls.Add(this.textBoxCity);
            this.Controls.Add(this.textBoxStreetAddress);
            this.Controls.Add(this.textBoxSpousesLastName);
            this.Controls.Add(this.textBoxSpousesFirstName);
            this.Controls.Add(this.textBoxMembersLastName);
            this.Controls.Add(this.textBoxMembersFirstName);
            this.Controls.Add(this.labelFee);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelHomePhone);
            this.Controls.Add(this.labelPostalCode);
            this.Controls.Add(this.labelProvinceCode);
            this.Controls.Add(this.labelCity);
            this.Controls.Add(this.labelStreetAddress);
            this.Controls.Add(this.labelSpousesLastName);
            this.Controls.Add(this.labelSpousesFirstname);
            this.Controls.Add(this.labelMembersLastName);
            this.Controls.Add(this.labelMembersFirstName);
            this.Controls.Add(this.labelMemberMaintenance);
            this.Name = "AnkitKundluMember";
            this.Text = "Ankit Kundlu Member";
            this.Load += new System.EventHandler(this.AnkitKundluMember_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderMembersFirstName)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelMemberMaintenance;
        private System.Windows.Forms.Label labelMembersFirstName;
        private System.Windows.Forms.Label labelMembersLastName;
        private System.Windows.Forms.Label labelSpousesFirstname;
        private System.Windows.Forms.Label labelSpousesLastName;
        private System.Windows.Forms.Label labelStreetAddress;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.Label labelProvinceCode;
        private System.Windows.Forms.Label labelPostalCode;
        private System.Windows.Forms.Label labelHomePhone;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelFee;
        private System.Windows.Forms.TextBox textBoxMembersFirstName;
        private System.Windows.Forms.TextBox textBoxMembersLastName;
        private System.Windows.Forms.TextBox textBoxSpousesFirstName;
        private System.Windows.Forms.TextBox textBoxSpousesLastName;
        private System.Windows.Forms.TextBox textBoxStreetAddress;
        private System.Windows.Forms.TextBox textBoxCity;
        private System.Windows.Forms.TextBox textBoxProvinceCode;
        private System.Windows.Forms.TextBox textBoxPostalCode;
        private System.Windows.Forms.TextBox textBoxHomePhone;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxFee;
        private System.Windows.Forms.Button buttonPreFill;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label labelErrorMembersFirstName;
        private System.Windows.Forms.Label labelErrorMembersLastName;
        private System.Windows.Forms.Label labelErrorSpousesFirstName;
        private System.Windows.Forms.Label labelErrorSpousesLastName;
        private System.Windows.Forms.Label labelErrorStreetAddress;
        private System.Windows.Forms.Label labelErrorCity;
        private System.Windows.Forms.Label labelErrorProvinceCode;
        private System.Windows.Forms.Label labelErrorPostalCode;
        private System.Windows.Forms.Label labelErrorPhoneNumber;
        private System.Windows.Forms.Label labelErrorEmail;
        private System.Windows.Forms.Label labelErrorFee;
        private System.Windows.Forms.ErrorProvider errorProviderMembersFirstName;
        private System.Windows.Forms.Label labelFullName;
        private System.Windows.Forms.Button buttonFullName;
    }
}

