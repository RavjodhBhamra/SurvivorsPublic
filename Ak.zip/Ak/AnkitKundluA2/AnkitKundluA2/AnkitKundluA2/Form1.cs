﻿/*
 *  Purpose : Assignment #2
 * 
 * Purpose ID : To create Info Form
 * 
 * Revision History : Created by Ankit Kundlu on 16th Feb 2018.
 * 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnkitKundluA2
{
    public partial class AnkitKundluMember : Form
    {
        public AnkitKundluMember()
        {
            InitializeComponent();
        }

        #region ButtonsCloseSubmitPreFill

        private void buttonFullName_Click(object sender, EventArgs e)
        {

            // delaration of strings for each text boxes
             string a = textBoxMembersFirstName.Text;
             string b = textBoxMembersLastName.Text;
             string c = textBoxSpousesFirstName.Text;
             string d = textBoxSpousesLastName.Text;

            //declaration of string for other textboxes other than for First and last names
            string f = textBoxStreetAddress.Text;
            string g = textBoxCity.Text;
            string h = textBoxProvinceCode.Text;
            string i = textBoxHomePhone.Text;
            string j = textBoxEmail.Text;
            string k = textBoxFee.Text;

            k = k +  " $ " + "  " +  ".00"; // Adds two decimal place in Fee textBox with "$" symbol in front
           
           


            // trims the space in text Boxes of Fist and Last names of Member and Spouse
            a = a.Trim();
            b = b.Trim();
            c = c.Trim();
            d = d.Trim();

            // trims the space for remaining text boxes other than names 
            f = f.Trim();
            g = g.Trim();
            h = h.Trim();
            i = i.Trim();
            j = j.Trim();
            k = k.Trim();


            // displays trimmed names in the respective text boxes
            textBoxMembersFirstName.Text = a;
            textBoxMembersLastName.Text = b;
            textBoxSpousesFirstName.Text = c;
            textBoxSpousesLastName.Text = d;

            // displays trimmed names in the respective text boxes
             textBoxStreetAddress.Text = f;
             textBoxCity.Text = g;
             textBoxProvinceCode.Text = h;
             textBoxHomePhone.Text = i;
             textBoxEmail.Text = j;
             textBoxFee.Text = k;

   
            // Following are conditions to display Members and Spouse names on the top of the form

            if ( b == d || string.IsNullOrEmpty(d)) // if LName of both are same or Lname of spouse if empty 
             {
              
                labelFullName.Text = b + " , " + a + " & " + c;
                 
            }

             if (string.IsNullOrEmpty(c) && string.IsNullOrEmpty(d)) // if there is no spouse
             {
              
                labelFullName.Text = b + " , " + a;
                 
            } 

             if( b != d) // if member and spouse have different last name
             {
               
                labelFullName.Text = b + " , " + a + " & " + d + " , " + c;
                 
            }

             if(string.IsNullOrEmpty(a) && string.IsNullOrEmpty(b) && string.IsNullOrEmpty(c) && string.IsNullOrEmpty(d))
             {
                 labelFullName.Text = " Please enter Names"; // if all name boxes are empty indicates user to write names.
                 this.labelFullName.ForeColor = Color.Red; // changes the color to red
             }

            

        }
        private void buttonClose_Click(object sender, EventArgs e)
        {
              this.Close();  // Closes the form
       
        }
        #region Button Submit
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxMembersFirstName.Text))  // Label Error for First Text Box (textBoxMembersFirstName)
            {
                labelErrorMembersFirstName.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxMembersFirstName.Clear();
                labelErrorMembersFirstName.Text = " ";


            }

            if (string.IsNullOrEmpty(textBoxMembersLastName.Text)) // Label Error for Second Text Box(textBoxMembersLastName)
            {
                labelErrorMembersLastName.Text = " *Space Cannot Be empty  ";
            }
            else
            {
                textBoxMembersLastName.Clear();
                labelErrorMembersLastName.Text = "  ";
            }

            if (string.IsNullOrEmpty(textBoxSpousesFirstName.Text)) // Label Error for Third Text Box(textBoxSpousesFirstName)
            {
                labelErrorSpousesFirstName.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxSpousesFirstName.Clear();
                labelErrorSpousesFirstName.Text = "  ";
            }


            if (string.IsNullOrEmpty(textBoxSpousesLastName.Text)) // Label Error for Fourth Text Box Text Box(textBoxSpousesLastName)
            {
                labelErrorSpousesLastName.Text = " Space Acceptable only If\n Member and Spouse have\n same last name ";
                this.labelErrorSpousesLastName.ForeColor = Color.Green;
            }
            else
            {
                textBoxSpousesLastName.Clear();
                labelErrorSpousesLastName.Text = "  ";
            }

            if (string.IsNullOrEmpty(textBoxStreetAddress.Text)) // Label Error for Fifth Text Box Text Box(textBoxStreetAddress)
            {
                labelErrorStreetAddress.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxStreetAddress.Clear();
                labelErrorStreetAddress.Text = "  ";
            }

            if (string.IsNullOrEmpty(textBoxCity.Text)) //Label Error for Sixth Text Box Text Box(textBoxCity)
            {
                labelErrorCity.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxCity.Clear();
                labelErrorCity.Text = "  ";
            }


            if (string.IsNullOrEmpty(textBoxProvinceCode.Text)) // Label Error for Seventh Text Box Text Box(textBoxProvinceCode)
            {
                labelErrorProvinceCode.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxProvinceCode.Clear();
                labelErrorProvinceCode.Text = "  ";
            }
/*
            else if (textBoxProvinceCode.Text.Length > 2) // Allows user to enter only 2 Characters
            {
                labelErrorProvinceCode.Text = " Only two characters are allowed !";
                this.labelErrorProvinceCode.ForeColor = Color.Red;  // changes color to Red if Number is valid
            }
            else if (textBoxProvinceCode.Text.Length == 2)
            {
                labelErrorProvinceCode.Text = " Characters are valid ";
                this.labelErrorProvinceCode.ForeColor = Color.Green;  // changes color to green if Number is valid
            }*/

            if (string.IsNullOrEmpty(textBoxPostalCode.Text)) // Label Error for Eighth Text Box Text Box(textBoxPostalCode)
            {
                labelErrorPostalCode.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxPostalCode.Clear();
                labelErrorPostalCode.Text = "  ";
            }

            if (string.IsNullOrEmpty(textBoxHomePhone.Text)) // Label Error for Nineth Text Box Text Box(textBoxHomePhone)
            {
                labelErrorPhoneNumber.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxHomePhone.Clear();
                labelErrorPhoneNumber.Text = "  ";
            }

            if (string.IsNullOrEmpty(textBoxEmail.Text)) // Label Error for Tenth Text Box Text Box(textBoxEmail)
            {
                labelErrorEmail.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxEmail.Clear();
                labelErrorEmail.Text = "  ";
            }

            if (string.IsNullOrEmpty(textBoxFee.Text)) // Label Error for eleventh Text Box Text Box(textBoxFee)
            {
                labelErrorFee.Text = " *Space Cannot Be empty ";
            }
            else
            {
                textBoxFee.Clear();
                labelErrorFee.Text = "  ";
            }

            labelFullName.Text = "  ";  // Clears Full Name label when clicked on Submit button

        }
        #endregion
        private void buttonPreFill_Click(object sender, EventArgs e)
        {
            textBoxMembersFirstName.Text = "Shania  ";             // Fills the form to give an example About Form .
            textBoxMembersLastName.Text = "Twain  ";
            textBoxSpousesFirstName.Text = "Russell ";
            textBoxSpousesLastName.Text = "Crowe ";
            textBoxStreetAddress.Text = "170 Old Carriage Drive ";
            textBoxCity.Text = "Kitchener ";
            textBoxProvinceCode.Text = "ON  ";
            textBoxPostalCode.Text = "N2P 1Z7 ";
            textBoxHomePhone.Text = "519-729-7030 ";
            textBoxEmail.Text = "ankitkundlu32gmail.com ";
            textBoxFee.Text = "100 ";

            labelErrorMembersFirstName.Text = " ";      // Clears the Error labels if any active, due to invalid submission( Clicking Submit Button) of form   
            labelErrorMembersLastName.Text = "  ";
            labelErrorSpousesFirstName.Text = "  ";
            labelErrorSpousesLastName.Text = "  ";
            labelErrorStreetAddress.Text = "  ";
            labelErrorCity.Text = "  ";
            labelErrorProvinceCode.Text = "  ";
            labelErrorPostalCode.Text = "  ";
            labelErrorPhoneNumber.Text = "  ";
            labelErrorEmail.Text = "  ";
            labelErrorFee.Text = "  ";
            labelFullName.Text = " Twain, Shania & Crowe, Russell "; // Shows sample of full name in Full name label at top of the form 
            this.labelFullName.ForeColor = Color.Black; // shows above names in Black if Pre-Filled after submitting the form
        }
        #endregion



        #region TextBoxes
        private void textBoxMembersFirstName_TextChanged(object sender, EventArgs e)
        {
           // Will make the First Letter Capital if there is no space in First Position
            if ((textBoxMembersFirstName.Text.Length) == 1)
              {
                  textBoxMembersFirstName.Text = textBoxMembersFirstName.Text[0].ToString().ToUpper();
                  textBoxMembersFirstName.Select(2, 1);
              }

            // Will make first letter capital of every new word afterspace i.e Title Case.
            textBoxMembersFirstName.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.textBoxMembersFirstName.Text);
            textBoxMembersFirstName.Select(textBoxMembersFirstName.Text.Length, 0);
        }

        private void textBoxMembersLastName_TextChanged(object sender, EventArgs e)
        {
            // Will make the First Letter Capital if there is no space in First Position
            if ((textBoxMembersLastName.Text.Length) == 1)
            {
                textBoxMembersLastName.Text = textBoxMembersLastName.Text[0].ToString().ToUpper();
                textBoxMembersLastName.Select(2, 1);
            }

            // Will make first letter capital of every new word afterspace i.e Title Case.
            textBoxMembersLastName.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.textBoxMembersLastName.Text);
            textBoxMembersLastName.Select(textBoxMembersLastName.Text.Length, 0);
        }

        private void textBoxSpousesFirstName_TextChanged(object sender, EventArgs e)
        {
            // Will make the First Letter Capital if there is no space in First Position
            if ((textBoxSpousesFirstName.Text.Length) == 1)
            {
                textBoxSpousesFirstName.Text = textBoxSpousesFirstName.Text[0].ToString().ToUpper();
                textBoxSpousesFirstName.Select(2, 1);
            }

            // Will make first letter capital of every new word afterspace i.e Title Case.
            textBoxSpousesFirstName.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.textBoxSpousesFirstName.Text);
            textBoxSpousesFirstName.Select(textBoxSpousesFirstName.Text.Length, 0);
        }

        private void textBoxSpousesLastName_TextChanged(object sender, EventArgs e)
        {
            // Will make the First Letter Capital if there is no space in First Position
            if ((textBoxSpousesLastName.Text.Length) == 1)
            {
                textBoxSpousesLastName.Text = textBoxSpousesLastName.Text[0].ToString().ToUpper();
                textBoxSpousesLastName.Select(2, 1);
            }

            // Will make first letter capital of every new word afterspace i.e Title Case.
            textBoxSpousesLastName.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.textBoxSpousesLastName.Text);
            textBoxSpousesLastName.Select(textBoxSpousesLastName.Text.Length, 0);
        }

        private void textBoxStreetAddress_TextChanged(object sender, EventArgs e)
        {
            // Will make the First Letter Capital if there is no space in First Position
            if ((textBoxStreetAddress.Text.Length) == 1)
            {
                textBoxStreetAddress.Text = textBoxStreetAddress.Text[0].ToString().ToUpper();
                textBoxStreetAddress.Select(2, 1);
            }
            
            // Will make first letter capital of every new word afterspace i.e Title Case.
            textBoxStreetAddress.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.textBoxStreetAddress.Text);
            textBoxStreetAddress.Select(textBoxStreetAddress.Text.Length, 0);
        }

        private void textBoxCity_TextChanged(object sender, EventArgs e)
        {
            // Will make the First Letter Capital if there is no space in First Position
            if ((textBoxCity.Text.Length) == 1)
            {
                textBoxCity.Text = textBoxCity.Text[0].ToString().ToUpper();
                textBoxCity.Select(2, 1);
            }

            // Will make first letter capital of every new word afterspace i.e Title Case.
            textBoxCity.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.textBoxCity.Text);
            textBoxCity.Select(textBoxCity.Text.Length, 0);
        }

        private void textBoxProvinceCode_TextChanged(object sender, EventArgs e)
        {
            // Will make the Letter Capital if there is no space in First Position
            if ((textBoxProvinceCode.Text.Length) == 1)
            {
                textBoxProvinceCode.Text = textBoxProvinceCode.Text[0].ToString().ToUpper();    
                textBoxProvinceCode.Select(2,2);
            }

            if (textBoxProvinceCode.Text.Length > 2) // Allows user to enter only 2 Characters
            {
                labelErrorProvinceCode.Text = " Only two characters are allowed !";
                this.labelErrorProvinceCode.ForeColor = Color.Red;  // changes color to Red if Number is valid
            }
            else if (textBoxProvinceCode.Text.Length == 2)
            {
                labelErrorProvinceCode.Text = " Characters are valid ";
                this.labelErrorProvinceCode.ForeColor = Color.Green;  // changes color to green if Number is valid
            }
            else if (string.IsNullOrEmpty(textBoxProvinceCode.Text))
            {
                labelErrorProvinceCode.Text = " Space Cannot Be empty ";
                this.labelErrorProvinceCode.ForeColor = Color.Red;  // changes color to Red if Number is valid
            }
        }

        private void textBoxPostalCode_TextChanged(object sender, EventArgs e)
        {
           
            
            // Will make Postal Code Valid as per Canadian postal Code pattern
            Regex validator = new Regex("^[ABCEGHJ-NPRSTVXY]{1}[0-9]{1}[ABCEGHJ-NPRSTV-Z]{1}[ ]?[0-9]{1}[ABCEGHJ-NPRSTV-Z]{1}[0-9]{1}$");

            if (validator.Match(textBoxPostalCode.Text).Success)
            {
                labelErrorPostalCode.Text = "Valid";
                this.labelErrorPostalCode.ForeColor = Color.Green;  // changes color to green if Number is valid
            }
            else
            {
                labelErrorPostalCode.Text = " Invalid ";
                this.labelErrorPostalCode.ForeColor = Color.Red;  // changes color to Red if Number is valid
            }

        }

        private void textBoxHomePhone_TextChanged(object sender, EventArgs e)
        {
            // This will Show "valid or Invalid" as per Canadian Phone number Sequence 
            string i = textBoxHomePhone.Text;
            Regex validator = new Regex("^[3-9][0-9]{9}$");

            if (validator.Match(textBoxHomePhone.Text).Success)
            {
                labelErrorPhoneNumber.Text = "Valid";
                this.labelErrorPhoneNumber.ForeColor = Color.Green;  // changes color to green if Number is valid
               /* i.Insert(3, " - ");
                i.Insert(7, " - ");*/
                 string phoneNumberString = String.Format("{0:(000) 000-0000 x0000}", i);
            }
            else
            {
                labelErrorPhoneNumber.Text = "Invalid, Keep typing!!";
                this.labelErrorPhoneNumber.ForeColor = Color.Red;  // changes color to Red if Number is valid
            }
            
        }

        private void textBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxFee_TextChanged(object sender, EventArgs e)
        {
            
           

        }
        #endregion

        #region ErrorLabels

        private void labelFullName_Click(object sender, EventArgs e)
        {
            

        }

        private void labelErrorMembersFirstName_Click(object sender, EventArgs e)
        {


        }

        private void labelErrorMembersLastName_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorSpousesFirstName_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorSpousesLastName_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorStreetAddress_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorCity_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorProvinceCode_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorPostalCode_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorPhoneNumber_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorEmail_Click(object sender, EventArgs e)
        {

        }

        private void labelErrorFee_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Validating Mothods
        private void textBoxEmail_Validating(object sender, CancelEventArgs e)    // Validating Method of TextBoxEmail
        {
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (textBoxEmail.Text.Length > 0)
            {
                if (!rEMail.IsMatch(textBoxEmail.Text))
                {
                    MessageBox.Show("Invalid email address", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxEmail.SelectAll();
                    textBoxEmail.Clear();
                    e.Cancel = true;

                    labelErrorMembersFirstName.Text = " Space Cannot Be empty ";   // All these show empty space error if you try just e mail      
                    labelErrorMembersLastName.Text = " Space Cannot Be empty ";    // and leave other text boxes empty
                    labelErrorSpousesFirstName.Text = " Space Cannot Be empty ";
                    labelErrorSpousesLastName.Text = " Space Cannot Be empty  ";
                    labelErrorStreetAddress.Text = " Space Cannot Be empty ";
                    labelErrorCity.Text = " Space Cannot Be empty ";
                    labelErrorProvinceCode.Text = " Space Cannot Be empty ";
                    labelErrorPostalCode.Text = " Space Cannot Be empty ";
                    labelErrorPhoneNumber.Text = " Space Cannot Be empty";
                    labelErrorFee.Text = " Space Cannot Be empty ";
                    this.labelErrorEmail.ForeColor = Color.Red;  // changes color to Red if Entrty is Invalid
                }
               
            }

        }

    
        #endregion

        #region KeyPress Methods of text boxes 
        private void textBoxMembersFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }

        private void textBoxMembersLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void textBoxSpousesFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }

        private void textBoxSpousesLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void textBoxStreetAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }

        private void textBoxCity_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void textBoxProvinceCode_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }

        private void textBoxPostalCode_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }
        private void textBoxHomePhone_KeyPress(object sender, KeyPressEventArgs e) 
        {
            if (textBoxHomePhone.Text.Length == 0) // It will not allow space at first position of textbox
            {
                if (e.Handled = (e.KeyChar == (char)Keys.Space))
                {
                    MessageBox.Show(" Space is not allowed at first position");
                }
            } 

            char ch = e.KeyChar;             //KeyPress Event which will accept only numeric entries of user including Backspace
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBoxEmail_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBoxFee_KeyPress(object sender, KeyPressEventArgs e)
        {
 
        }
        #endregion

        #region KeyDown Events

        private void textBoxMembersFirstName_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void textBoxMembersLastName_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void textBoxSpousesFirstName_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void textBoxSpousesLastName_KeyDown(object sender, KeyEventArgs e)
        {
            

        }

        private void textBoxStreetAddress_KeyDown(object sender, KeyEventArgs e)
        {
            

        }

        private void textBoxCity_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void textBoxProvinceCode_KeyDown(object sender, KeyEventArgs e)
        {
           

        }

        private void textBoxPostalCode_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void textBoxHomePhone_KeyDown(object sender, KeyEventArgs e)
        {
            

        }

        private void textBoxEmail_KeyDown(object sender, KeyEventArgs e)
        {
            


        }
        private void textBoxFee_KeyDown(object sender, KeyEventArgs e)
        {
           
        }
        #endregion

        private void AnkitKundluMember_Load(object sender, EventArgs e)
        {

        }

        private void labelFullNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void textBoxFee_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (textBoxFee.Text.Length == 0) // It will not allow space at first position of textbox
            {
                if (e.Handled = (e.KeyChar == (char)Keys.Space))
                {
                    MessageBox.Show(" Space is not allowed at first position");
                }
            }
            char ch = e.KeyChar;             //KeyPress Event which will accept only numeric entries of user including Backspace
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }
    }

 }

