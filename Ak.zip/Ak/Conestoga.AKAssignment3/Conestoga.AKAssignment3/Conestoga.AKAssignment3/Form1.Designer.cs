﻿namespace Conestoga.AKAssignment3
{
    partial class Assignment3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPath = new System.Windows.Forms.Label();
            this.btnAddNewRecord = new System.Windows.Forms.Button();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.btnDeleteAll = new System.Windows.Forms.Button();
            this.btnDeleteByTransactNo = new System.Windows.Forms.Button();
            this.txtTransactNo = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtSerialNo = new System.Windows.Forms.TextBox();
            this.txtTools = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblTransactNo = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblSerialNo = new System.Windows.Forms.Label();
            this.lblTools = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.txtDataDiaplay = new System.Windows.Forms.RichTextBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtFilePath = new System.Windows.Forms.TextBox();
            this.radOpenExistingFile = new System.Windows.Forms.RadioButton();
            this.radCreateNewFile = new System.Windows.Forms.RadioButton();
            this.btnOpenOrCreate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPath
            // 
            this.lblPath.AutoSize = true;
            this.lblPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPath.Location = new System.Drawing.Point(30, 16);
            this.lblPath.Name = "lblPath";
            this.lblPath.Size = new System.Drawing.Size(47, 16);
            this.lblPath.TabIndex = 0;
            this.lblPath.Text = "Path :";
            // 
            // btnAddNewRecord
            // 
            this.btnAddNewRecord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnAddNewRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewRecord.Location = new System.Drawing.Point(83, 97);
            this.btnAddNewRecord.Name = "btnAddNewRecord";
            this.btnAddNewRecord.Size = new System.Drawing.Size(135, 23);
            this.btnAddNewRecord.TabIndex = 2;
            this.btnAddNewRecord.Text = "Add New Record";
            this.btnAddNewRecord.UseVisualStyleBackColor = false;
            this.btnAddNewRecord.Click += new System.EventHandler(this.btnAddNewRecord_Click);
            // 
            // btnShowAll
            // 
            this.btnShowAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnShowAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowAll.Location = new System.Drawing.Point(251, 97);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new System.Drawing.Size(135, 23);
            this.btnShowAll.TabIndex = 3;
            this.btnShowAll.Text = "Show All";
            this.btnShowAll.UseVisualStyleBackColor = false;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
            // 
            // btnDeleteAll
            // 
            this.btnDeleteAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnDeleteAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteAll.Location = new System.Drawing.Point(444, 97);
            this.btnDeleteAll.Name = "btnDeleteAll";
            this.btnDeleteAll.Size = new System.Drawing.Size(135, 23);
            this.btnDeleteAll.TabIndex = 5;
            this.btnDeleteAll.Text = "Delete All";
            this.btnDeleteAll.UseVisualStyleBackColor = false;
            this.btnDeleteAll.Click += new System.EventHandler(this.btnDeleteAll_Click);
            // 
            // btnDeleteByTransactNo
            // 
            this.btnDeleteByTransactNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnDeleteByTransactNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteByTransactNo.Location = new System.Drawing.Point(628, 97);
            this.btnDeleteByTransactNo.Name = "btnDeleteByTransactNo";
            this.btnDeleteByTransactNo.Size = new System.Drawing.Size(147, 23);
            this.btnDeleteByTransactNo.TabIndex = 6;
            this.btnDeleteByTransactNo.Text = "Delete By Transact No.";
            this.btnDeleteByTransactNo.UseVisualStyleBackColor = false;
            this.btnDeleteByTransactNo.Click += new System.EventHandler(this.btnDeleteByTransactNo_Click);
            // 
            // txtTransactNo
            // 
            this.txtTransactNo.Location = new System.Drawing.Point(15, 156);
            this.txtTransactNo.Name = "txtTransactNo";
            this.txtTransactNo.Size = new System.Drawing.Size(95, 20);
            this.txtTransactNo.TabIndex = 7;
            this.txtTransactNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTransactNo_KeyPress);
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(141, 156);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(100, 20);
            this.txtDate.TabIndex = 8;
            this.txtDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDate_KeyPress);
            // 
            // txtSerialNo
            // 
            this.txtSerialNo.Location = new System.Drawing.Point(266, 156);
            this.txtSerialNo.Name = "txtSerialNo";
            this.txtSerialNo.Size = new System.Drawing.Size(100, 20);
            this.txtSerialNo.TabIndex = 9;
            this.txtSerialNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSerialNo_KeyPress);
            // 
            // txtTools
            // 
            this.txtTools.Location = new System.Drawing.Point(389, 156);
            this.txtTools.Name = "txtTools";
            this.txtTools.Size = new System.Drawing.Size(166, 20);
            this.txtTools.TabIndex = 10;
            this.txtTools.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTools_KeyPress);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(586, 156);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(108, 20);
            this.txtPrice.TabIndex = 11;
            this.txtPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrice_KeyPress);
            this.txtPrice.Leave += new System.EventHandler(this.txtPrice_Leave);
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(732, 156);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(100, 20);
            this.txtQuantity.TabIndex = 12;
            this.txtQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantity_KeyPress);
            // 
            // lblTransactNo
            // 
            this.lblTransactNo.AutoSize = true;
            this.lblTransactNo.Location = new System.Drawing.Point(12, 140);
            this.lblTransactNo.Name = "lblTransactNo";
            this.lblTransactNo.Size = new System.Drawing.Size(69, 13);
            this.lblTransactNo.TabIndex = 13;
            this.lblTransactNo.Text = "Transact No.";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(138, 140);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(94, 13);
            this.lblDate.TabIndex = 14;
            this.lblDate.Text = "Date(dd/mm/yyyy)";
            // 
            // lblSerialNo
            // 
            this.lblSerialNo.AutoSize = true;
            this.lblSerialNo.Location = new System.Drawing.Point(263, 140);
            this.lblSerialNo.Name = "lblSerialNo";
            this.lblSerialNo.Size = new System.Drawing.Size(53, 13);
            this.lblSerialNo.TabIndex = 15;
            this.lblSerialNo.Text = "Serial No.";
            // 
            // lblTools
            // 
            this.lblTools.AutoSize = true;
            this.lblTools.Location = new System.Drawing.Point(386, 140);
            this.lblTools.Name = "lblTools";
            this.lblTools.Size = new System.Drawing.Size(33, 13);
            this.lblTools.TabIndex = 16;
            this.lblTools.Text = "Tools";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(583, 140);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 17;
            this.lblPrice.Text = "Price";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(729, 140);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(46, 13);
            this.lblQuantity.TabIndex = 18;
            this.lblQuantity.Text = "Quantity";
            // 
            // txtDataDiaplay
            // 
            this.txtDataDiaplay.Location = new System.Drawing.Point(15, 195);
            this.txtDataDiaplay.Name = "txtDataDiaplay";
            this.txtDataDiaplay.Size = new System.Drawing.Size(817, 347);
            this.txtDataDiaplay.TabIndex = 19;
            this.txtDataDiaplay.Text = "";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.Red;
            this.lblMessage.Location = new System.Drawing.Point(12, 552);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(29, 16);
            this.lblMessage.TabIndex = 20;
            this.lblMessage.Text = "* * *";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Red;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(703, 552);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(110, 37);
            this.btnClose.TabIndex = 21;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtFilePath
            // 
            this.txtFilePath.Location = new System.Drawing.Point(83, 12);
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.Size = new System.Drawing.Size(749, 20);
            this.txtFilePath.TabIndex = 22;
            // 
            // radOpenExistingFile
            // 
            this.radOpenExistingFile.AutoSize = true;
            this.radOpenExistingFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radOpenExistingFile.Location = new System.Drawing.Point(83, 46);
            this.radOpenExistingFile.Name = "radOpenExistingFile";
            this.radOpenExistingFile.Size = new System.Drawing.Size(142, 19);
            this.radOpenExistingFile.TabIndex = 23;
            this.radOpenExistingFile.TabStop = true;
            this.radOpenExistingFile.Text = "Open Existing File";
            this.radOpenExistingFile.UseVisualStyleBackColor = true;
            // 
            // radCreateNewFile
            // 
            this.radCreateNewFile.AutoSize = true;
            this.radCreateNewFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radCreateNewFile.Location = new System.Drawing.Point(231, 46);
            this.radCreateNewFile.Name = "radCreateNewFile";
            this.radCreateNewFile.Size = new System.Drawing.Size(127, 19);
            this.radCreateNewFile.TabIndex = 24;
            this.radCreateNewFile.TabStop = true;
            this.radCreateNewFile.Text = "Create New File";
            this.radCreateNewFile.UseVisualStyleBackColor = true;
            // 
            // btnOpenOrCreate
            // 
            this.btnOpenOrCreate.BackColor = System.Drawing.Color.Blue;
            this.btnOpenOrCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenOrCreate.ForeColor = System.Drawing.Color.White;
            this.btnOpenOrCreate.Location = new System.Drawing.Point(364, 41);
            this.btnOpenOrCreate.Name = "btnOpenOrCreate";
            this.btnOpenOrCreate.Size = new System.Drawing.Size(135, 29);
            this.btnOpenOrCreate.TabIndex = 25;
            this.btnOpenOrCreate.Text = "Open / Create";
            this.btnOpenOrCreate.UseVisualStyleBackColor = false;
            this.btnOpenOrCreate.Click += new System.EventHandler(this.btnOpenOrCreate_Click);
            // 
            // Assignment3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(852, 595);
            this.Controls.Add(this.btnOpenOrCreate);
            this.Controls.Add(this.radCreateNewFile);
            this.Controls.Add(this.radOpenExistingFile);
            this.Controls.Add(this.txtFilePath);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.txtDataDiaplay);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblTools);
            this.Controls.Add(this.lblSerialNo);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblTransactNo);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtTools);
            this.Controls.Add(this.txtSerialNo);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.txtTransactNo);
            this.Controls.Add(this.btnDeleteByTransactNo);
            this.Controls.Add(this.btnDeleteAll);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.btnAddNewRecord);
            this.Controls.Add(this.lblPath);
            this.Name = "Assignment3";
            this.Text = "Conestoga.AnkitKundluAssignment3";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPath;
        private System.Windows.Forms.Button btnAddNewRecord;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.Button btnDeleteAll;
        private System.Windows.Forms.Button btnDeleteByTransactNo;
        private System.Windows.Forms.TextBox txtTransactNo;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtSerialNo;
        private System.Windows.Forms.TextBox txtTools;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblTransactNo;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblSerialNo;
        private System.Windows.Forms.Label lblTools;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.RichTextBox txtDataDiaplay;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtFilePath;
        private System.Windows.Forms.RadioButton radOpenExistingFile;
        private System.Windows.Forms.RadioButton radCreateNewFile;
        private System.Windows.Forms.Button btnOpenOrCreate;
    }
}

