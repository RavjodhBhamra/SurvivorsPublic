﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * This is a windows form app that functions to keep track of 
 * records purchased by the Organisation.
 * 
 * Specifically, this windows for app will allow user to
 * create a ".txt" file to add record and 
 * Enter record, Read the record, Delete the whole Record,
 * delete the record by Transact No. provided by user
 * 
 * Ankit Ravindra Kundlu, 2018.03.16 : Created
 * 
 */
namespace Conestoga.AKAssignment3
{
    public partial class Assignment3 : Form
    {
        // Declaration of global varialbels.
        StreamWriter writer;
        StreamReader reader;
        string answer;
        string record = "";
        string path = "";
        
        public Assignment3()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        /// <summary>
        /// This region consists of All buttons.
        /// </summary>
        /// <param name="sender">The event sender(for all buttons)</param>
        /// <param name="e">The event arguments(for all buttons)</param>
        #region Buttons

        // This Button "Creates new file" or "Opens existing file"
        //as per user selection of radio Buttons
        private void btnOpenOrCreate_Click(object sender, EventArgs e)
        {
            // Condition if Radio Buttons Not Checked by user
            if (!radOpenExistingFile.Checked && !radCreateNewFile.Checked)
            {
                MessageBox.Show("Please select the option\n\n" +
                         "\"Open Existing File\" OR \"Create new file\"\n " +
                               "\n to perform action");
            }
            else
            {   
                // If Radio Button checked and ".txt" File exist & Viceversa
                if (radOpenExistingFile.Checked && File.Exists(path))
                {
                    MessageBox.Show(" File Opened Successfully \n " +
                                   " Now you can access the opened file\n" +
                                   "  and Add record to it");
                }
                else if (radOpenExistingFile.Checked && !File.Exists(path))
                {
                    MessageBox.Show("File Does not exist \n\n" +
                              "To open file you need to create a file by\n\n" +
                                  "selecting \"Create new file\" option");

                }

                // If Button checked and ".txt" File dosen't exist & Viceversa
                if (radCreateNewFile.Checked && !File.Exists(path) && 
                    (!string.IsNullOrWhiteSpace(txtFilePath.Text)))
                {
                    try
                    {
                        path = String.Format(txtFilePath.Text+ ".txt");
                        writer = File.AppendText(path);
                        MessageBox.Show("File created Successfully");
                        writer.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Please enter File name\n" +
                                        $"Error\n:{ex.Message}");
                    }  
                }
                else if (radCreateNewFile.Checked && File.Exists(path))
                {
                    MessageBox.Show("File already exist");
                } 
                else
                {
                    MessageBox.Show("Make sure you have " +
                                   "entered file name ");
                }
            }
        }

        // This button adds new record to the "txt" file,   
        private void btnAddNewRecord_Click(object sender, EventArgs e)
        {
            if (File.Exists(path = String.Format(txtFilePath.Text + ".txt"))
                && txtFilePath.Text != null)
            {
                using (writer = File.AppendText(path))
                {
                    try
                    {
                        if (((string.IsNullOrWhiteSpace(txtTransactNo.Text)) ||
                            (string.IsNullOrWhiteSpace(txtDate.Text)) ||
                            (string.IsNullOrWhiteSpace(txtSerialNo.Text)) ||
                             (string.IsNullOrWhiteSpace(txtTools.Text)) ||
                             (string.IsNullOrWhiteSpace(txtPrice.Text)) ||
                             (string.IsNullOrWhiteSpace(txtQuantity.Text)))
                             || ((txtTransactNo.Text.Length <= 0) ||
                             (txtDate.Text.Length <= 0) ||
                             (txtSerialNo.Text.Length <= 0) ||
                             (txtTools.Text.Length <= 0)
                             || (txtPrice.Text.Length <= 0) ||
                             (txtQuantity.Text.Length <= 0)))
                        {
                            lblMessage.Text = " Please fill all " +
                                              "the Information !!";
                            this.lblMessage.ForeColor = Color.Red;
                        }
                        else
                        {
                            // Alignment of text to display records 
                            // in "txt" file properly 
                            record = string.Format("{0, -30}{1, -30}" +
                                                   "{2, -30}{3, -30}" +
                                                   "{4, -30}{5, -30}", 
                                                   txtTransactNo.Text, 
                                                   txtDate.Text, 
                                                   txtSerialNo.Text, 
                                                   txtTools.Text, 
                                                   txtPrice.Text,
                                                   txtQuantity.Text);
                            try
                            {
                                writer.WriteLine(record);

                                // Gives Message to the user indicating 
                                // the data he/she wish to save.
                                MessageBox.Show("File >" +
                                             "\n----------------------------"
                                             + " \n Transact No : "
                                             + txtTransactNo.Text
                                             + "\n Date : "
                                             + txtDate.Text
                                             + "\n Serial No : "
                                             + txtSerialNo.Text
                                             + "\n Tool Purchased : "
                                             + txtTools.Text
                                             + "\n Price : "
                                             + txtPrice.Text
                                             + "\n Quantity : "
                                             + txtQuantity.Text
                                             + "\n-----------------------------"
                                             + "\n Created Successfully!!" +
                                             "\n Press Ok if Confirmed");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Error Writing record " +
                                                $"to the File\n:{ex.Message}");
                            }
                            finally
                            {
                                writer.Close();

                                // Clears all the TextBoxes after 
                                //data is entered
                                txtTransactNo.Text =
                                txtDate.Text = txtSerialNo.Text =
                                txtTools.Text = txtPrice.Text =
                                txtQuantity.Text = "";

                                // Clears Messagelabel (" *** ")
                                lblMessage.Text = "";

                                // Clears Display Screen 
                                txtDataDiaplay.Clear();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Please check you record " +
                                        $"you have entered\n:{ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("File does not exist \n" +
                            "\nOR\n make sure you have " +
                      "entered existing fileName(correct name)\n" +
                             "in which you want to add record");
            }
        }

        //this Button shows all the records of ".txt" file
        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (File.Exists(path = String.Format(txtFilePath.Text + ".txt"))
                  && txtFilePath.Text != null)
            {
                if (new FileInfo(path).Length == 0)
                {
                    MessageBox.Show("File contains no record to show");
                }
                else
                {
                    using (reader = new StreamReader(path))
                    {

                        while (!reader.EndOfStream)
                        {
                            try
                            {
                                // Creates Header Menu on the Screen followed 
                                //by the record of user.
                                txtDataDiaplay.Text = 
                                    $"{"Transact No.".PadRight(20)}"+
                                    $"\t{"Date".PadRight(20)}" +
                                    $"\t{"Serial No.".PadRight(30)}" +
                                    $"\t{"Tool".PadRight(25)}"+
                                    $"{"Price".PadRight(20)}" +
                                    $"\t{"Quantity".PadRight(20)}" +
                                    $"\n{"".PadRight(130, '_')}" +
                                    $"\n{"".PadRight(130, ' ')}" +
                                    $"\n "
                                    // reads the record
                                    + reader.ReadToEnd();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Error Reading the" +
                                                $" File\n:{ex.Message}");
                            }
                            finally
                            {
                                // Clears all the TextBoxes text
                                txtTransactNo.Text = txtDate.Text = 
                                txtSerialNo.Text= txtTools.Text = 
                                txtPrice.Text = txtQuantity.Text = "";

                                // Clears Messagelabel (" *** ")
                                lblMessage.Text = "";
                            }
                        }
                        reader.Close();
                    }
                }
            }
            else
            {
               MessageBox.Show(" File does not exist to show record to see\n" +
                             "record create new file and enter data to it\n" +
                              "\nOR\n make sure you have entered\n" +
                               " existing fileName(correct name)\n" +
                                "of which you want to see the record");
            }
        }

        //this button deletes the "txt" file
        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            if (File.Exists(path = String.Format(txtFilePath.Text + ".txt")) 
                     && txtFilePath.Text != null)
            {
                // Asks user if he/she wish to delete entire file
                answer = MessageBox.Show(" Deleting file will delete the\n " +
                               "file and will erase all data ", " Delete File "
                               ,MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Exclamation).ToString();

                if (answer == "OK")
                {
                    try
                    {
                        // Deletes the "txt" file.
                        File.Delete(path);
                        txtDataDiaplay.Clear();
                        MessageBox.Show(" File Deleted Successfully");
                    }
                    catch (Exception ex)   
                    {
                        MessageBox.Show($"Error Deleting File :{ex.Message}");
                    }

                    finally
                    { 
                        txtTransactNo.Text = txtDate.Text = txtSerialNo.Text
                       = txtTools.Text = txtPrice.Text = txtQuantity.Text = "";

                        // Clears Messagelabel (" *** ")
                        lblMessage.Text = "";
                    }

                }
            }
            else
            {
                MessageBox.Show(" File does not exist to be deleted" +
                             "OR make sure you have entered existing " +
                                "fileName(correct name)\n" +
                                " which you want to delete");
            }
        }

        // This button deletes the record as per Transact no. 
        //Provided by the user
        private void btnDeleteByTransactNo_Click(object sender, EventArgs e)
        {
            string transactNo = txtTransactNo.Text;
            string savedRecord;
            string n = "";

            if (File.Exists(path = String.Format(txtFilePath.Text + ".txt"))
                && txtFilePath.Text != null)
            {
                if (new FileInfo(path).Length == 0)
                {
                    MessageBox.Show("File contains no record to delete ");
                }
                else
                { 
                    using (StreamReader reader = File.OpenText(path))
                    {

                         if ((string.IsNullOrWhiteSpace(txtTransactNo.Text))
                            || ((txtTransactNo.Text.Length < 0)))
                         {
                             lblMessage.Text = " Please enter Transact No. " +
                                                      "to delete record !!";
                             this.lblMessage.ForeColor = Color.Red;
                         }
                         else
                         {
                            answer = MessageBox.Show(" Are you sure you" +
                                  " want to delete record" + " " + transactNo,
                                  " Delete File ", MessageBoxButtons.YesNo,
                                  MessageBoxIcon.Exclamation).ToString();

                             if (answer == "Yes")
                             {

                                // Clears Messagelabel (" *** ") which was 
                                //active due to above activity 
                                 lblMessage.Text = " ";

                                 try
                                 {
                                    while ((savedRecord = reader.ReadLine()) 
                                             != null)
                                     {
                                         if (!savedRecord.Contains(transactNo))
                                         {  
                                             n += savedRecord + 
                                             Environment.NewLine;
                                         }
                                    }
                                        
                                    reader.Close();

                                    /*Clears the Line as per "Transact No." 
                                      giving "txt" file
                                      empty string (i.e here string n = " ";)*/
                                    File.WriteAllText(path, n);

                                    //Gives Message of Record deleted
                                    MessageBox.Show("Record" + " " 
                                                     + transactNo + " "
                                                     + "deleted sucessfully");

                                        // Clears the Display Screen 
                                     txtDataDiaplay.Clear();

                                        // Clears Messagelabel (" *** ")
                                     lblMessage.Text = " ";

                                        // Clears "Transact No."
                                     txtTransactNo.Text = " ";
                                 }
                                   //Catches Error if any and alerts user
                                 catch (Exception ex)
                                 {
                                    MessageBox.Show($"Error deleting record " +
                                                 $"in the file\n:{ex.Message}");
                                 }
                             }
                         }   
                    }
                }
            }
            else
            {
                MessageBox.Show("File does not exist" +
                       "\nOR\n make sure you have entered existing " +
                           "fileName(correct name)\n" +
                          "of which you want to delete the line");
            }
        }

        //This button closes the form without erasing 
        //any data entered by the user
        private void btnClose_Click(object sender, EventArgs e)
        {
            answer = MessageBox.Show(" Are you sure you want to " +
                                       "close file and Exit",
                                     " Close File ", MessageBoxButtons.YesNo,
                                      MessageBoxIcon.Exclamation).ToString();

            if (answer == "Yes")
            {
                this.Close();
            }
        }
        #endregion


        /// <summary>
        /// This region consists of all keypress Events which 
        /// restricts space at first position
        /// of the textbox (for proper alignment of the texts). 
        /// Also it restricts any other characters 
        /// other than numbers, Backspace and decimal 
        /// in the textbox,(except for "Date" and "Tools" Textboxes)
        /// to make sure the input entry of user is a valid entry.
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        #region keyPress Events
        private void txtTransactNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            // It does not allow user to hit space at first position of textbox
            // so that data entered by user remains aligned 
            if (txtTransactNo.Text.Length == 0) 
            {
                if (e.Handled = (e.KeyChar == (char)Keys.Space))
                {
                    MessageBox.Show(" Space is not allowed at first position");
                }
            }

            // It restricts user to enter any other characters other than
            // Numbers, decimal piont and backspace
            char ch = e.KeyChar;             
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
                MessageBox.Show("Only numeric entries are allowed!");
            }
        }

        private void txtDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtPrice.Text.Length == 0)
            {
                if (e.Handled = (e.KeyChar == (char)Keys.Space))
                {
                    MessageBox.Show(" Space is not allowed at first position");
                }
            }
        }

        private void txtSerialNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtSerialNo.Text.Length == 0) 
            {
                if (e.Handled = (e.KeyChar == (char)Keys.Space))
                {
                    MessageBox.Show(" Space is not allowed at first position");
                }
            }

            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
                MessageBox.Show("Only numeric entries are allowed!");
            }
        }

        private void txtTools_KeyPress(object sender, KeyPressEventArgs e)
        {
            //It makes the name of tools in Title case irrespective of
            // tool name consists one, two or more words

            txtTools.Text = System.Threading.Thread.CurrentThread.
                    CurrentCulture.TextInfo.ToTitleCase(this.txtTools.Text);
                    txtTools.Select(txtTools.Text.Length, 0);
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtPrice.Text.Length == 0) 
            {
                if (e.Handled = (e.KeyChar == (char)Keys.Space))
                {
                    MessageBox.Show(" Space is not allowed at first position");
                }
            }
          
            char ch = e.KeyChar;            
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
                MessageBox.Show("Only numeric entries are allowed!");
            }       
        }

        // changes user input to currency format 
        private void txtPrice_Leave(object sender, EventArgs e)
        {
            double amount = 0.0d;
            if (Double.TryParse(txtPrice.Text, 
                                 NumberStyles.Currency, null, out amount))
            {
                txtPrice.Text = amount.ToString("C");
            }
        }

        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtQuantity.Text.Length == 0) 
            {
                if (e.Handled = (e.KeyChar == (char)Keys.Space))
                {
                    MessageBox.Show(" Space is not allowed at first position");
                }
            }
 
            char ch = e.KeyChar;            
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
                MessageBox.Show("Only numeric entries are allowed!");
            }
        }
        #endregion        
    }
}
