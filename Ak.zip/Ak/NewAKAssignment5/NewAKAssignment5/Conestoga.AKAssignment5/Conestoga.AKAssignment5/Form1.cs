﻿using Conestoga.AKAssignment5.AKUtilityClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 *This is a windows form app that functions to keep track of 
 * the validations and input Formats. 
 * 
 * Specifically, this windows for app will allow user to
 * enter record and check for the validations 
 * 
 * More specifically, it will convert invalid record to
 * desired format and pattern
 * 
 * Ankit Ravindra Kundlu, 2018.04.16 : Created 
 */

namespace Conestoga.AKAssignment5
{
    public partial class AKAssignment5 : Form
    {
        public AKAssignment5()
        {
            InitializeComponent();  
        }

        // Form load Event
        private void AKAssignment5_Load(object sender, EventArgs e)
        {
            // Keeps Error Msgs Clear for every method when form load
            lblMsgIsNumeric.Text = lblMsgIsInteger.Text = 
            lblMsgExtractNumeric.Text = lblMsgOnlyInputDigit.Text = 
            lblMsgCapatalize.Text = lblMsgExtractDigit.Text =
            lblMsgFormatPhone.Text = lblMsgFormatPostal.Text = 
            lblMsgFormatZip.Text = lblMsgFormatFullName.Text = 
            lblMsgValidatePostal.Text = lblMsgValidateZip.Text =
            lblMsgValidatePhone.Text = "";
        }

        //Submit Button : Keeps track of all methods being tested             
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Instantiation of Utility Classes globally for "btnSumit"
            AKNumericUtilities akNumericUtilities = new AKNumericUtilities();
            AKStringUtilities akStringUtilities = new AKStringUtilities();
            AKValidations akValidations = new AKValidations();

            #region Numeric Utilities

            // Uses "IsNumeric Method" to Check Numeric Value
            if (string.IsNullOrEmpty(txtIsNumeric.Text))
            {
                lblMsgIsNumeric.Text = " Space Cannot Be empty ";
                this.lblMsgIsNumeric.ForeColor = Color.Red;
            }
            else
            {
                if(!akNumericUtilities.AKIsNumeric(txtIsNumeric.Text))
                {
                    lblMsgIsNumeric.Text = "Value has character Or String";
                    this.lblMsgIsNumeric.ForeColor = Color.Red;
                }
                else
                {
                    lblMsgIsNumeric.Text = "Value Is Numeric";
                    this.lblMsgIsNumeric.ForeColor = Color.Green;               
                }  
            }

            // Uses "IsInteger Method" to Check Integer Value
            if (string.IsNullOrEmpty(txtIsInteger.Text))
            {
                lblMsgIsInteger.Text = " Space Cannot Be empty ";
                this.lblMsgIsInteger.ForeColor = Color.Red;
            }
            else
            {
                if(!akNumericUtilities.AKIsInteger(txtIsInteger.Text))
                {
                    lblMsgIsInteger.Text = " Value has Character Or String ";
                    this.lblMsgIsInteger.ForeColor = Color.Red;
                }
                else
                {
                    lblMsgIsInteger.Text = " Value is an Integer ";
                    this.lblMsgIsInteger.ForeColor = Color.Green;
                }
            }

            // Uses "ExtractNumeric Method" to Extract Numerics
            if (string.IsNullOrEmpty(txtExtractNumeric.Text))
            {
                lblMsgExtractNumeric.Text = " Space Cannot Be empty ";
            }
            else
            {
               

                lblMsgExtractNumeric.Text = " ";
            }

            // Uses "OnlyInputDigit Method" for input digits
            if (string.IsNullOrEmpty(txtOnlyInputDigit.Text))
            {
                lblMsgOnlyInputDigit.Text = " Space Cannot Be empty ";
            }
            else
            {
                

                lblMsgOnlyInputDigit.Text = " ";
            }

            #endregion

            #region String Utilities

            // Uses "Capatalize Method" to capatalize text
            if (string.IsNullOrEmpty(txtCapatalize.Text))
            {
                lblMsgCapatalize.Text = " Space Cannot Be empty ";
                this.lblMsgCapatalize.ForeColor = Color.Red;
            }
            else
            { 
                txtCapatalize.Text = akStringUtilities.AKCapatalize(txtCapatalize.Text);

                lblMsgCapatalize.Text = " ";
            }

            // Uses "ExtractDigit Method" to Extract Digits
            if (string.IsNullOrEmpty(txtExtractDigit.Text))
            {
                lblMsgExtractDigit.Text = " Space Cannot Be empty ";
                this.lblMsgExtractDigit.ForeColor = Color.Red;
            }
            else
            {
                txtExtractDigit.Text = akStringUtilities.AKExtractDigit(txtExtractDigit.Text);
                lblMsgExtractDigit.Text = " ";
            }

            // Uses "FormatPhone Method" to Convert Valid phone no.
            // to Phone pattern { (###)###-#### OR ###-#### }
            if (string.IsNullOrEmpty(txtFormatPhone.Text))
            {
                lblMsgFormatPhone.Text = " Space Cannot Be empty ";
                this.lblMsgFormatPhone.ForeColor = Color.Red;
            }
            else
            {
                txtFormatPhone.Text = akStringUtilities.AKFormatPhone(txtFormatPhone.Text);
                lblMsgFormatPhone.Text = " ";
            }



            // Uses "FormatPostal Method" to Convert a Valid Postal
            // to Format (A3A 3A3)
            if (string.IsNullOrEmpty(txtFormatPostal.Text))
            {
                lblMsgFormatPostal.Text = " Space Cannot Be empty ";
                this.lblMsgFormatPostal.ForeColor = Color.Red;
            }
            else
            {
                txtFormatPostal.Text = akStringUtilities.AKFormatPostal(txtFormatPostal.Text);
                lblMsgFormatPostal.Text = " ";
            }

            // Uses "Format Zip Method" to Convert a Valid Zip
            // to Format {(#####) OR (#####-####)}
            if (string.IsNullOrEmpty(txtFormatZip.Text))
            {
                lblMsgFormatZip.Text = " Space Cannot Be empty ";
                this.lblMsgFormatZip.ForeColor = Color.Red;
            }
            else
            {
                if (txtFormatZip.Text.Length == 5 || txtFormatZip.Text.Length == 9)
                {
                    txtFormatZip.Text = akStringUtilities.AKFormatZip(txtFormatZip.Text);
                    lblMsgFormatZip.Text = " ";
                }
                else
                {
                   lblMsgFormatZip.Text = "Please enter valid Zip Code";
                    this.lblMsgFormatZip.ForeColor = Color.Red;
                }
                
            }

            // Uses "FullName Method" to Covert userinput to
            // name format {Lastname, Firstname} ->(for full name provided).
            //        OR   {Firstname}           ->(for just one of the name provided).

            if (string.IsNullOrEmpty(txtFullName.Text))
            {
                lblMsgFormatFullName.Text = " Space Cannot Be empty ";
                this.lblMsgFormatFullName.ForeColor = Color.Red;
            }
            else
            {
                txtFullName.Text = akStringUtilities.AKFullName(txtFullName.Text);
                lblMsgFormatFullName.Text = "";   
            }

            #endregion

            #region Validations 

            // Validates PostalCode (A3A 3A3) 
            if (string.IsNullOrEmpty(txtValidatePostal.Text))
            {
                lblMsgValidatePostal.Text = " Space Cannot Be empty ";
                this.lblMsgValidatePostal.ForeColor = Color.Red;
            }
            else
            {
                string postal = Convert.ToString(txtValidatePostal.Text);

                if (!akValidations.AKValidatePostalCode(postal))
                {
                    lblMsgValidatePostal.Text = "Invalid Postal Code";
                    this.lblMsgValidatePostal.ForeColor = Color.Red;
                }
                else
                {
                    postal = akValidations.AKValidatePostalCode(postal).ToString();
                    lblMsgValidatePostal.Text = "Valid";
                    this.lblMsgValidatePostal.ForeColor = Color.Green;
                }
            }

            // Validates ZipCode (##### OR ##### ####) 
            // E.g. A Valid 5 digit code is : 33132
            // E.g. Valid 9 digit code : 
            if (string.IsNullOrEmpty(txtValidateZip.Text))
            {
                lblMsgValidateZip.Text = " Space Cannot Be empty ";
                this.lblMsgValidateZip.ForeColor = Color.Red;
            }
            else
            {
                string zip = Convert.ToString(txtValidateZip.Text);
                if(!akValidations.AKValidateZip(zip))
                {
                    lblMsgValidateZip.Text = "Invalid Zip Code";
                    this.lblMsgValidateZip.ForeColor = Color.Red;
                }
                else
                {
                    zip = akValidations.AKValidateZip(zip).ToString();
                    lblMsgValidateZip.Text = "Valid";
                    this.lblMsgValidateZip.ForeColor = Color.Green;
                }  
            }

            // Validates Phone Number extracting digits {(###) ### - #### } 
            if (string.IsNullOrEmpty(txtValidatePhone.Text))
            {
                lblMsgValidatePhone.Text = " Space Cannot Be empty ";
                this.lblMsgValidatePhone.ForeColor = Color.Red;
            }
            else
            {
                string phone = Convert.ToString(txtValidatePhone.Text);

                if (!akValidations.AKValidatePhone(phone))
                {
                    lblMsgValidatePhone.Text = "Invalid Phone Number";
                    this.lblMsgValidatePhone.ForeColor = Color.Red;
                }
                else
                {
                    phone = akValidations.AKValidatePhone(phone).ToString();
                    lblMsgValidatePhone.Text = "Valid";
                    this.lblMsgValidatePhone.ForeColor = Color.Green;
                }  
            }
#endregion

        }

           #region Other Buttons and Properties

        // KeyPress Event for "e.KeyChar" and "e.Handled"
        private void txtOnlyInputDigit_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
                lblMsgOnlyInputDigit.Text = "Only Digits allowed !!";
                this.lblMsgOnlyInputDigit.ForeColor = Color.Red;
            }
            else
            {
                lblMsgOnlyInputDigit.Text = " ";
            }
        }

        // Prefills TextBoxes with records and clears Error Msgs
        // of the labels if any active
        private void btnPreFill_Click(object sender, EventArgs e)
        {
            txtIsNumeric.Text = "1";
            txtIsInteger.Text = "1.1";
            txtExtractNumeric.Text = "1.1";
            txtOnlyInputDigit.Text = "123";
            txtCapatalize.Text = "hello world";
            txtExtractDigit.Text = "12345678";
            txtFormatPhone.Text = "5197297030";
            txtFormatPostal.Text = "n2p1z7";
            txtFormatZip.Text = "331325515";
            txtFullName.Text = "ankit kundlu";
            txtValidatePostal.Text = "n2p 1z7";
            txtValidateZip.Text = "33132";
            txtValidatePhone.Text = "5197297030";

            lblMsgIsNumeric.Text = lblMsgIsInteger.Text =
            lblMsgExtractNumeric.Text = lblMsgOnlyInputDigit.Text =
            lblMsgCapatalize.Text = lblMsgExtractDigit.Text =
            lblMsgFormatPhone.Text = lblMsgFormatPostal.Text =
            lblMsgFormatZip.Text = lblMsgFormatFullName.Text =
            lblMsgValidatePostal.Text = lblMsgValidateZip.Text =
            lblMsgValidatePhone.Text = "";
        }

        // Clears everything i.e. ErrorMsgs and TextBoxes
        private void btnClearTxtBox_Click(object sender, EventArgs e)
        {
            txtIsNumeric.Text = " ";
            txtIsInteger.Text = " ";
            txtExtractNumeric.Text = " ";
            txtOnlyInputDigit.Text = " ";
            txtCapatalize.Text = " ";
            txtExtractDigit.Text = " ";
            txtFormatPhone.Text = " ";
            txtFormatPostal.Text = " ";
            txtFormatZip.Text = " ";
            txtFullName.Text = " ";
            txtValidatePostal.Text = " ";
            txtValidateZip.Text = " ";
            txtValidatePhone.Text = " ";

            lblMsgIsNumeric.Text = lblMsgIsInteger.Text =
            lblMsgExtractNumeric.Text = lblMsgOnlyInputDigit.Text =
            lblMsgCapatalize.Text = lblMsgExtractDigit.Text =
            lblMsgFormatPhone.Text = lblMsgFormatPostal.Text =
            lblMsgFormatZip.Text = lblMsgFormatFullName.Text =
            lblMsgValidatePostal.Text = lblMsgValidateZip.Text =
            lblMsgValidatePhone.Text = "";
        }

             

        // Extract Numeric and trims other character at the same time.
        private void txtExtractNumeric_TextChanged(object sender, EventArgs e)
        {
            Exception ex = new Exception();

            TextBox txt = (TextBox)sender;

            // Trims
            txt.Text = txt.Text.Trim();
            try
            {
                if (txt.Text != "-")
                {
                    int x = int.Parse(txt.Text);
                }
            }
            catch (Exception ex1)
            {
                try
                {
                    // looks for selection start
                    int CursorIndex = txt.SelectionStart - 1;
                    txt.Text = txt.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    txt.SelectionStart = CursorIndex;
                    txt.SelectionLength = 0;
                }
                catch (Exception ex2)
                {
                    lblMsgExtractNumeric.Text = "No characters allowed" + ex2.Message;
                }

                lblMsgExtractNumeric.Text = "No characters allowed" + ex1.Message;
            }
        }
    }
#endregion
}
