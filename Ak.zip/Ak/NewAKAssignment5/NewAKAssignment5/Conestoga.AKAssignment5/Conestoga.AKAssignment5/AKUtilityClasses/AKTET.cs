using System;  
using NUnit.Framework; 


namespace allTests
{
[TestFixture]
  public allTests
  {
    [Test]
	public  Boolean validInputs
	{
	
	  AKNumericUtilities obj = new AKNumericUtilities;
	  
	  Assert.AreEqual(0, obj.AKisNumeric(0));
	
	
	
	}
  
  }

}