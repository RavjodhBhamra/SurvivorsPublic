﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
/*
     This is a DAL class naming "AKProvince" in "AKClasses"
     folder. This class contains following methods in
     sequence.
     1) AKFillList.
     2) AKParseProvince
     4) AKGetProvince
     5) AKSave
     6) AKUpdate
     7) AKDelete
     8) AKCreateFile 
 */
namespace Conestoga.AKAssignment4.AKClasses
{
    class AKProvince
    {
        // Class-level Streams
        private FileStream fileStream = null;
        private StreamReader reader = null;
        private StreamWriter writer = null;

        private string dataPath = "";
        
        // gets and sets path 
        public string Path
        {
            get { return dataPath; }
            set { dataPath = value; }
        }

       // Fills the list Box and saves entire
       // in ".txt" file.
        public int AKFillList()
        {
            int count = 0;
           AKCreateFile();
            try
            {
                fileStream = new FileStream(dataPath, FileMode.Open);
                if (fileStream.Length > 0)
                {
                    reader = new StreamReader(fileStream);
                    while (reader.ReadLine() != null)
                    {
                        count++;
                    }
                    reader.Close();
                }
                fileStream.Close();
            }
            catch
            {
                count = 0;
            }
            return count;
        }

       // Reads the ".txt" File. 
        public bool AKParseProvince(int id,
                               ref string provinceCode,
                               ref string provinceName,
                               ref string countryCode,
                               ref string taxCode,
                               ref string taxRate)
        {
            int count = 0;
            AKCreateFile();
            try
            {
                fileStream = new FileStream(dataPath, FileMode.Open);
                reader = new StreamReader(fileStream);
                string temp = "";
                bool cond = true;
                while (cond == true)
                {

                    if ((temp = reader.ReadLine()) == null)
                    {
                        reader.Close();
                        fileStream.Close();
                        cond = false;
                        if (count == 0)
                            return false;
                    }


                    if (count == id)
                    {
                        string[] stringSplit = temp.Split('\t');
                        int maxIndex = stringSplit.Length;
                        provinceCode = stringSplit[0];
                        provinceName = stringSplit[1];
                        countryCode = stringSplit[2];
                        taxCode = stringSplit[3];
                        taxRate = stringSplit[4];

                    }
                    count++;

                }

                reader.Close();
                fileStream.Close();
                return true;
            }
            catch
            {
                return false;
            }

        }

        // Fills the list box with Province Code
        // if Province code selected by user in List Box,
        // it displays entire data of that particular 
        // province code in respective textBoxes
        public bool AKGetProvince(int id, ref string provinceCode)
        {
            int count = 0;
            AKCreateFile();
            try
            {
                fileStream = new FileStream(dataPath, FileMode.Open);
                reader = new StreamReader(fileStream);
                bool cond = true;
                string temp = "";
                while (cond == true)
                {

                    if ((temp = reader.ReadLine()) == null)
                    {
                        reader.Close();
                        fileStream.Close();
                        cond = false;
                        if (count == 0)
                            return false;
                    }

                    if (count == id)
                    {
                        string[] stringSplit = temp.Split('\t');
                        int maxIndex = stringSplit.Length;
                        provinceCode = stringSplit[0];
                    }
                    count++;

                }

                reader.Close();
                fileStream.Close();
                return true;
            }
            catch
            {
                return false;
            }

        }

        // Writes the record to ".txt" file.
        // Trims the Spaces.
        // Shifts required fields to upper case
        public bool AKSave(string provinceCode,
                           string provinceName,
                           string countryCode,
                           string taxCode,
                           string taxRate)
        {
            AKCreateFile();

            
            try
            {
                provinceCode = (provinceCode + "").Trim().ToUpper();
                provinceName = (provinceName + "").Trim();
                countryCode = (countryCode + "").Trim().ToUpper();
                taxCode = (taxCode = "").Trim().ToUpper();

                fileStream = new FileStream(dataPath, FileMode.Append);
                writer = new StreamWriter(fileStream);
                writer.WriteLine(provinceCode + '\t' +
                                 provinceName + '\t' +
                                 countryCode + '\t' +
                                 taxCode + '\t' +
                                 taxRate);
                writer.Close();
                fileStream.Close();
                return true;
            }
            catch (Exception ex)
            {
                string temp = ex.Message;
                return false;
            }
        }

        // Updates the edited record in ".txt file
        // replacing the existed record in ".txt" file
        public bool AKUpdate(int id, 
                                 string provinceCode,
                                 string provinceName,
                                 string countryCode,
                                 string taxCode,
                                 string taxRate)
        {
            int count = 0;
            AKCreateFile();
            try
            {
                fileStream = new FileStream(dataPath, FileMode.Open);
                reader = new StreamReader(fileStream);

                string temp = "";
                string temp2 = "";
                while ((temp = reader.ReadLine()) != null)
                {

                    if (count == id)
                    {
                        temp2 += provinceCode + '\t' +
                                 provinceName + '\t' +
                                 countryCode + '\t' +
                                 taxCode + '\t' +
                                 taxRate + "\r\n";
                    }
                    else
                    {
                        temp2 += (temp + "\r\n");
                    }
                    count++;

                }
                reader.Close();
                fileStream.Close();

                fileStream = new FileStream(dataPath, FileMode.Create);
                writer = new StreamWriter(fileStream);
                writer.Write(temp2);
                writer.Close();
                fileStream.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Deletes the Selected index Province 
        // from the list box with entire data
        // the selected provinceCode had.
        public bool AKDelete(int id)
        {
            int count = 0;
            AKCreateFile();
            try
            {
                fileStream = new FileStream(dataPath, FileMode.Open);
                reader = new StreamReader(fileStream);

                string temp = "";
                string temp2 = "";
                while ((temp = reader.ReadLine()) != null)
                {

                    if (count != id)
                    {
                        temp2 += (temp + "\r\n");
                    }
                    count++;

                }
                reader.Close();
                fileStream.Close();

                fileStream = new FileStream(dataPath, FileMode.Create);
                writer = new StreamWriter(fileStream);
                writer.Write(temp2);
                writer.Close();
                fileStream.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Creates the file and enters record to it,
        // hence this method is called in every above 
        // methods
        private bool AKCreateFile()
        {
            try
            {
                dataPath = dataPath.Replace((char)92, '/');
                dataPath = dataPath.Replace((char)9, '/');
                if (!File.Exists(dataPath))
                {

                    string temp = System.IO.Path.GetDirectoryName(dataPath);

                    if (!Directory.Exists(temp))
                    {
                        Directory.CreateDirectory(temp);
                    }
                    fileStream = new FileStream(dataPath, FileMode.CreateNew);
                    fileStream.Close();
                }
                return true;
            }
            catch
            {
                return false;
            }
 
        }
    }
}
