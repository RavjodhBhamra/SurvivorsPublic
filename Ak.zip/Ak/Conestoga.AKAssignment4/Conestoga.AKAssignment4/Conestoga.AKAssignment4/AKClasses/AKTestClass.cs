using Nunit.Framework;
using System;


namespace UnitTest.Province.Classes
{
 [TextFixture]
public class Province
{
   private readonly Province _valid;
   
   public Province_IsValid 
   {
  
     _valid = new Province();
       
   
   }
   [Test]
   public ReturnValue
   {
	   
	   Assert.IsTrue(AKCreateFile,result, "I have a new file");
	   
   }



}






}