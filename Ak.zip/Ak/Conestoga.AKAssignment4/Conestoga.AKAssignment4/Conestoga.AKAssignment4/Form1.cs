﻿using Conestoga.AKAssignment4.AKClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 *This is a windows form app that functions to keep track of 
 * Province Record and taxes associated.
 * 
 * Specifically, this windows for app will allow user to
 * save record ".txt" file at the same time user will see the
 * update of the record in List box.
 * 
 * user can delete the record, update the record
 * but cannot save same province record which is
 * already existing
 * 
 * Ankit Ravindra Kundlu, 2018.04.01 : Created 
 */
namespace Conestoga.AKAssignment4
{
    public partial class AKAssignment4 : Form
    {
        // Data Access Layer link
        private AKProvince DAL;
        string txtvalue = "";

        string provinceCode = "";
        string provinceName = "";
        string countryCode = "";
        string taxCode = "";
        string taxRate = "";


        public AKAssignment4()
        {
            //get set path, from AKProvince class 
            InitializeComponent();
            DAL = new AKProvince();
            DAL.Path = @"C:\PROG1815data\Province.txt";

            //Fills list Box(Methods)
            fillListBox();
        }

        private void AKAssignment4_Load(object sender, EventArgs e)
        {
            //Loads form for user for new
            //  record entry
            txtProvinceCode.Text = "";
            txtName.Text = "";
            txtCountryCode.Text = "";
            chkIncludesFedTax.Checked = false;

            txtTaxCode.Text = "";
            txtTaxCode.Enabled = false;

            txtTaxRate.Text = "0";
            txtTaxRate.Enabled = false;

            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
        }

        /// <summary>
        /// This region consists of methods called in 
        /// required btns for proper validations
        /// </summary>
        #region Methods Created

        // This method fills list Box using
        // AKFillList method form AKProvince class
        // with the Province Code of
        // each record entered by user
        private void fillListBox()
        {
            this.lstProvinceCode.Items.Clear();
            int temp = DAL.AKFillList();
            if (temp > 0)
            {
                temp--;
                for (int i = 0; i <= temp; i++)
                {
                    
                    DAL.AKGetProvince(i, ref provinceCode);
                    this.lstProvinceCode.Items.Add(provinceCode);
                }
                lstProvinceCode.SelectedIndex = 0;
            }
        }

        // This method reads the record using 
        // AKParseProvince Method of AKProvince Class
        private void read(int id)
        {  
            txtvalue = id.ToString();
            bool result = DAL.AKParseProvince(id, ref provinceCode,
                                             ref provinceName, 
                                             ref countryCode, 
                                             ref taxCode, 
                                             ref taxRate);

            txtProvinceCode.Text = provinceCode;
            txtName.Text = provinceName;
            txtCountryCode.Text = countryCode;
            txtTaxCode.Text = taxCode;
            taxRate = txtTaxRate.Text;   
        }

        // This Method indicates user about the'
        // errors and how to fix errors 
        //(this method is called in "btnSave")
        public bool AKError(string provinceCode,
                            string provinceName,
                            string countryCode,
                            string taxCode,
                            string taxRate)
        {
            // Regex Expression to check if user entered 
            // digit and letters in desired place
            
            Regex digit = new Regex(@"^(\d+\.?\d*|\.\d+)$");
            Regex twoLetters = new Regex(@"^([A-Z][A-Z])$", RegexOptions.IgnoreCase);

            try
            {
                string errors = "";

                if (provinceCode == "")
                {
                    errors += "first name cannot be empty or just spaces\n";
                } 
                if (provinceName == "")
                {
                    errors += "last name cannot be empty or just spaces\n";
                }

                if (countryCode == "")
                {
                    errors += "country code cannot be empty or just spaces\n";
                }

                if (errors != "")
                {
                    throw new Exception($"validation Errors\n{errors}");
                }

                if (!twoLetters.IsMatch(provinceCode))
                {
                    errors += "province Code should be two letter\n";
                }

                if (!twoLetters.IsMatch(countryCode))
                {
                    errors += "country code should be two letters\n";
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error :\n { ex.Message }");
                return false;
            }

        }

        #endregion

        /// <summary>
        /// This region consists of Buttons in the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region Buttons

         // clears form for new record.
        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtProvinceCode.Text = "";
            txtName.Text = "";
            txtCountryCode.Text = "";
            txtTaxCode.Text = "";
            txtTaxRate.Text = "0";
            chkIncludesFedTax.Checked = false;

            btnUpdate.Enabled = false;
            btnSave.Enabled = true;

        }

        // Saves record using "AKSave" method of
        //"AKProvince" class after checking errors using
        // AKError method.
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (AKError(txtProvinceCode.Text, txtName.Text,
                txtCountryCode.Text, txtTaxCode.Text, txtTaxRate.Text))
                {
                    DAL.AKSave(txtProvinceCode.Text, txtName.Text,
                           txtCountryCode.Text, txtTaxCode.Text,
                           txtTaxRate.Text);

                    txtvalue = Convert.ToString(DAL.AKFillList() - 1);
                    fillListBox();

                }
                else
                {
                    AKError(txtProvinceCode.Text, txtName.Text,
                    txtCountryCode.Text, txtTaxCode.Text, txtTaxRate.Text);
                }

            }
            catch (Exception EX)
            {
                MessageBox.Show($"Error saving record\n{EX.Message}");
            }         
        }

        // Updates the record replacing the function of 
        // btnSave and disables save button.
        // Uses "AKUpdate" of "AKProvince" Class
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                provinceCode = txtProvinceCode.Text;
                provinceName = txtName.Text;
                countryCode = txtCountryCode.Text;
                taxCode = txtTaxCode.Text;
                taxRate = txtTaxRate.Text;
               
                int id = Convert.ToInt32(txtvalue);
                DAL.AKUpdate(id, provinceCode, provinceName, countryCode, taxCode, taxRate);
                fillListBox();

                txtProvinceCode.Text = txtName.Text =
                txtCountryCode.Text = txtTaxCode.Text =
                txtTaxRate.Text = "";
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Error Updating record\n{ex.Message}");
            }   
        }

        // deletes the record using the users selected Index of 
        // List box and using "AKDelete" method of 
        // "AKProvince" Class
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstProvinceCode.SelectedIndex < -1)
                {
                    MessageBox.Show("Nothing is selected to delete");
                }
                else
                {
                    int id = Convert.ToInt32(txtvalue);
                    DAL.AKDelete(id);
                    read(0);
                    fillListBox();

                    txtProvinceCode.Text = txtName.Text =
                    txtCountryCode.Text = txtTaxCode.Text =
                    txtTaxRate.Text = "";

                    lstProvinceCode.ClearSelected();
                    txtProvinceCode.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting record\n{ex.Message}");
            }  
        }

        // Asks user, if yes, closes the form
        private void btnClose_Click(object sender, EventArgs e)
        {
            string response;
            response = MessageBox.Show(" Are you sure you want to " +
                                       "close file and Exit",
                                     " Close File ", MessageBoxButtons.YesNo,
                                      MessageBoxIcon.Exclamation).ToString();

            if (response == "Yes")
            {
                this.Close();
            }
        }

        #endregion

        #region ListBox,CheckBox
        private void lstProvinceCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            btnUpdate.Enabled = true;
            //txtID.Text = combo.SelectedIndex.ToString();
            txtvalue = lstProvinceCode.SelectedIndex.ToString();
            //read(Convert.ToInt32(txtID.Text));
            read(Convert.ToInt32(txtvalue));

            txtTaxCode.Enabled = true;
            txtTaxRate.Enabled = true;
        }

        private void chkIncludesFedTax_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkIncludesFedTax.Checked)
            {
                txtTaxCode.Text = "";
                txtTaxCode.Enabled = false;

                txtTaxRate.Text = "0";
                txtTaxRate.Enabled = false;
            }
            else
            {
                txtTaxCode.Enabled = true;

                txtTaxRate.Text = "";
                txtTaxRate.Enabled = true;
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            //Makes Province name Title case
            txtName.Text = System.Threading.Thread.CurrentThread.
                   CurrentCulture.TextInfo.ToTitleCase(this.txtName.Text);
            txtName.Select(txtName.Text.Length, 0);
        }

        #endregion

    }
}
